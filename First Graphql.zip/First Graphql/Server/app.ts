import { ApolloServer } from "@apollo/server"
import { startStandaloneServer } from "@apollo/server/standalone"
import connectDb from "./config/dbConnect.config"
import schema from "./Graphql/schema.graphql"
import {
    createEmployee,
    getEmployeeDetails,
    getEmployeeAddressDetails,
    getEmployeeContactDetails,
    getEmployeeRHDetails,
    toggleEmployee,
    changeRH,
    getAllEmployee,
    getEmployeeAssociativeData
} from "./controller/Employee.controller"
import 'dotenv/config'


connectDb().then(() => {
    const server = new ApolloServer({
        typeDefs: schema,
        resolvers: {
            Query: {
                // Type : Controoler Method
                findEmployee: getEmployeeDetails,
                getAllEmployee: getAllEmployee,
                getEmployeeList: getAllEmployee,
                oldField: (value) => {
                    console.log("Hey");
                    return value
                }
            },
            Mutation: {
                createEmployee: createEmployee,
                toggleEmployee: toggleEmployee,
                changeRH: changeRH
            },
            Employee: {
                Employee_Address: getEmployeeAddressDetails,
                Employee_Contact: getEmployeeContactDetails,
                Employee_Rh: getEmployeeRHDetails,
                Employee_Associates: getEmployeeAssociativeData
            },
        }
    })
    startStandaloneServer(server, {
        listen: { port: 8080 }
    }).then(() => console.log("Server Listening ON http://localhost:8080"))
        .catch((e) => console.log("StandAlone Server Error", e))
}).catch((e) => {
    console.log("Error", e);
})