import mongoose from "mongoose";
import { Employee_Address } from "../types/Employee.types"


const AddressSchema = new mongoose.Schema<Employee_Address>({
    Employee_State: {
        type: String,
        required: true
    },
    Employee_City: {
        type: String,
        required: true
    },
    Employee_Pincode: {
        type: String,
        required: true,
        minlength: 6,
        maxlength: 6
    }
},{timestamps:true})

export const Address = mongoose.model<Employee_Address>("Address",AddressSchema)