import mongoose from "mongoose";
import { Employee_Contact } from "../types/Employee.types";

const ContactSchema = new mongoose.Schema<Employee_Contact>({
    Employee_Number1: {
        type: String,
        required: true
    },
    Employee_Number2: {
        type: String,
        required: true
    },
    Employee_Email: {
        type: String,
        required: true
    }
})
export const Contact = mongoose.model<Employee_Contact>("Contact", ContactSchema)