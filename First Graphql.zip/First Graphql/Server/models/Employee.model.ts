import mongoose from "mongoose";
import { Emp_Depart, EmployeeTypes } from "../types/Employee.types"

const EmployeeSchema = new mongoose.Schema<EmployeeTypes>({
    Employee_Name: {
        type: String,
        required: true
    },
    Employee_Age: {
        type: Number,
        required: true
    },
    Employee_DOB: {
        type: String,
        required: true
    },
    Employee_Department: {
        type: String,
        enum: Object.values(Emp_Depart)
    },
    Employee_Gender: {
        type: String,
        required: true
    },
    Employee_Address: {
        type: mongoose.Types.ObjectId,
        ref: "Address",
        required: true
    },
    Employee_Contact: {
        type: mongoose.Types.ObjectId,
        ref: "Contact",
        required: true
    },
    Employee_RH: {
        type: mongoose.Types.ObjectId,
        ref: "Employee"
    },
    Employee_Active: {
        type: Boolean,
        default: true
    },
    Employee_Associates: [
        {
            type: mongoose.Types.ObjectId,
            ref: "Employee",
        }
    ]
})

export const Employee = mongoose.model<EmployeeTypes>("Employee", EmployeeSchema)