const schema = `#Heyy
enum Emp_Depart{
    HR
    NETWORK
    ADMIN
    DEVELOPER
}

type Employee_Contact{
    Employee_Number1:String
    Employee_Number2:String
    Employee_Email:String
}
type Employee_Address{
    Employee_State:String
    Employee_City: String
    Employee_Pincode: String
}

# Data Fetching
type Employee{
    Employee_Name: String
    Employee_Age: Int
    Employee_DOB: String
    Employee_Gender: String
    Employee_Department: Emp_Depart
    Employee_Address: Employee_Address
    Employee_Contact: Employee_Contact
    Employee_Rh:Employee
    Employee_Active:Boolean
    Employee_Associates:[Employee]
}

type EmployeeList{
    Employee_Name:String
}

type Mutation{
    createEmployee(
        Employee_Name: String,
        Employee_Age: Int,  
        Employee_DOB: String,
        Employee_Gender: String,
        Employee_Department: Emp_Depart,
        Employee_Number1:String
        Employee_Number2:String
        Employee_Email:String
        Employee_State:String
        Employee_City:String
        Employee_Pincode:String
        Employee_RhName:String
    ):String
    toggleEmployee(name:String):String # Soft Delete Employee With IsActive True False
    changeRH(employeeName: String, newRhName: String):String    
}

type Query{
    findEmployee(name:String):Employee
    getAllEmployee:[Employee]
    getEmployeeList:[EmployeeList]
    oldField:String @deprecated(reason:"Use New Field")
}
`;

export default schema