import { Contact } from "../models/Contact.model"
import { Address } from "../models/Address.model"
import { Employee } from "../models/Employee.model"
import { getEmployeeId } from "../utils/getEmployeeId.utils"
import { EmployeeTypes, Employee_Address, Employee_Contact } from "../types/Employee.types"
import { ObjectId, isValidObjectId } from "mongoose"
import mongoose from "mongoose"

const createEmployee = async (parent: undefined, args: any) => {
    const {
        Employee_Name,
        Employee_Age,
        Employee_DOB,
        Employee_Gender,
        Employee_Number1,
        Employee_Number2,
        Employee_Email,
        Employee_RhName,
        Employee_State,
        Employee_City,
        Employee_Pincode,
        Employee_Department
    } = args

    const createContact: Employee_Contact = await Contact.create({
        Employee_Email,
        Employee_Number1,
        Employee_Number2
    })
    const createAddress: Employee_Address = await Address.create({
        Employee_City,
        Employee_Pincode,
        Employee_State
    })
    const employeeData: EmployeeTypes = {
        Employee_Name,
        Employee_Age,
        Employee_DOB,
        Employee_Gender,
        Employee_Department,
        Employee_Address: createAddress._id,
        Employee_Contact: createContact._id,
        Employee_Associates: []
    }

    if (Employee_RhName) {
        employeeData.Employee_RH = await getEmployeeId(Employee_RhName)
    }

    const createEmployee = await Employee.create(employeeData)

    if (createEmployee && Employee_RhName) {
        // Adding Associates
        const addAssociate = await Employee.findOneAndUpdate({ Employee_Name: Employee_RhName },
            { $push: { Employee_Associates: createEmployee._id } })
    }
    return "Employee Created"
}
const getAllEmployee = async () => {
    const allEmployeeData = Employee.find()
    return allEmployeeData
}
const getEmployeeDetails = async (parent: undefined, args: { name: string }) => {
    const { name } = args

    const findEmployee = await Employee.findOne({
        $and: [
            { Employee_Name: name },
            { Employee_Active: true }
        ]
    })
    if (findEmployee) {
        return findEmployee
    }
    else {
        return "No Employee Found"
    }
}

const getEmployeeContactDetails = async (parent: EmployeeTypes) => {
    const employeeContact = await Contact.findById({ _id: parent.Employee_Contact })
    return employeeContact
}

const getEmployeeAddressDetails = async (parent: EmployeeTypes) => {
    const employeeAddress = await Address.findById({ _id: parent.Employee_Address })
    return employeeAddress
}

const getEmployeeRHDetails = async (parent: EmployeeTypes) => {
    if (isValidObjectId(parent.Employee_RH)) {
        const employeeRhData = await Employee.findById({ _id: parent.Employee_RH })
        return employeeRhData
    }
    else {
        return parent
    }
}

const getEmployeeAssociativeData = async (parent: EmployeeTypes) => {
    const associativeEmployeeData = await Employee.find(
        { Employee_Associates: { $in: parent.Employee_Associates } }
    )
    return associativeEmployeeData
}
const toggleEmployee = async (_: undefined, data: { name: String }) => {
    const findUser: any = await Employee.findOne({ Employee_Name: data.name })

    if (findUser?.Employee_Active) {// User Deletion 
        findUser.Employee_Active = !findUser.Employee_Active

        // Removing All Employees RH Field Under This.Employee
        await Employee.updateMany({ Employee_RH: findUser._id }, { $unset: { Employee_RH: "" } })
        findUser.save()

        return "Employee Deleted"
    }
    else { // Revoking Employee
        findUser.Employee_Active = !findUser?.Employee_Active
        findUser.save()
        // Setting Employee Old RH
        const setEmployeeRH = await Employee.updateMany(
            {
                _id: { $in: findUser.Employee_Associates }
            },
            {
                $set: { Employee_RH: findUser._id }
            }
        )
        return "Employee Revoked"
    }

}

const changeRH = async (_: undefined, data: { employeeName: String, newRhName: String }) => {

    //  Change RH In Employee
    const changeRH = await Employee.findOneAndUpdate(
        { Employee_Name: data.employeeName },
        { Employee_RH: await getEmployeeId(data.newRhName) })

    if (!changeRH) {
        return "Error Chaning RH"
    }
    // Remove EmployeeId From OldRh Array
    const removeFromOldRh = await Employee.updateOne(
        { _id: changeRH.Employee_RH },
        { $pull: { Employee_Associates: changeRH._id } },
        { new: true }
    )

    // Add EmployeeId To NewRh Array
    const updateNewRH = await Employee.updateOne(
        { Employee_Name: data.newRhName },
        { $push: { Employee_Associates: changeRH._id } },
        { new: true }
    )
}

export {
    createEmployee,
    getEmployeeDetails,
    getEmployeeContactDetails,
    getEmployeeAddressDetails,
    getEmployeeRHDetails,
    toggleEmployee,
    changeRH,
    getAllEmployee,
    getEmployeeAssociativeData
}