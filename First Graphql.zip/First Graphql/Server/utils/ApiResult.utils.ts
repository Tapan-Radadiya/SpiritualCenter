export const ApiResult = (stausCode:number,message:string,data?:object,err?:Error) => {
    return {
        stausCode:stausCode,
        message:message,
        data:data,
        err:err
    }
}