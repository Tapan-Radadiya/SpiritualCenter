import { Employee } from "../models/Employee.model"

export const getEmployeeId = async (employeeName: String) => {
    const data: any = await Employee.findOne({ Employee_Name: employeeName })
    if (data) {
        return data._id
    }
    else {
        return "No Rh Found"
    }
}