import mongoose from "mongoose";
const connectDb = async () => {
    try {
        const connectDbStatus = await mongoose.connect(`${process.env.MONGODB_URL}/${process.env.MONGODB_DATABASE}`)
        console.log(`Connected With Host : ${connectDbStatus.connection.host}`);
    } catch (error) {
        console.log(`Error Connection to DB ${error}`);

    }
}
export default connectDb