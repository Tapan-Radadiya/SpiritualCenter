import { ObjectId, Document } from "mongoose"

export enum Emp_Depart {
    HR = "HR",
    NETWORK = "NETWORK",
    ADMIN = "ADMIN",
    DEVELOPER = "DEVELOPER"
}

export interface Employee_Contact extends Document {
    Employee_Number1: String
    Employee_Number2: String
    Employee_Email: String
}
export interface Employee_Address extends Document {
    Employee_State: String
    Employee_City: String
    Employee_Pincode: String
}
export interface EmployeeTypes {
    Employee_Name: String
    Employee_Age: Number
    Employee_DOB: String
    Employee_Gender: String
    Employee_Department: Emp_Depart
    Employee_RH?: ObjectId
    Employee_Address: ObjectId
    Employee_Contact: ObjectId
    Employee_Active?: Boolean
    Employee_Associates: [ObjectId] | []
}