import { useForm } from "react-hook-form"
import Input from "./ul component/Input"
import Button from "./ul component/Button"
import { useNavigate } from "react-router-dom"
import { createEmployee } from "../services/employee.services"

export default function CreateEmployee() {
    type EmployeeForm = {
        Employee_Name: String
        Employee_Age: Number
        Employee_DOB: Date
        Employee_Gender: String
        Employee_Department: String
        Employee_Number1: String
        Employee_Number2: String
        Employee_Email: String
        Employee_State: String
        Employee_City: String
        Employee_Pincode: String
        Employee_RhName: String
    }
    const navigate = useNavigate()
    const { register, handleSubmit } = useForm<EmployeeForm>()
    function validate(data: EmployeeForm) {
        createEmployee(data)
        // navigate("/")
    }
    return (
        <>
            <div className="flex flex-col justify-center items-center">
                <div>
                    <h1 className="uppercase text-4xl text-center mt-5">Create Employee</h1>
                </div>
                <div className="flex flex-col gap-4 border border-black p-5 rounded-lg font-mono tracking-wider mt-[20px] w-1/3">
                    <form onSubmit={handleSubmit((data) => validate(data))}>
                        <div>
                            <Input
                                className="border border-gray-700 rounded-lg focus:ring-black p-2.5 w-full"
                                id="employee_name"
                                label="Employee Name"
                                labelClass="block mb-2"
                                placeholder="mployee Name"
                                type="text"
                                {...register("Employee_Name")}
                                register={register}
                            />
                        </div>
                        <div>
                            <Input
                                className="border border-gray-700 rounded-lg focus:ring-black p-2.5 w-full"
                                {...register("Employee_Age")}
                                id="employee_age"
                                label="Employee Age"
                                labelClass="block mb-2"
                                placeholder="Employee Age"
                                type="text"
                                register={register}
                            />
                        </div>
                        <div>
                            <Input
                                className="border border-gray-700 rounded-lg focus:ring-black p-2.5 w-full"
                                id="employee_Dob"
                                label="Employee DateOfBirth"
                                labelClass="block mb-2"
                                placeholder="Employee DOB"
                                type="date"
                                {...register("Employee_DOB")}
                                register={register}
                            />
                        </div>
                        <p className="mb-1">Employee Gender</p>
                        <div className="flex gap-5">
                            <div>
                                <input type="radio" value={"Male"} {...register("Employee_Gender")} id="Male" className="w-4 h-4 text-blue-600 border-gray-300 " />
                                <label htmlFor="Male" className="ms-2 font-medium">Male</label>
                            </div>
                            <div>
                                <input type="radio" value={"Female"} {...register("Employee_Gender")} id="Female" className="w-4 h-4 text-blue-600 border-gray-300  " />
                                <label htmlFor="Female" className="ms-2 font-medium">Female</label>
                            </div>
                        </div>
                        <div>
                            <label htmlFor="employee_depart" className="block mb-2">Employee Department</label>
                            <select id="employee_depart" {...register("Employee_Department")} className="bg-gray-50 border border-gray-700 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                <option value="">----</option>
                                <option value="HR">Hr</option>
                                <option value="ADMIN">Admin</option>
                                <option value="NETWORK">Network</option>
                                <option value="DEVELOPER">Developer</option>
                            </select>
                        </div>
                        <div>
                            <p className="mb-2">Employee Address</p>
                            <div className="flex justify-between">
                                <div>
                                    <select id="state" {...register("Employee_State")} className="bg-gray-50 border border-gray-700 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-auto p-2.5">
                                        <option value="">Select State</option>
                                        <option value="Gujarat">Gujarat</option>
                                        <option value="UP">UP</option>
                                    </select>
                                </div>
                                <div>
                                    <select {...register("Employee_City")} id="" className="bg-gray-50 border border-gray-700 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-auto p-2.5">
                                        <option value="">Select City</option>
                                        <option value="Gujarat">Gujarat</option>
                                        <option value="UP">UP</option>
                                    </select>
                                </div>
                                <div>
                                    <input type="text" {...register("Employee_Pincode")} id="pincode" className="border border-gray-700 rounded-lg focus:ring-black p-2.5 w-auto" placeholder="PinCode" />
                                </div>
                            </div>
                        </div>
                        <div>
                            <p className="mb-2">Employee Contact Details</p>
                            <div className="flex justify-between space-x-5">
                                <div>
                                    <Input
                                        className="border border-gray-700 rounded-lg focus:ring-black p-2.5 w-full placeholder:text-sm"
                                        id=""
                                        placeholder="Mobile Number"
                                        type="text"
                                        {...register("Employee_Number1")}
                                        register={register}
                                    />
                                </div>
                                <div>
                                    <Input
                                        className="border border-gray-700 rounded-lg focus:ring-black p-2.5 w-full placeholder:text-sm"
                                        id=""
                                        placeholder="Alternate Mobile Number"
                                        type="text"
                                        {...register("Employee_Number2")}
                                        register={register}
                                    />
                                </div>
                                <div>
                                    <Input
                                        className="border border-gray-700 rounded-lg focus:ring-black p-2.5 w-full placeholder:text-sm"
                                        id=""
                                        {...register("Employee_Email")}
                                        placeholder="Employee EmailId"
                                        type="text"
                                        register={register}
                                    />
                                </div>
                            </div>
                        </div>
                        <div>
                            <label htmlFor="employee_name" className="block mb-2">Employee Reporting Head</label>
                            <select name="" id="employeeRH" className="bg-gray-50 border border-gray-700 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                <option value="user1">User 1</option>
                                <option value="user2">User 2</option>
                                <option value="user3">User 3</option>
                                <option value="user4">User 4</option>
                            </select>
                        </div>
                        <div className="text-center">
                            <Button
                                btnText="Register Employee"
                                className="mt-5 w-1/2 border border-black p-2.5 uppercase tracking-widest rounded-md hover:bg-gray-300 hover:tracking-wide duration-500"
                            // onClick={validate}
                            />
                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}