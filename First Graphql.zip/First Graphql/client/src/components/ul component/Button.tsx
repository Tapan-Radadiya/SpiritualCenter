import { MouseEventHandler } from "react"

export default function Button(
    {
        btnText,
        className,
        onClick,
    }: {
        btnText: string
        className: string
        onClick?: MouseEventHandler
    }
) {
    return (
        <>
            <button className={className} onClick={onClick}>{btnText}</button>
        </>
    )
}