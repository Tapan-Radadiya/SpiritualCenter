export default function Input({
    className,
    name,
    id,
    type,
    placeholder,
    label,
    labelClass,
    register
}: {
    className: string,
    name: string
    id: string
    type: string
    placeholder: string
    label?: string
    labelClass?: string,
    register:any
}) {
    return (
        <>
            <label className={labelClass} htmlFor={id}>{label}</label>
            <input
                type={type}
                className={className}
                id={id}
                placeholder={placeholder}
                {...register(name)}
            />
        </>
    )
}