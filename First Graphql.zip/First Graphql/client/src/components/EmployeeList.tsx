import { useNavigate } from "react-router-dom";
import Button from "./ul component/Button";
import { useEffect, useState } from "react";
import { toggleEmployee, getEmployeeNames, fetchEmpData } from "../services/employee.services.ts";
import { useMutation, useQuery } from "@apollo/client";

export default function EmployeeList() {
    const navigate = useNavigate()
    const [employeeData, setEmployeeData] = useState([])
    const [employeeNameList, setEmployeeNameList] = useState([])
    const { loading, error, data } = useQuery(fetchEmpData)
    console.log(loading, error, data);
    setEmployeeData(data)

    useEffect(() => {
        if (data) {
            console.log(data);
        }
    }, [data])

    function addEmployeeHandler() {
        navigate("/addEmployee")
    }
    return (
        <>
            <select name="" id="">
                <option value=""></option>
                {
                    employeeNameList.map((key: string, value: number) => (
                        <option value={key}>{key}</option>
                    ))
                }
            </select>
            <div className="flex flex-col">
                <div>
                    <h1 className="text-3xl uppercase tracking-widest text-center mt-5">Employee List</h1>
                </div>
                <div className="max-h-lvh h-[80vh] m-5">
                    <table className=" table-auto border border-black w-full text-l text-center overflow-auto">
                        <thead className="text-l tracking-widest bg-black border border-none text-white p-96">
                            <tr className="">
                                <th className="p-5">Employee Name</th>
                                <th className="p-5">Employee Age</th>
                                <th className="p-5">Employee DateOfBirth</th>
                                <th className="p-5">Employee Gender</th>
                                <th className="p-5">Employee Department</th>
                                <th className="p-1">Delete Employee</th>
                                <th className="p-1">Change Rh</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                employeeData.map((key: any, index: number) => (
                                    <tr key={index} className="border border-b-black hover:bg-slate-100 text-center">
                                        <td className="p-5">{key.Employee_Name}</td>
                                        <td className="p-5">{key.Employee_Age}</td>
                                        <td className="p-5">{key.Employee_DOB}</td>
                                        <td className="p-5">{key.Employee_Gender}</td>
                                        <td className="p-5">{key.Employee_Department}</td>
                                        {/* <td className="p-5 text-red-500 " onClick={() => deleteOrRevokeEmployee(key.Employee_Name)}> <span className="hover:cursor-pointer hover:underline">Delete</span> </td> */}
                                        <td className="p-5 text-blue-500"><span className="hover:underline hover:cursor-pointer">Change RH</span></td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
                <div className="text-center">
                    <Button
                        btnText="Create Employee"
                        className="border border-black p-2.5 rounded-lg w-96 tracking-widest uppercase hover:bg-[#323232] hover:text-white duration-500 hover:tracking-wider"
                        onClick={addEmployeeHandler}
                    />
                </div>
            </div>
        </>
    )
}