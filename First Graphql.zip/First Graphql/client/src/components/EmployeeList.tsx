import { useNavigate } from "react-router-dom";
import Button from "./ul component/Button";
import { gql } from "@apollo/client"
import { client } from '../Apollo Client/apolloClient.ts'

export default function EmployeeList() {
    client.query({
        query: gql`
  getAllEmployee {
    Employee_Active
    Employee_Age
    Employee_Associates {
      Employee_Name
      Employee_Address {
        Employee_City
      }
    }
    Employee_Department
    Employee_DOB
    Employee_Gender
    Employee_Name
    Employee_Rh {
      Employee_Name
    }
    Employee_Address {
      Employee_City
    }
    Employee_Contact {
      Employee_Email
    }
  }
      `
    }).then((res) => console.log("-=-==", res))
    const navigate = useNavigate()
    const data = [
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        }, {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        },
        {
            employeeName: "tapan",
            employeeAge: "29",
            employeeDateOfBirth: "31-03-2002",
            employeeGender: "Male",
            employeeDepartment: "HR"
        }
    ]
    function addEmployeeHandler() {
        navigate("/addEmployee")
    }
    return (
        <>
            <div className="flex flex-col">
                <div>
                    <h1 className="text-3xl uppercase tracking-widest text-center mt-5">Employee List</h1>
                </div>
                <div className="max-h-lvh h-[80vh] border border-black m-5  overflow-x-hidden">
                    <table className=" table-auto border border-black w-full text-l text-center overflow-auto">
                        <thead className="text-l tracking-widest bg-black border border-none text-white p-96">
                            <tr className="">
                                <th className="p-5">Employee Name</th>
                                <th className="p-5">Employee Age</th>
                                <th className="p-5">Employee DateOfBirth</th>
                                <th className="p-5">Employee Gender</th>
                                <th className="p-5">Employee Department</th>
                                <th className="p-1">Delete Employee</th>
                                <th className="p-1">Change Rh</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                data.map((key: any, index: number) => (
                                    <tr key={index} className="border border-b-black hover:bg-slate-100 text-center">
                                        <td className="p-5">{key.employeeName}</td>
                                        <td className="p-5">{key.employeeAge}</td>
                                        <td className="p-5">{key.employeeDateOfBirth}</td>
                                        <td className="p-5">{key.employeeGender}</td>
                                        <td className="p-5">{key.employeeDepartment}</td>
                                        <td className="p-5 text-red-500 underline hover:cursor-pointer hover:no-underline">Delete</td>
                                        <td className="p-5 text-blue-500 underline hover:cursor-pointer hover:no-underline">Change RH</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
                <div className="text-center">
                    <Button
                        btnText="Create Employee"
                        className="border border-black p-2.5 rounded-lg w-96 tracking-widest uppercase hover:bg-[#323232] hover:text-white duration-500 hover:tracking-wider"
                        onClick={addEmployeeHandler}
                    />
                </div>
            </div>
        </>
    )
}