import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import EmployeeList from './components/EmployeeList'
import CreateEmployee from './components/CreateEmployee'

function App() {

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<><EmployeeList /></>} />
          <Route path='/addEmployee' element={<><CreateEmployee /></>} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
