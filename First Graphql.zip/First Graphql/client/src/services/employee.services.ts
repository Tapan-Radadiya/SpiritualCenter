import { gql } from '@apollo/client'
import { client } from '../Apollo Client/apolloClient.ts'

const fetchEmpData = gql`
        query getAllEmployee {
            getAllEmployee {
                        Employee_Active,
                        Employee_Age,
                        Employee_Associates {
                            Employee_Name,
                            Employee_Address {
                                Employee_City
                            }
                        },
                        Employee_Department,
                        Employee_DOB,
                        Employee_Gender,
                        Employee_Name,
                        Employee_Rh {
                            Employee_Name
                        },
                        Employee_Address {
                            Employee_City
                        },
                        Employee_Contact {
                            Employee_Email
                        }
                    }
                }
`;

const toggleEmployee = gql`
query toggleEmployee($name:String){
    toggleEmployee(name:$name)
}
`


const getEmployeeNames = async () => {
    try {
        const { data } = await client.query({
            query: gql`
            query getEmployeeName{
                getEmployeeName{
                    Employee_Name
                }
            }`
        })
        return data
    } catch (error) {
        console.error("Error fetching employee data:", error);
    }
}


// const toggleEmployee = async (name: string) => {
//     try {
//         await client.query({
//             query: gql`
//             query toggleEmployee($name:String!){
//                 toggleEmployee(name:$name)
//             }
//             `,
//             variables: {
//                 name: name
//             }
//         })
//     } catch (error) {
//         console.error("Error fetching employee data:", error);
//     }
// }

const createEmployee = async (employeeData: any) => {
    console.log(employeeData);
    try {
        const { data } = await client.mutate({
            mutation: gql`
                mutation createEmployee($employeeAge:Int, $employeeCity: String, $employeeDepartment: Emp_Depart, $employeeDob: String,    $employeeEmail: String, $employeeGender: String, $employeeName: String, $employeeNumber1: String, $employeeNumber2: String, $employeePincode: String, $employeeRhName: String, $employeeState: String){
                    createEmployee(
                        Employee_Age: $employeeAge
                        Employee_City: $employeeCity
                        Employee_Department: $employeeDepartment
                        Employee_DOB: $employeeDob
                        Employee_Email: $employeeEmail
                        Employee_Gender: $employeeGender
                        Employee_Name: $employeeName
                        Employee_Number1: $employeeNumber1
                        Employee_Number2: $employeeNumber2
                        Employee_Pincode: $employeePincode
                        Employee_RhName: $employeeRhName
                        Employee_State: $employeeState
                    )
            }
            `,
            variables: {
                employeeAge: parseInt(employeeData.Employee_Age),
                employeeCity: employeeData.Employee_City,
                employeeDepartment: employeeData.employeeDepartment,
                employeeDob: employeeData.Employee_DOB,
                employeeEmail: employeeData.Employee_Email,
                employeeGender: employeeData.Employee_Gender,
                employeeName: employeeData.Employee_Name,
                employeeNumber1: employeeData.Employee_Number1,
                employeeNumber2: employeeData.Employee_Number2,
                employeePincode: employeeData.Employee_Pincode,
                // employeeRhName: employeeData.Employee_Pincode,
                employeeState: employeeData.Employee_State
            }
        })
        console.log("response -=-=", data);
    } catch (error) {
        console.error("Error fetching employee data:", error);
    }
}
export {
    toggleEmployee,
    createEmployee,
    getEmployeeNames,
    fetchEmpData
}