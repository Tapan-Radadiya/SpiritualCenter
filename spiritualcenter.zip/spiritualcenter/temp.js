const tempdata = {
    "Room1": [
        { userName: "John", Message: "Hello", Time: "21:23" },
        { userName: "John", Message: "Hello", Time: "21:23" },
        { userName: "John", Message: "Hello", Time: "21:23" }
    ],
    "Room2": [
        { userName: "John", Message: "Hello", Time: "21:23" },
        { userName: "John", Message: "Hello", Time: "21:23" },
        { userName: "John", Message: "Hello", Time: "21:23" }
    ],
    "Room3": [
        { userName: "John", Message: "Hello", Time: "21:23" },
        { userName: "John", Message: "Hello", Time: "21:23" },
        { userName: "John", Message: "Hello", Time: "21:23" }
    ]
}

function addMessage(roomName, userName, message, time) {
    if (!tempdata[roomName]) {
        tempdata[roomName] = [{ userName: userName, message: message, time: time }]
    }
    else{
        tempdata[roomName].push({userName:userName,message:message,time:time})
    }

}
addMessage("Room4","Tapan","Hello Everyone","21:3434")
addMessage("Room4","Wick","Hello Tapan","12:12")
console.log(tempdata);