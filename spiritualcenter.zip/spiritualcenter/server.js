import { createServer } from "http";
import { Server } from "socket.io";
import next from "next";
const PORT = 3000
const dev = process.env.PROD_ENV !== "production"
const app = next({ dev: dev, port: PORT, hostname: "localhost" })
const handler = app.getRequestHandler()

app.prepare().then(() => {
    const httpServer = createServer(handler)

    const io = new Server(httpServer)
    io.on("connection", (socket) => {
        io.emit("NEW_USER_CONNECTED")

        socket.on("NEW_USER_CONNECTED", () => {
            io.emit("UPDATE_NEW_USER_STATUS")
        })
        socket.on("BROADCAST_MESSAGE", ({ room_name, userName, message, time }, callback) => {
            io.emit("RECEIVE_BROADCAST_MESSAGE", { room_name, userName, message, time })
            callback({ success: true, time })
        })
        socket.on("JOIN_ROOM", (room_name) => {
            console.log("joining Room ", room_name);
            socket.join(room_name)
        })
        socket.on("PRIVATE_CHAT_MESSAGE", ({ message, room_name, time, userName }, callback) => {
            io.to(room_name).emit("PRIVATE_MESSAGE", { room_name, message, userName: userName, time })
            callback({ success: true, time: time })
        })
        socket.on("DISCONNECT_USER", () => {
            io.emit("USER_DISCONNETED")
        });
    })

    httpServer
        .once("error", (err) => {
            console.log(err);
            process.exit(1)
        })
        .listen(PORT, () => {
            console.log(`Listening On Port Number ${PORT}`);
        })
})