async function getAllDonationDataService() {
    const getDonationData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/getdonationdata`, {
        cache: "reload",
        credentials: "include",
        method: "GET"
    })
    return await getDonationData.json()
}

async function getUnpaidDonationDataService() {
    const getUnpaidDonationData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/getunpaiddonationdata`, {
        cache: "reload",
        credentials: "include",
        method: "GET"
    })
    return await getUnpaidDonationData.json()
}

async function createUserService(user_data: any) {
    const formdata = new FormData()
    formdata.append("First_Name", user_data.First_Name)
    formdata.append("Middle_Name", user_data.Middle_Name)
    formdata.append("Last_Name", user_data.Last_Name)
    formdata.append("Email_Id", user_data.Email_Id)
    formdata.append("Initiation_Date", user_data.Initiation_Date)
    formdata.append("Flat_Number", user_data.Flat_Number)
    formdata.append("Area", user_data.Area)
    formdata.append("City", user_data.City)
    formdata.append("State", user_data.State)
    formdata.append("PinCode", user_data.PinCode)
    if (user_data.ImageUrl.length != 0) {
        formdata.append("ImageUrl", user_data.ImageUrl[0])
    }
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/createUser`, {
        credentials: "include",
        method: "POST",
        body: formdata
    })
    return await sendReq.json()
}

async function editUserService(user_data: any, username: string) {
    var formdata = new FormData();
    formdata.append("First_Name", user_data.First_Name);
    formdata.append("Middle_Name", user_data.Middle_Name);
    formdata.append("Last_Name", user_data.Last_Name);
    formdata.append("Email_Id", user_data.Email_Id);
    formdata.append("Initiation_Date", user_data.Initiation_Date);
    formdata.append("Flat_Number", user_data.Flat_Number);
    formdata.append("Area", user_data.Area);
    formdata.append("City", user_data.City);
    formdata.append("State", user_data.State);
    formdata.append("PinCode", user_data.PinCode);
    if (user_data.ImageUrl.length != 0) {
        formdata.append("Image", user_data.ImageUrl[0]);
    }
    const updateData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/editUser/${username}`, {
        credentials: "include",
        body: formdata,
        method: "PUT",

    })
    return await updateData.json()
}
async function deleteUserService(userName: string) {
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/deleteUser/${userName}`, {
        method: "DELETE",
        credentials: "include"
    })
    return await sendReq.json()
}
async function getUserDataService(pageNumber: number) {
    const reqData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/userlist/${pageNumber}`, {
        cache: "reload",
        credentials: "include",
        method: "GET"
    })
    return await reqData.json()
}

async function getTotalPagesService() {
    const reqData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/getTotalPages`, {
        credentials: "include",
        method: "GET",
        cache:"reload"
    })
    return await reqData.json()
}

async function getDeletedUserDataService() {
    const reqData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/deletedUsers`, {
        credentials: "include",
        method: "GET",
        cache:"reload"
    })
    return await reqData.json()
}

async function revokeUserDataService(userName: string) {
    const revokeUser = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/rollbackUser/${userName}`, {
        credentials: "include",
        method: "PATCH"
    })
    return await revokeUser.json()
}
async function changeRecordsPerPageService(records: number) {

    const changeRecordsValue = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/updateRecordsPerPage`, {
        credentials: "include",
        body: JSON.stringify({ "RecordsValue": records }),
        method: "PATCH"
    })
    return await changeRecordsValue.json()
}
async function getCurrectRecordsPerPageService() {
    const currentRecordsPerPage = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/getrecordsperpage`, {
        credentials: "include",
        method: "GET",
        cache:"reload"
    })
    return await currentRecordsPerPage.json()
}
export {
    getAllDonationDataService,
    getUnpaidDonationDataService,
    createUserService,
    editUserService,
    deleteUserService,
    getUserDataService,
    getTotalPagesService,
    getDeletedUserDataService,
    revokeUserDataService,
    changeRecordsPerPageService,
    getCurrectRecordsPerPageService
}