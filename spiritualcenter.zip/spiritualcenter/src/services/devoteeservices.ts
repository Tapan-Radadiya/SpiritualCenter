async function getDonationDataService() {
    const getDonationData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/devotee/totaldonation`, {
        credentials: "include",
        method: "GET",
        cache: "reload"
    })
    return await getDonationData.json()
}

async function getDevpteeProfileService() {
    const profileData = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/devotee/getprofile`, {
        credentials: "include",
        method: "GET",
        cache:"reload"
    })
    return await profileData.json()
}

async function addDonationService(donationData: FormData) {
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/devotee/adddonation`, {
        credentials: "include",
        method: "POST",
        body: JSON.stringify(donationData),
    })
    return await sendReq.json()
}
export {
    getDonationDataService,
    getDevpteeProfileService,
    addDonationService
}