async function getAllUsersData() {
    const sendReq = await fetch("http://localhost:3000/api/chating/getAllUsersData", {
        credentials: "include",
        cache: "default",
        method: "GET"
    })
    return await sendReq.json()
}

async function getChatMessagesService(roomName: string) {
    const sendReq = await fetch(`http://localhost:3000/api/chating/getChatMessages/${roomName}`, {
        credentials: "include",
        cache: "default",
        method: "GET"
    })
    return await sendReq.json()
}

async function sendMessageService(messageData: { roomName: string, message: string, time: Date }) {
    console.log(messageData);    
    const sendReq = await fetch("http://localhost:3000/api/chating/sendMessage", {
        credentials: "include",
        method: "POST",
        body: JSON.stringify({ roomName: messageData.roomName, message: messageData.message, time: messageData.time })
    })
    return await sendReq.json()
}
export {
    getAllUsersData,
    getChatMessagesService,
    sendMessageService
}