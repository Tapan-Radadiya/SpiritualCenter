import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    ChatData: [],
    BroadCastData: [],
    UsersList: []
}

const chatingSlice = createSlice(
    {
        name: "ChatingSlice",
        initialState: initialState,
        reducers: {
            addChatMessage: (state: any, action: any) => {
                return {
                    ...state,
                    ChatData: [...state.ChatData, action.payload]
                }
            },
            addOldChatMessages: (state: any, action: any) => {
                return {
                    ...state,
                    ChatData: action.payload
                }
            },
            addOldBroadCastMessages: (state: any, action: any) => {
                return {
                    ...state,
                    BroadCastData: action.payload
                }
            },
            addBroadCastChatData: (state: any, action: any) => {
                return {
                    ...state,
                    BroadCastData: [...state.BroadCastData, action.payload]
                }
            },
            addUsers: (state: any, action: any) => {
                return {
                    ...state,
                    UsersList: action.payload
                }
            },
        }
    }
)
export const {
    addChatMessage,
    addUsers,
    addBroadCastChatData,
    addOldChatMessages,
    addOldBroadCastMessages
} = chatingSlice.actions

export default chatingSlice.reducer