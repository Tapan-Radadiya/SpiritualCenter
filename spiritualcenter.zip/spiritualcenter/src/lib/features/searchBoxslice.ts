import { createSlice } from "@reduxjs/toolkit";

const searchBoxSlice = createSlice(
    {
        name: "SearchBox",
        initialState: {
            searchValue: ""
        },
        reducers: {
            setSearchValue: (state: any, action: any) => {
                return {
                    ...state,
                    searchValue: action.payload
                }
            }
        }
    }
)
export const { setSearchValue } = searchBoxSlice.actions
export default searchBoxSlice.reducer