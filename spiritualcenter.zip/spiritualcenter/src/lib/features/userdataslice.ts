import { User_Interface } from "@/app/interfaces/userData.interface";
import { createSlice } from "@reduxjs/toolkit";

const userdataSlice = createSlice(
    {
        name: "AddData",
        initialState: {
            userData: [],
            userForm: {},
            userProfile: {},
            operationData: [],
            totalPages: [],
            deletedUserData: [],
            currentPageNumber: 1,
            currentRecordsPerPage: 3,
        },
        reducers: {
            addUserData: (state: any, action: any) => {
                return {
                    ...state,
                    userData: action.payload
                }
            },
            adduserForm: (state: any, action: any) => {
                return { ...state, userForm: action.payload }
            },
            addUserProfile: (state: any, action: any) => {
                return {
                    ...state,
                    userProfile: action.payload
                }
            },
            deleteUserState: (state: any, action: any) => {
                return {
                    ...state,
                    operationData: state.operationData.filter((elem: User_Interface) => elem.UserName == action.payload)
                }
            },
            dataOperation: (state: any, action: any) => {
                return {
                    ...state,
                    operationData: action.payload
                }
            },
            setPages: (state: any, action: any) => {
                return {
                    ...state,
                    totalPages: action.payload
                }
            },
            setDeletedUserData: (state: any, action: any) => {
                return {
                    ...state,
                    deletedUserData: action.payload
                }
            },
            setCurrentPage: (state: any, action: any) => {
                if (action.payload <= 0) {
                    return {
                        ...state,
                        currentPageNumber: 1
                    }
                }
                else {
                    return {
                        ...state,
                        currentPageNumber: action.payload
                    }
                }
            },
            setTotalRecordsValue: (state: any, action: any) => {
                if (action.payload <= 0) {
                    return {
                        ...state,
                        currentRecordsPerPage: 3
                    }
                }
                else {
                    return {
                        ...state, currentRecordsPerPage: action.payload
                    }
                }
            },
        }
    }
)
export const { addUserData,
    adduserForm,
    addUserProfile,
    dataOperation,
    setPages,
    setDeletedUserData,
    setCurrentPage,
    setTotalRecordsValue,
    deleteUserState,
} = userdataSlice.actions
export default userdataSlice.reducer