import { Dontaion_Interface } from "@/app/interfaces/donation.interface";
import mongoose from "mongoose";

const DonationSchema = new mongoose.Schema<Dontaion_Interface>({
    UserName: {
        type: String,
        required: [true, "UserName Is Required"]
    },
    Month: {
        type: Number,
        required: [true, "Month Is Required"],
        max: [12, "Invalid Month"],
        min: [0, "Invalid Month"]
    },
    Year: {
        type: Number,
        required: [true, "Year Is Required"]
    },
    Donation_Amount: {
        type: Number,
        required: [true, "Donation Amount Is Required"],
        min: [100, "Donation Amount Should Not Be Less Then 100"]
    }
}, { timestamps: true })

export const DonationData = mongoose.models.DonationData || mongoose.model("DonationData", DonationSchema)