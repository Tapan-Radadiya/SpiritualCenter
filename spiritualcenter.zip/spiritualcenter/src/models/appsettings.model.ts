import { App_Settings } from "@/app/interfaces/appsettings.interface";
import mongoose from "mongoose";

const AppSettingsSchema = new mongoose.Schema<App_Settings>({
    RecordsPerPage: {
        type: Number,
        required: [true, "Pages Per Records Is Required"],
        min: [0, "Pages Should Not Be Less Then 1"]
    }
}, { timestamps: true })

export const AppSettings = mongoose.models.AppSettings || mongoose.model("AppSettings", AppSettingsSchema)