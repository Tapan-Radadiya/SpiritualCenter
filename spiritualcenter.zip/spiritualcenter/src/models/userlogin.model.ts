import { Userlogin } from "@/app/interfaces/login.interface";
import mongoose from "mongoose";

const UserLoginSchema = new mongoose.Schema<Userlogin>({
    UserName: {
        type: String,
        required: [true, "UserName Is Required"]
    },
    Password: {
        type: String,
        required: [true, "Password Is Required"]
    },
    Role: {
        type: String,
        required: [true, "Role Is Required"]
    },
}, { timestamps: true })
export const UserLogin = mongoose.models.UserLogin || mongoose.model("UserLogin", UserLoginSchema)