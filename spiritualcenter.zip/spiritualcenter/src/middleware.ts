import { cookies } from "next/headers";
import { NextFetchEvent, NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken"
import authUser from "./utils/authUser";
import ApiResponse from "./utils/ApiResponse";
import { encryptData } from "./utils/bcryptFunc";
import { NextURL } from "next/dist/server/web/next-url";

export default async function middleware(req: NextRequest) {
    const userdata: any = cookies().get("userdata")
        
    if (!userdata) {              
        if (req.nextUrl.pathname.startsWith("/api")) {
            return NextResponse.json(ApiResponse(401, "Please Login"))
        }
        else if (req.nextUrl.pathname.startsWith("/login")) {
            return NextResponse.next()
        }
    }
    try {
        const { Role, Username }: any = jwt.decode(String(userdata.value))
        if (!Role || !Username) {
            throw new Error("Invalid JWT")
        }
        if (req.nextUrl.pathname.startsWith("/api")) {

            const requestHeader = new Headers(req.headers)
            requestHeader.set("Username", Username)

            // Api Protection
            if (req.nextUrl.pathname.startsWith("/api/admin")) {
                if (Role === "ADMIN") {
                    console.log(Username);

                    return NextResponse.next({ headers: requestHeader })
                }
                else {
                    return NextResponse.json(ApiResponse(401, "You Are Not Authorize For This"))
                }
            }

            if (req.nextUrl.pathname.startsWith("/api/devotee")) {
                if (Role === "DEVOTEE") {
                    return NextResponse.next({ headers: requestHeader })
                }
                else {
                    return NextResponse.json(ApiResponse(401, "You Are Not Authorize For This"))
                }
            }
            if (req.nextUrl.pathname.startsWith("/api/chating")) {
                return NextResponse.next({ headers: requestHeader })
            }
        }
        // Route Protection
        else {

            if (req.nextUrl.pathname == "/" || req.nextUrl.pathname == "/login" && Role == "ADMIN") {
                return NextResponse.redirect(new URL("/admin/userlist", req.url))
            }
            else if (req.nextUrl.pathname == "/" || req.nextUrl.pathname == "/login" && Role == "DEVOTEE") {
                return NextResponse.redirect(new URL("/devotee/mypayments", req.url))
            }
            else if (req.nextUrl.pathname.startsWith("/admin") && Role != "ADMIN") {
                return NextResponse.redirect(new URL("/devotee/mypayments", req.url))
            }
            else if (req.nextUrl.pathname.startsWith("/devotee") && Role != "DEVOTEE") {
                return NextResponse.redirect(new URL("/admin/userlist", req.url))
            }
        }
    } catch (error) {
        return NextResponse.redirect(new URL("/invalidvalue", req.url))
    }
}

export const config = {
    matcher: [
        "/login",
        "/admin/:path*",
        "/devotee/:path*",
        "/api/admin/:path*",
        "/api/devotee/:path*",
        "/api/chating/:path*"
    ]
}