'use server'
import { User } from "@/models/userdata.model";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import jwt from "jsonwebtoken"

export default async function userlogoutaction() {
    try {
        const cookie: any = cookies().get("userdata")
        const { Username }: any = jwt.decode(cookie.value)
        cookies().delete("userdata")
        await User.findOneAndUpdate({ UserName: Username }, { isOnline: false }) // Seting User Active Status to False
        redirect("/login")
    } catch (error) {
        cookies().delete("userdata")
        redirect("/login")
    }
}