import { useEffect } from "react";
import { ToastContainer } from "react-toastify";
import { socket } from "../socket"
import { toast } from "react-toastify"
export default function Home() {

  useEffect(() => {
alert("hey")    
    socket.on("RECEIVE_BROADCAST_MESSAGE", (data: any) => {
      toast.success("New Message In BroadCast")
    })
  }, [socket])
  return (
    <>

    </>
  );
}
