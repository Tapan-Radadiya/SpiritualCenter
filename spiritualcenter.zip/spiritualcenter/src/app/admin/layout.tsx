"use client"
import React, { useEffect } from "react";
import AdminHeader from "../components/Adminheader";
import { socket } from "@/socket";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
    useEffect(() => {
        socket.emit("NEW_USER_CONNECTED")
    }, [])
    return (
        <>
            <section>
                <AdminHeader />
                {children}
            </section>
        </>
    )
}