export default function LoadingPage() {
    return (
        <>
            <h1>Page Is Loading.......</h1>
        </>
    )
}