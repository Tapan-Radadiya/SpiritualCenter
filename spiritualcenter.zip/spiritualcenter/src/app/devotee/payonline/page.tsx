'use client'
import { Dontaion_Interface } from "@/app/interfaces/donation.interface"
import { addDonationService } from "@/services/devoteeservices"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { useForm } from "react-hook-form"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
const months = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]
export default function PayOnline() {
    const [btnStatus, setBtnStatus] = useState(false)
    const dispatch = useDispatch()
    const router = useRouter()
    const { register, handleSubmit, setError, formState: { errors } } = useForm<Dontaion_Interface>({ mode: "onBlur" })
    async function createPayment(donation_data: any) {
        setBtnStatus(true)
        toast.loading("Making Your Payment . . .")
        const { statusCode, message }: any = await addDonationService(donation_data)

        if (statusCode == 201) {
            toast.dismiss()
            toast.success(message)
            setBtnStatus(false)
            router.push("/devotee/mypayments")
        }
        else if (statusCode == 422 || statusCode == 409) {
            toast.dismiss()
            toast.warning(message)
        }
        else if (statusCode == 500) {
            toast.dismiss()
            toast.error(message)
        }
    }

    return (
        <>
            <div className="container">
                <div className="container">
                    <h1 className="text-center text-uppercase mt-5">Pay Online</h1>
                </div>
                <div className="container w-50 p-4 mt-5" style={{ boxShadow: "0px 0px 50px 1px", borderRadius: "15px" }}>
                    <form onSubmit={handleSubmit((data) => createPayment(data))}>
                        <div className="form-group mt-3">
                            <label htmlFor="Month" className="form-label">Select Month</label>
                            <select {...register("Month", { required: true })} id="month" className="form-select border border-dark">
                                <option value={""}>Select Month</option>
                                {
                                    months.map((key: any, _: any) => (
                                        <option value={key} key={key}>{key}</option>
                                    ))
                                }
                            </select>
                            {errors.Month && <span className="text-danger" id="monthErr">Month is required</span>}
                        </div>
                        <div className="form-group mt-3">
                            <label htmlFor="Year" className="form-label">Select Year</label>
                            <select {...register("Year", { required: true })} id="year" className="form-select border border-dark">
                                <option value={""}>Select Year</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                            </select>
                            {errors.Year && <span id="yearErr" className="text-danger">Year is required</span>}
                        </div>
                        <div className="form-group mt-3">
                            <label htmlFor="amount" className="form-label">Enter Amount</label>
                            <input type="number" {...register("Donation_Amount", {
                                required: { value: true, message: "Amount is required" },
                                // min: { value: Number(100), message: "Amount should not be less than 100" }
                            })} onChange={(e) => {
                                const { value } = e.target
                                if (Number(value) < 100) {
                                    setError("Donation_Amount", { message: "Amount should not be less than 100" })
                                }
                                else {
                                    setError("Donation_Amount", { message: "" })
                                }
                            }}
                                id="amount" className="form-control border border-dark" />
                            {errors.Donation_Amount && <span id="amountErr" className="text-danger">{errors.Donation_Amount?.message}</span>}
                        </div>
                        <div className="form-group mt-5 text-center">
                            {
                                btnStatus ?
                                    <button className="btn btn-success w-100 p-3" style={{ fontSize: "20px" }} disabled>
                                        <span className="spinner-border spinner-border-sm mr-2 "></span>
                                        <span>Creating Donation..</span>
                                    </button>
                                    :
                                    <button className="btn btn-success w-100 p-3" id="submit">Make Donation</button>
                            }
                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}