import { User } from "@/models/userdata.model";
import { UserLogin } from "@/models/userlogin.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { headers } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    try {
        console.log("UserData Request");

        const username = headers().get("username")
        const usersData: [{ UserName: string, FullName: string, ProfileImage: string }] = [{ UserName: "BroadCast", FullName: "BroadCast", ProfileImage: "SpiritualCenterLogo.jpeg" }]
        const allUserData = await UserLogin.aggregate(
            [
                {
                    $lookup: {
                        from: "users",
                        localField: "UserName",
                        foreignField: "UserName",
                        as: "result",
                    },
                },
                {
                    $addFields: {
                        result: {
                            $arrayElemAt: ["$result", 0],
                        },
                    },
                },
                {
                    $addFields: {
                        UserFullName: {
                            $concat: [
                                "$result.First_Name",
                                " ",
                                "$result.Last_Name",
                            ],
                        },
                        ProfileImage: "$result.ImageUrl",
                        isActive: "$result.isOnline"
                    },
                },
                {
                    $project: {
                        result: 0,
                    },
                },
            ]
        )
        allUserData.forEach((ele) => {
            if (ele.UserName != username) {
                const userList: any = {
                    UserName: ele.UserName,
                    FullName: ele.UserFullName || "admin",
                    ProfileImage: ele.ProfileImage || "whatsappDefaultProfile.jpeg",
                    ActiveStatus: ele.isActive
                }
                usersData.push(userList)
            }
        })
        return NextResponse.json(ApiResponse(200, "Data", usersData))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error Try After SomeTime"))
    }
}