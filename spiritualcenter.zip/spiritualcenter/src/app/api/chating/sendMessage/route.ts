import { ChatingData } from "@/models/chating.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import getTime from "@/utils/getCurrentTime";
import { headers } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting DB"))
    }
    try {
        const { message, roomName, time } = await req.json()
        const username = headers().get("username")
        if (!username) {
            return NextResponse.json(ApiResponse(401, "Invalid Session Please Login Again"))
        }
        if (!message) {
            return NextResponse.json(ApiResponse(422, "Message Should Not Be Empty"))
        }
        if (!roomName) {
            return NextResponse.json(ApiResponse(422, "Room Name Required"))
        }
        if (!time) {
            return NextResponse.json(ApiResponse(422, "Time Required"))
        }
        const sendMessage = await ChatingData.findOneAndUpdate({ RoomName: roomName },
            {
                $push: {
                    MessageData: {
                        userName: username,
                        message: message,
                        time: time
                    }
                }
            },
            { new: true }
        )
        if (sendMessage) {
            return NextResponse.json(ApiResponse(201, "Message sended"))
        }
        else {
            return NextResponse.json(ApiResponse(500, "Error Sending Message Try After SomeTime"))
        }
    } catch (error) {
        console.log(error);

        return NextResponse.json(ApiResponse(500, "Error Sending Message"))
    }
}
