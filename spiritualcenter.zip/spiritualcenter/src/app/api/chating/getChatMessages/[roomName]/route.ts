import { ChatingData } from "@/models/chating.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest, { params }: any) {

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(502, "Error Connecting With Server"))
    }

    try {
        const { roomName } = params

        const checkRoomExist = await ChatingData.findOne({ RoomName: roomName })

        if (checkRoomExist) {
            return NextResponse.json(ApiResponse(200, "Data Fetched", checkRoomExist.MessageData))
        }
        else {
            const createRoom = await ChatingData.create({ RoomName: roomName, MessageData: [] })
            return NextResponse.json(ApiResponse(201, "New Room Created", createRoom.MessageData))
        }
    } catch (error) {
        console.log(error);
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}