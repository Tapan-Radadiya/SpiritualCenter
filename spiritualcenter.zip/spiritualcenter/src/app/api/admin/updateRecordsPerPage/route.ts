import { AppSettings } from "@/models/appsettings.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import mongoose from "mongoose";
import { NextRequest,NextResponse } from "next/server";

export async function PATCH(req: NextRequest) {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Db"))
    }
    const { RecordsValue } = await req.json()
    if (!RecordsValue) {
        return NextResponse.json(ApiResponse(422, "Records Value Is Required"))
    }
    else if (Number(RecordsValue) <= 0) {
        return NextResponse.json(ApiResponse(409, "Record Value Should Not Be Less Then 1"))
    }

    try {
        const getId = await AppSettings.findOne({})
        if (!getId) {
            return NextResponse.json(ApiResponse(500, "Server Error Try After SomeTime"))
        }
        const updateValue = await AppSettings.findByIdAndUpdate(getId._id,
            { RecordsPerPage: RecordsValue }, { new: true })

        if (!updateValue) {
            return NextResponse.json(ApiResponse(500, "Error Updating App Setting Try After SomeTime"))
        }
        return NextResponse.json(ApiResponse(200, "Records Per Page Value Updated 👍"))

    } catch (error) {
        console.log(error);
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}