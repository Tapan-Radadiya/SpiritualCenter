import { AppSettings } from "@/models/appsettings.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextResponse } from "next/server";
export async function GET() {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    try {
        const getPages = await AppSettings.findOne({})
        if (!getPages) {
            return NextResponse.json(ApiResponse(500, "Error Try After SomeTime"))
        }
        const curRecordsPerPage = getPages.RecordsPerPage
        return NextResponse.json(ApiResponse(200, "Current Records Are 👍", { curRecordsPerPage }))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error Try After Some Time"))
    }
}