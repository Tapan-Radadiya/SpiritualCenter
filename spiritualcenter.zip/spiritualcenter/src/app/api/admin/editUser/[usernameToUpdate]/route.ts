import { User_Interface } from "@/app/interfaces/userData.interface";
import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { uploadImageToS3 } from "@/utils/imageUpload";
import { validateUser } from "@/utils/validateUserData";
import { cookies } from "next/headers";
import { NextRequest,NextResponse } from "next/server";

export async function PUT(req: NextRequest, { params }: any) {
    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connection With Server"))
    }
    const { usernameToUpdate } = params
    if (!usernameToUpdate) {
        return NextResponse.json(ApiResponse(422, "UserName Is Required"))
    }

    try {
        const findUser = await User.findOne({ UserName: usernameToUpdate })
        if (!findUser) {
            return NextResponse.json(ApiResponse(404, "No User Found With This UserName"))
        }
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }

    const formData: any = await req.formData()

    const data = Object.fromEntries(formData)
    const First_Name = data.First_Name
    const Middle_Name = data.Middle_Name
    const Last_Name = data.Last_Name
    const Email_Id = data.Email_Id
    const Initiation_Date = data.Initiation_Date
    const Flat_Number = data.Flat_Number
    const Area = data.Area
    const City = data.City
    const State = data.State
    const PinCode = data.PinCode
    const ImageData = data.Image ? data.Image : null
    const Password = data.Password
    
    const userType: User_Interface = {
        First_Name: First_Name,
        Middle_Name: Middle_Name,
        Last_Name: Last_Name,
        UserName: "",
        Email_Id: Email_Id,
        Initiation_Date: Initiation_Date,
        Flat_Number: Flat_Number,
        Area: Area,
        City: City,
        State: State,
        PinCode: PinCode,
        Status: "ACTIVE",
        Password: "password" || Password
    }
    const { statusCode, message }: any = validateUser(userType, ImageData)
    if (statusCode == 422) {
        return NextResponse.json(ApiResponse(statusCode, message))
    }
    else if (statusCode == 409) {
        return NextResponse.json(ApiResponse(statusCode, message))
    }

    try {
        const editUser = await User.findOneAndUpdate({ UserName: usernameToUpdate }, {
            First_Name,
            Middle_Name,
            Last_Name,
            Email_Id,
            Initiation_Date,
            Flat_Number,
            Area,
            City,
            State,
            PinCode,
            ImageUrl: ImageData != null ? await uploadImageToS3(ImageData, usernameToUpdate) : "",
            Status: "ACTIVE",
        })
        if (!editUser) {
            return NextResponse.json(ApiResponse(500, "Error Updating User Try After SomeTime"))
        }
        return NextResponse.json(ApiResponse(200, "User Updated 👍"))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}