import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies } from "next/headers";
import { NextRequest,NextResponse } from "next/server";

export async function GET(req: NextRequest) {
    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    try {
        const unpaidDonationData = await User.aggregate(
            [
                {
                    $lookup: {
                        from: "donationdatas",
                        localField: "UserName",
                        foreignField: "UserName",
                        as: "result",
                    },
                },
                {
                    $project: {
                        data: {
                            $filter: {
                                input: "$result",
                                as: "data",
                                cond: {
                                    $ne: ["$$data.Month", new Date().getMonth() - 1],
                                },
                            },
                        },
                        UserName: 1,
                        First_Name: 1,
                        Middle_Name: 1,
                        Last_Name: 1,
                        Email_Id: 1,
                        Flat_Number: 1,
                        Area: 1,
                        City: 1,
                        State: 1,
                        PinCode: 1,
                        Initiation_Date: 1,
                    },
                },
                {
                    $project: {
                        data: 0
                    }
                }
            ]
        )
        return NextResponse.json(ApiResponse(200, "Data Fetched", unpaidDonationData))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}