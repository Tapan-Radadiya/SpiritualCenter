import ApiResponse from "@/utils/ApiResponse";
import { NextRequest,NextResponse } from "next/server";
import { connectDb } from "@/config/connectDb";
import { DonationData } from "@/models/donationdata.model";
import authUser from "@/utils/authUser";
import { cookies } from "next/headers";

export async function GET(req: NextRequest) {

    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }

    try {
        const donationData: any = await DonationData.aggregate(
            [
                {
                    $group: {
                        _id: { UserName: "$UserName", Month: "$Month", Year: "$Year" },
                        totalDonation: {
                            $sum: "$Donation_Amount"
                        }
                    }
                },
                {
                    $sort: {
                        totalDonation: 1
                    }
                }
            ]
        )
        if (donationData.length == 0) {
            return NextResponse.json(ApiResponse(200, "No Donation Data Found 👍",donationData))
        }
        return NextResponse.json(ApiResponse(200, "Data Fetched 👍", donationData))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}