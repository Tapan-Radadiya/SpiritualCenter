import { AppSettings } from "@/models/appsettings.model";
import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
    
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    const pageLimit = await AppSettings.findOne({})
    const limit = pageLimit.RecordsPerPage
    const pageArray: number[] = []
    const totalDocuments = await User.find({ Status: "ACTIVE" })
    const totalPages = Math.ceil(totalDocuments.length / Number(limit))

    for (let i = 1; i <= totalPages; i++) {
        pageArray.push(i)
    }

    if (pageArray.length > 1) {
        return NextResponse.json(ApiResponse(200, "PageNumber Fetched", pageArray))
    }
    else {
        return NextResponse.json(ApiResponse(200, "PageNumber Fetched", []))
    }
}