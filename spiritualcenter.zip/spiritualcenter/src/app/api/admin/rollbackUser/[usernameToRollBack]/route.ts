import { User } from "@/models/userdata.model"
import { UserLogin } from "@/models/userlogin.model"
import ApiResponse from "@/utils/ApiResponse"
import authUser from "@/utils/authUser"
import { connectDb } from "@/config/connectDb"
import { cookies } from "next/headers"
import { NextRequest,NextResponse } from "next/server"

export async function PATCH(req: NextRequest, { params }: any) {
    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    const { usernameToRollBack } = params
    if (!usernameToRollBack) {
        return NextResponse.json(ApiResponse(422, "UserName Is Required"))
    }

    try {
        const updateUser = await User.findOneAndUpdate({ UserName: usernameToRollBack }, { Status: "ACTIVE" }, { new: true })
        const addCredentials = await UserLogin.create({
            UserName: updateUser.UserName,
            Password: updateUser.Password,
            Role: "DEVOTEE"
        })
        if (!updateUser || !addCredentials) {
            return NextResponse.json(ApiResponse(500, "Error Revoking User"))
        }
        return NextResponse.json(ApiResponse(200, "User Revoked 👍"))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}