import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies } from "next/headers";
import { NextRequest,NextResponse } from "next/server";
import { headers } from "next/headers";
import { AppSettings } from "@/models/appsettings.model";

export async function GET(req: NextRequest, { params }: any) {
    const userName = headers().get("username")
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Server"))
    }
    const { pagenumber } = params

    try {

        const pageLimit = await AppSettings.findOne({})
        const limit = pageLimit.RecordsPerPage
        const skip = (pagenumber - 1) * limit

        const userData: any = await User.find({ Status: "ACTIVE" }).limit(limit).skip(skip)
        if (userData.length == 0) {
            return NextResponse.json(ApiResponse(200, "Empty User Data 👍", userData))
        }
        return NextResponse.json(ApiResponse(200, "Data Fetched 👍", userData))
    } catch (error) {
        console.log(error)
        return NextResponse.json(ApiResponse(500, "Error Connecting With Server", error))
    }
}