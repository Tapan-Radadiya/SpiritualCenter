import { User } from "@/models/userdata.model";
import { UserLogin } from "@/models/userlogin.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

export async function DELETE(req: NextRequest, { params }: any) {
    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Host"))
    }
    const { usernameToUpdate } = params
    if (!usernameToUpdate) {
        return NextResponse.json(ApiResponse(422, "Username Is Required"))
    }

    try {
        const removeUser = await User.findOneAndUpdate({ UserName: usernameToUpdate }, { Status: "INACTIVE" })
        const removeCredentials = await UserLogin.findOneAndDelete({ UserName: usernameToUpdate })
        if (!removeUser || !removeCredentials) {
            return NextResponse.json(ApiResponse(404, "User Not Found"))
        }
        return NextResponse.json(ApiResponse(200, "User Deleted 👍"))

    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}