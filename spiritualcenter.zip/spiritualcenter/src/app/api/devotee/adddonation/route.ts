import { DonationData } from "@/models/donationdata.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextRequest,NextResponse } from "next/server";
import { headers } from "next/headers";

export async function POST(req: NextRequest) {

    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Host"))
    }
    const userName = headers().get("username")
    const {
        Month,
        Year,
        Donation_Amount,
    } = await req.json()
    if (!Month) {
        return NextResponse.json(ApiResponse(422, "Month Is Required"))
    }
    else if (Number(Month) <= 0 || Number(Month) >= 13) {
        return NextResponse.json(ApiResponse(409, "Please Provide Valid Month"))
    }
    if (!Year) {
        return NextResponse.json(ApiResponse(422, "Year Is Required"))
    }
    else if (Year.toString().length != 4) {
        return NextResponse.json(ApiResponse(409, "Please Provide Valid Year"))
    }
    if (!Donation_Amount) {
        return NextResponse.json(ApiResponse(422, "Amount Is Required"))
    }
    else if (Number(Donation_Amount) < 100) {
        return NextResponse.json(ApiResponse(422, "Amount Should Not Be Less Then 100"))
    }
    try {
        const addDonation = await DonationData.create({
            UserName: userName,
            Month: Number(Month),
            Year: Number(Year),
            Donation_Amount: Number(Donation_Amount)
        })
        if (!addDonation) {
            return NextResponse.json(ApiResponse(500, "Error Making Donation Try After SomeTime"))
        }
        return NextResponse.json(ApiResponse(201, "Thank Your For Your Donation ❤️ ❤️ ❤️"))
    } catch (error) {
        console.log(error)
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}