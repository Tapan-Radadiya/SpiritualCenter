import { DonationData } from "@/models/donationdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies, headers } from "next/headers";
import { NextRequest,NextResponse } from "next/server";

export async function GET(req: NextRequest) {
    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Host"))
    }
    const username = headers().get("username")

    if (!username) {
        return NextResponse.json(ApiResponse(409, "UserName Required"))
    }
    try {
        const getData = await DonationData.aggregate(
            [
                {
                    $match: {
                        UserName: username
                    }
                },
                {
                    $group: {
                        _id: { UserName: "$UserName", Month: "$Month", Year: "$Year" },
                        totalDonation: {
                            $sum: "$Donation_Amount"
                        }
                    }
                },
                {
                    $sort: {
                        totalDonation: 1
                    }
                }
            ]
        )

        if (getData.length == 0) {
            return NextResponse.json(ApiResponse(200, "No Data Found", getData))
        }
        return NextResponse.json(ApiResponse(200, "Data Fetched", getData))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}