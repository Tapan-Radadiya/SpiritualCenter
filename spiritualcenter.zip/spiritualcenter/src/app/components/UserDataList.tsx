import { getChatMessagesService } from "@/services/chatingservices"
import { addOldBroadCastMessages, addOldChatMessages } from "@/lib/features/chatingSlice"
import Image from "next/image"
import { useDispatch } from "react-redux"
import { toast } from "react-toastify"
import { socket } from "@/socket"
import style from "../css/chatCss.module.css"

export default function UserDataList({ userListData, setCurRoom, curUser, setCurChat }: any) {
    const dispatch = useDispatch()

    async function changeRoom(chatUserName: string, ProfileImage: string, roomName: any) {
        setCurChat({ userName: chatUserName, ProfileImage: ProfileImage })
        if (roomName == "BroadCast") {
            const { statusCode, message, data } = await getChatMessagesService(roomName)
            if (statusCode == 200 || statusCode == 201) {
                setCurRoom(roomName)
                dispatch(addOldBroadCastMessages(data))
            }
            else {
                toast.error(message)

            }
        }
        else {
            const privateChatRoomName: any = (roomName.toUpperCase() + " " + curUser.toUpperCase()).split(" ").sort().join("")
            setCurRoom(privateChatRoomName)
            socket.emit("JOIN_ROOM", privateChatRoomName)

            const { statusCode, message, data } = await getChatMessagesService(privateChatRoomName)
            if (statusCode == 200 || statusCode == 201) {
                dispatch(addOldChatMessages(data))
            }
            else {
                toast.error(message)
            }
        }
    }
    return (
        <div className={`${style.userDataList}`}>
            {
                userListData.map((key: any, value: any) => (
                    <div className="p-3 container border border-secondary mb-2 row ml-2" style={{ borderRadius: "10px" }} key={value} onClick={() => changeRoom(key.FullName, key.ProfileImage, key.UserName)}>
                        <div className="col-md-2">
                            {/* Default Image */}
                            {
                                key.ProfileImage !== "" ?
                                    < Image
                                        alt="user Profile Image"
                                        src={`${process.env.NEXT_PUBLIC_S3_URL}/${key.ProfileImage}`}
                                        width={50}
                                        height={50}
                                        style={{ border: "1px solid black", borderRadius: "50%", padding: "3px" }}
                                    />
                                    : < Image
                                        alt="Default user Profile Image"
                                        src={`${process.env.NEXT_PUBLIC_S3_URL}/whatsappDefaultProfile.jpeg`}
                                        width={50}
                                        height={50}
                                        style={{ border: "1px solid black", borderRadius: "50%" }}
                                    />
                            }

                        </div>
                        <p className="col-md" style={{ fontSize: "20px", color: "#f9fafa" }}>{key.FullName}</p>
                        {
                            key.FullName != "BroadCast" && key.FullName != "admin" ?
                                key.ActiveStatus ?
                                    <p className="col-md-2" style={{ color: "#1ca053" }}>Online</p>
                                    :
                                    <p className="col-md-2 text-danger">Offline</p> : <></>

                        }
                    </div>
                ))
            }
        </div>
    )
}