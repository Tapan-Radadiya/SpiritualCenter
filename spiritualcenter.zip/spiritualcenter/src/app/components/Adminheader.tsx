'use client'
import { useRouter } from "next/navigation"
import style from "../css/adminheader.module.css"
import userlogoutaction from "@/actions/userlogoutaction"
import { socket } from "@/socket"
import { useState } from "react"

export default function AdminHeader() {
    const router = useRouter()

    function logoutUser() {
        setTimeout(() => {
            socket.emit("DISCONNECT_USER")
        }, 2000)
        userlogoutaction()
    }

    return (
        <>
            <div className="container-fluid">
                <div className=" p-2 bg-dark row user-select-none">
                    <div className="m-1 col-md-2"><p style={{ fontSize: "20px" }} className="text-light text-center mt-3 user-select-none">SPIRITUAL CENTER</p></div>
                    <div className="m-1 col-md-3"></div>
                    <div className={`m-1 col-md ${style.adminNavBar}`} onClick={() => router.push("/admin/chat")}><p style={{ fontSize: "20px" }} className="text-light text-center mt-3">Chating</p></div>
                    <div className={`m-1 col-md ${style.adminNavBar}`} onClick={() => router.push("/admin/appsettings")}><p style={{ fontSize: "20px" }} className="text-light text-center mt-3">App Settings </p></div>
                    <div className={`m-1 col-md ${style.adminNavBar}`} onClick={() => router.push("/admin/userlist")}><p style={{ fontSize: "20px" }} className="text-light text-center mt-3">Home Page</p></div>
                    <div className={`m-1 col-md ${style.adminNavBar}`} onClick={() => router.push("/admin/createuser")}><p id="userCreateBtn" style={{ fontSize: "20px" }} className="text-light text-center mt-3">User Create <i className="fa-solid fa-user"></i></p></div>
                    <div className={`m-1 col-md ${style.adminNavBar}`} onClick={() => router.push("/admin/donations")}><p id="donationBtn" style={{ fontSize: "20px" }} className="text-light text-center mt-3">Donation <i className="fa-solid fa-hand-holding-dollar"></i></p></div>
                    <div className={`m-1 col-md ${style.adminNavBar}`} onClick={() => logoutUser()}><p id="logoutBtn" style={{ fontSize: "20px" }} className="text-light text-center mt-3">Logout &nbsp;<i className="fa fa-right-from-bracket"></i></p></div>
                </div>
            </div>
        </>
    )
}