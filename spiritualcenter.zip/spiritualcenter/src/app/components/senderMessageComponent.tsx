import getTime from "@/utils/getCurrentTime";

export default function SenderMessageComponent({ message, time }: { message: string, time: Date }) {
    return (
        <div className="container d-flex justify-content-end">
            <div className="row mt-3" style={{ backgroundColor: "#144d37", borderRadius: "20px", maxWidth: "800px", minWidth: "200px" }}>
                <p className="col-md text-light mt-3" style={{ overflowWrap: "break-word" }}>
                    {message}
                </p>
                <div className="col-md d-flex mb-2 mt-3 " >
                    <small className="mt-4 text-light text-light">{getTime(time)}</small>
                    <i className="fa fa-solid fa-check-double ml-2 mt-4" style={{ color: "#74C0FC" }}></i>
                </div>
            </div>
        </div>
    )
}