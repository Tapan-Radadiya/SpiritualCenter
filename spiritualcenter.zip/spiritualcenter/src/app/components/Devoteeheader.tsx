'use client'
import style from "../css/devoteeheader.module.css"
import userlogoutaction from "@/actions/userlogoutaction"
import { socket } from "@/socket"
import { redirect, useRouter } from "next/navigation"
import { useState } from "react"

export default function DevoteeHeader() {
    const router = useRouter()
    function logoutUser() {
        setTimeout(() => {
            socket.emit("DISCONNECT_USER")
        }, 2000)
        userlogoutaction()

    }
    return (
        <>
            <div className="container-fluid">
                <div className="row bg-dark user-select-none p-3">
                    <div className="m-1 col-md-2"><p className="text-light mt-3 text-center user-select-none text-uppercase" style={{ fontSize: "20px" }}>spiritual center</p></div>
                    <div className="m-1 col-md-4"></div>
                    <div className={`m-1 col-md ${style.devoteeNavBar}`} onClick={() => router.push("/devotee/chat")}><p style={{ fontSize: "20px" }} className="text-light text-center mt-3">Chating</p></div>
                    <div className={`m-1 col-md ${style.devoteeNavBar}`} onClick={() => router.push("/devotee/mypayments")}><p style={{ fontSize: "20px" }} id="myPaymentsBtn" className="text-light mt-3 text-center">My Payments $</p></div>
                    <div className={`m-1 col-md ${style.devoteeNavBar}`} onClick={() => router.push("/devotee/profile")}><p style={{ fontSize: "20px" }} id="profileBtn" className="text-light mt-3 text-center">Profile <i className="fa-solid fa-user"></i></p></div>
                    <div className={`m-1 col-md ${style.devoteeNavBar}`} onClick={() => router.push("/devotee/payonline")}><p style={{ fontSize: "20px" }} id="payOnlineBtn" className="text-light mt-3 text-center">Pay Online <i className="fa-solid fa-credit-card"></i></p></div>
                    <div className={`m-1 col-md ${style.devoteeNavBar}`} onClick={() => logoutUser()}><p style={{ fontSize: "20px" }} id="logoutBtn" className="text-light mt-3 text-center">Logout <i className="fa-solid fa-right-from-bracket"></i></p></div>
                </div>
            </div>
        </>
    )
}