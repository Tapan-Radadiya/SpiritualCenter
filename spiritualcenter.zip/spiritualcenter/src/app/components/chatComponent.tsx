'use client'
import { addBroadCastChatData, addChatMessage, addUsers } from "@/lib/features/chatingSlice"
import { getAllUsersData, sendMessageService } from "@/services/chatingservices"
import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { socket } from "../../socket"
import Cookies from "js-cookie"
import jwt from "jsonwebtoken"
import Image from "next/image"
import defaultImage from "../../../public/download (2).jpeg"
import style from "../css/chatCss.module.css"
import chatImage from "../../../public/Chatting-amico.png"
import { toast } from "react-toastify"
import UserDataList from "./UserDataList"
import SenderMessageComponent from "./senderMessageComponent"
import ReceiverMessageComponent from "./receiverMessageComponent"

function getUserName() {
    const { Username }: any = jwt.decode(Cookies.get("userdata") || "")
    return Username
}
export default function ChatComponent() {

    const dispatch = useDispatch()
    // use States
    const [userMessage, setUserMessage] = useState<string>("")
    const [curRoom, setCurRoom] = useState("")
    const [curUser, setCurUser] = useState<any>()
    const [curChat, setCurChat] = useState({ userName: "", ProfileImage: "" })

    // use Selectors
    const userListData = useSelector((state: any) => state.chatingSlice.UsersList)
    const messages = useSelector((state: any) => state.chatingSlice.ChatData)
    const broadCastMessage = useSelector((state: any) => state.chatingSlice.BroadCastData)

    useEffect(() => {
        fetchUsersData()
        socket.on("UPDATE_NEW_USER_STATUS", () => {
            fetchUsersData()
        })

        socket.on("USER_DISCONNETED", () => {
            fetchUsersData()
        })

        socket.on("RECEIVE_BROADCAST_MESSAGE", (data: any) => {
            dispatch(addBroadCastChatData(data))
        })

        socket.on("PRIVATE_MESSAGE", (data) => {
            dispatch(addChatMessage(data))
        })

        setCurUser(getUserName())

        return () => {
            socket.off("RECEIVE_BROADCAST_MESSAGE")
            socket.off("PRIVATE_MESSAGE")
            socket.off("UPDATE_NEW_USER_STATUS")
            socket.off("USER_DISCONNETED")
        }
    }, [])

    async function fetchUsersData() {
        const { statusCode, message, data } = await getAllUsersData()
        if (statusCode == 200) {
            dispatch(addUsers(data))
        }
    }
    function sendMessage() {
        if (userMessage != "") {
            if (curRoom == "BroadCast") {
                socket.emit("BROADCAST_MESSAGE", { room_name: curRoom, userName: curUser, message: userMessage, time: new Date() }, async (response: { success: boolean, time: Date }) => {
                    if (response.success) {
                        await sendMessageService({ roomName: curRoom, message: userMessage, time: response.time }) // Storing Message Data In DB
                    }
                })
            }
            else {
                socket.emit("PRIVATE_CHAT_MESSAGE", { room_name: curRoom, message: userMessage, userName: curUser, time: new Date() }, async (response: { success: boolean, time: Date }) => {
                    if (response.success) {
                        await sendMessageService({ roomName: curRoom, message: userMessage, time: response.time })// Storing Message Data In DB
                    }
                })
            }
        }
        setUserMessage("")
    }
    return (
        <>
            <div className={`container-fluid p-2 ${style.mainChatDiv}`} style={{ backgroundColor: "#1d1e1e", height: "100vh", overflowX: "hidden" }}>
                <div className="row">
                    <div className="col-md-3 p-3" >
                        <div className="container">
                            <div className="form-group">
                                <input type="text" className="form-control border border-dark" placeholder="Search User" style={{ borderRadius: "30px" }} />
                            </div>
                        </div>
                        {
                            <UserDataList
                                userListData={userListData}
                                setCurRoom={setCurRoom}
                                curUser={curUser}
                                setCurChat={setCurChat}
                            />
                        }
                    </div>
                    {
                        curRoom != "" ?
                            <div className="col-md p-3">
                                <div className={style.chatDiv} >
                                    <div className="border border-dark p-2 rounded ">
                                        <div className="d-flex">
                                            <Image
                                                alt="user Profile Image"
                                                src={curChat.ProfileImage ? `${process.env.NEXT_PUBLIC_S3_URL}/${curChat.ProfileImage}` : defaultImage}
                                                width={50}
                                                height={50}
                                                style={{ border: "1px solid black", borderRadius: "50%", padding: "3px" }}
                                            />
                                            <h4 className="ml-2 mt-2" style={{ color: "#f9fafa" }}>{curChat.userName}</h4>
                                        </div>
                                    </div>
                                    <div className={`${style.chatMsgDisplayDiv}`}>
                                        {
                                            curRoom == "BroadCast" ?
                                                broadCastMessage.map((key: any, value: any) => (
                                                    key.userName == curUser ?
                                                        <SenderMessageComponent
                                                            message={key.message}
                                                            time={key.time}
                                                            key={value}
                                                        /> :
                                                        <ReceiverMessageComponent
                                                            message={key.message}
                                                            time={key.time}
                                                            key={value}
                                                        />
                                                ))
                                                :
                                                messages.map((key: any, value: any) => (
                                                    key.userName == curUser ?
                                                        <SenderMessageComponent
                                                            message={key.message}
                                                            key={value}
                                                            time={key.time}
                                                        /> :

                                                        <ReceiverMessageComponent
                                                            message={key.message}
                                                            key={value}
                                                            time={key.time}
                                                        />
                                                ))
                                        }
                                    </div>
                                    <div className="container mt-3" >
                                        {
                                            curRoom == "BroadCast" && curUser != "admin" ?
                                                <div className="container">
                                                    <p className="display-6 text-light text-center" style={{ fontSize: "23px" }}>Only <span style={{ color: "#1ca053" }}> Admin's </span>Can Send Message. . .</p>
                                                </div> :
                                                <div className="form-group d-flex justify-content-center ">
                                                    <input type="text" style={{ backgroundColor: "#3a3b3b", color: "white" }}
                                                        className={`form-control border border-dark mr-3 w-100 ${style.sendMessage}`} value={userMessage} onChange={(e) => setUserMessage(e.target.value)} placeholder="Enter A Message" />
                                                    {
                                                        userMessage != "" ?
                                                            <button className="btn" style={{ backgroundColor: "#1ca053", fontSize: "", borderRadius: "50%" }} onClick={() => sendMessage()}><i className="fa fa-regular fa-paper-plane" style={{ color: "white" }}></i></button>
                                                            :
                                                            <button className="btn" style={{ backgroundColor: "#1ca053", fontSize: "", borderRadius: "50%" }} disabled><i className="fa fa-regular fa-paper-plane" style={{ color: "white" }}></i></button>
                                                    }
                                                </div>
                                        }
                                    </div>
                                </div>

                            </div> :
                            <div className="col-md">
                                <div className="text-center p-5 mb-5 mt-5" style={{ borderRadius: "20px", backgroundColor: "#2f393f" }}>
                                    <Image
                                        alt="Chating Image"
                                        src={chatImage}
                                        style={{ width: "40%", height: "40%" }}
                                        className="mt-5 mb-5"
                                    />
                                    <p className="display-6 text-center" style={{ color: "#f9fafa" }}>Welcome To Spiritual Center Chat Section</p>
                                </div>
                            </div>
                    }
                </div>
            </div>
        </>
    )
}