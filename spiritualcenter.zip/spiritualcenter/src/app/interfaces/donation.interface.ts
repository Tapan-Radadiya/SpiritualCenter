export interface Dontaion_Interface {
    UserName: String
    Month: String,
    Year: String
    Donation_Amount: Number
}