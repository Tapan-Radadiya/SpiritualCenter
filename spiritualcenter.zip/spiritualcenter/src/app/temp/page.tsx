export default function Temp() {
    return (
        <>
            <div className="container d-flex justify-content-end" >
                <div className="row mt-5" style={{ backgroundColor: "#144d37", borderRadius: "20px" }}>
                    <p className="col-md-10 text-light mt-3">
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque, deserunt!
                    </p>
                    <p className="col-md-2 mt-4 text-light">Time <i className="fa fa-solid fa-check-double ml-2" style={{ color: "#74C0FC" }}></i></p>
                </div>
            </div>
        </>
    )
}