'use server'
import jwt from 'jsonwebtoken'

export default async function authUser(jwtToken: any, allowedRole: string[]) {
    let isAllowed: boolean = false

    const { Username, Role }: any = jwt.verify(`${jwtToken}`, `${process.env.JWT_SECRET_KEY}`)
    allowedRole.forEach((ele: string) => {
        if (Role == ele) {
            isAllowed = true
        }
    })
    if (!isAllowed) {
        return false
    }
    else {
        return Username
    }
}