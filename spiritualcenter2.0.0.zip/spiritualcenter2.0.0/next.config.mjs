import withBundleAnalyzer from "@next/bundle-analyzer"
const bundleAnalyzer = withBundleAnalyzer({
    enabled: process.env.ANALYZE === 'true',
})

/** @type {import('next').NextConfig} */

/** @type {import('next').NextConfig} */
const nextConfig = {
    // eslint:{
    //     ignoreDuringBuilds:true
    // },
    redirects: async () => {
        return [
            {
                source: "/",
                destination: "/login",
                permanent: false
            }
        ]
    },
    images: {
        remotePatterns: [
            {
                protocol: "https",
                hostname: "spiritualcenterbucket.s3.ap-south-1.amazonaws.com",
            }
        ]
    },
    reactStrictMode:false
};
export default bundleAnalyzer(nextConfig)
// export default nextConfig;
