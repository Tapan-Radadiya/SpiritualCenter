import { User_Interface } from "@/app/interfaces/userData.interface"
import { connectDb } from "@/config/connectDb"
import { createUserServiceApi, deleteUserServiceApi, editUserServiceApi, getDonationDataServiceApi, getUnpaidDonationDataServiceApi, getUserListServiceApi, rollbackUserServiceApi, updateRecordsPerPageServiceApi } from "@/services/Api Services/adminservices"
import { getAllUsersDataServiceApi } from "@/services/Api Services/chatingservice"
import { addDonationServiceApi, getTotalDonationServiceApi, getUserProfileServiceApi } from "@/services/Api Services/devoteeservices"
import { createUserService } from "@/services/adminservices"
import { render } from "@testing-library/react"

const userData: User_Interface = {
    First_Name: "John",
    Middle_Name: "Doee",
    Last_Name: "Oggy",
    Email_Id: "john@gmail.com",
    Initiation_Date: new Date("6/5/2024"),
    Flat_Number: 123,
    Area: "Bapunagar",
    City: "Ahmedabad",
    State: "Gujarat",
    PinCode: "382350",
    UserName: "2024-Jo-Og-06",
    Password: "",
    Status: "",
    isOnline: false
}
const ImageData = null
const donationData = {
    userName: "2024-Jo-Og-06",
    Month: 7,
    Year: 2024,
    Donation_Amount: 159
}
describe("Backend Api Testing", () => {
    test("Add Valid Data", async () => {
        await connectDb()
        const { statusCode, message } = await createUserServiceApi(userData, ImageData)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 201, message: "User Registered Successfully 👍" })
    })
    test("Get User Donation Data Before Adding Donation", async () => {
        await connectDb()
        const { statusCode, message } = await getTotalDonationServiceApi("2024-Jo-Og-06")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "No Data Found" })
    })
    test("Add Donation Before Initiation Date With Month", async () => {
        await connectDb()
        const { statusCode, message } = await addDonationServiceApi({ ...donationData, Month: 3 })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Donation Date Can Not Be Of Past Of Your Initiation Date" })
    })
    test("Add Donation Before Initiation Date With Year", async () => {
        await connectDb()
        const { statusCode, message } = await addDonationServiceApi({ ...donationData, Year: 2023 })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Donation Date Can Not Be Of Past Of Your Initiation Date" })
    })

    test("Add Donation After Current Date With Month", async () => {
        await connectDb()
        const { statusCode, message } = await addDonationServiceApi({ ...donationData, Month: 10 })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Donation Date Can Not Be Of Future Of Your Initiation Date" })
    })
    test("Add Donation After Current Date With Year", async () => {
        await connectDb()
        const { statusCode, message } = await addDonationServiceApi({ ...donationData, Year: 2025 })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Donation Date Can Not Be Of Future Of Your Initiation Date" })
    })

    test("Add Donation Before Initiation Date With Month And Year", async () => {
        await connectDb()
        const { statusCode, message } = await addDonationServiceApi({ ...donationData, Month: 4, Year: 2023 })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Donation Date Can Not Be Of Past Of Your Initiation Date" })
    })
    test("Add Donation After Current Date With Month And Year", async () => {
        await connectDb()
        const { statusCode, message } = await addDonationServiceApi({ ...donationData, Month: 10, Year: 2024 })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Donation Date Can Not Be Of Future Of Your Initiation Date" })
    })

    // test("Add Donation Amount Less Then 100", async () => {
    //     await connectDb()
    //     const { statusCode, message } = await addDonationServiceApi({ ...donationData, Donation_Amount: 99 })
    //     expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "Amount Should Not Be Less Then 100" })
    // })

    test("Delete Invalid User", async () => {
        await connectDb()
        const { statusCode, message } = await deleteUserServiceApi("2024")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 404, message: "User Not Found" })
    })

    test("Add Valid Donation Date Between InitiationDate And Current Date", async () => {
        await connectDb()
        const { statusCode, message } = await addDonationServiceApi(donationData)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 201, message: "Thank Your For Your Donation ❤️ ❤️ ❤️" })
    })

    test("Update User With Valid Data", async () => {
        await connectDb()
        const { statusCode, message } = await editUserServiceApi({ ...userData, First_Name: "Shinchan", Flat_Number: 89, City: "Vadodara", State: "Gujarat" }, "2024-Jo-Og-06", ImageData)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "User Updated 👍" })
    })

    test("Fetch Donation Data", async () => {
        await connectDb()
        const { statusCode, message } = await getDonationDataServiceApi()
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "Data Fetched 👍" })
    })

    test("Fetch Unpaid Donation Data", async () => {
        await connectDb()
        const { statusCode, message } = await getUnpaidDonationDataServiceApi()
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "Data Fetched" })
    })




    test("Change App Setting (Change Pagination Value)", async () => {
        await connectDb()
        const { statusCode, message } = await updateRecordsPerPageServiceApi(5)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "Records Per Page Value Updated 👍" })
    })

    test("Get User List Data", async () => {
        await connectDb()
        const { statusCode, message } = await getUserListServiceApi(1)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "Data Fetched 👍" })
    })

    test("Delete User ", async () => {
        await connectDb()
        const { statusCode, message } = await deleteUserServiceApi("2024-Jo-Og-06")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "User Deleted 👍" })
    })

    test("Rollback User", async () => {
        await connectDb()
        const { statusCode, message } = await rollbackUserServiceApi("2024-Jo-Og-06")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "User Revoked 👍" })
    })

    test("Get Chating User Data", async () => {
        await connectDb()
        const { statusCode, message } = await getAllUsersDataServiceApi("admin")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "Data" })
    })
    test("Get User Profile", async () => {
        await connectDb()
        const { statusCode, message } = await getUserProfileServiceApi("2024-Jo-Og-06")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "Data Fetched" })
    })
    test("Get User Donation Data", async () => {
        await connectDb()
        const { statusCode, message } = await getTotalDonationServiceApi("2024-Jo-Og-06")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "Data Fetched" })
    })
})