import { User_Interface } from '@/app/interfaces/userData.interface'
import { validateUser } from '@/utils/validateUserData'
import '@testing-library/jest-dom'

const userData: User_Interface = {
    First_Name: "Shinchan",
    Middle_Name: "Nohara",
    Last_Name: "Harry",
    UserName: "undefined",
    Password: "password",
    Email_Id: "shinchannohara@gmail.com",
    Initiation_Date: new Date("06/06/2024"),
    Flat_Number: 123,
    Area: "Saitama",
    City: "Kasukabe",
    State: "Saitama",
    PinCode: "382350",
    Status: "ACTIVE",
    isOnline: false
}
describe("Validate UserForm", () => {

    test("Validate FirstName", () => {
        const { statusCode, message } = validateUser({ ...userData, First_Name: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "FirstName Is Required" })
    })
    test("Validate FirstName With Less Then 3 Characters", () => {
        const { statusCode, message } = validateUser({ ...userData, First_Name: "ab" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "For First Name minimum 3 char required" })
    })
    test("Validate FirstName", () => {
        const { statusCode, message } = validateUser({ ...userData, First_Name: "abcdefghijklmnop" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "For First Name maximum 15 char allowed" })
    })

    test("Validate MiddleName", () => {
        const { statusCode, message } = validateUser({ ...userData, Middle_Name: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "MiddleName Is Required" })
    })
    test("Validate MiddleName With Less Then 3 Characters", () => {
        const { statusCode, message } = validateUser({ ...userData, Middle_Name: "ab" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "For Middle Name minimum 3 char required" })
    })
    test("Validate MiddleName With More Then 15 Characters", () => {
        const { statusCode, message } = validateUser({ ...userData, Middle_Name: "abcefghijklmnop" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "For Middle Name maximum 15 char allowed" })
    })

    test("Validate LastName", () => {
        const { statusCode, message } = validateUser({ ...userData, Last_Name: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "LastName Is Required" })
    })
    test("Validate LastName With Less Then 3 Characters", () => {
        const { statusCode, message } = validateUser({ ...userData, Last_Name: "ab" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "For Last Name minimum 3 char required" })
    })
    test("Validate LastName With More Then 15 Characters", () => {
        const { statusCode, message } = validateUser({ ...userData, Last_Name: "abcdefghijklmnop" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "For Last Name maximum 15 char allowed" })
    })

    test("Validate Email", () => {
        const { statusCode, message } = validateUser({ ...userData, Email_Id: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "Email Id Is Required" })
    })
    test("Validate Email", () => {
        const { statusCode, message } = validateUser({ ...userData, Email_Id: "shinchan" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "Invalid Email Id" })
    })
    test("Validate Email", () => {
        const { statusCode, message } = validateUser({ ...userData, Email_Id: "shinchan@gmailcom" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "Invalid Email Id" })
    })
    test("Verfy Email", () => {
        const { statusCode, message } = validateUser({ ...userData, Email_Id: "abc@gmail..com" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "Invalid Email Id" })
    })
    // test("Validate FirstName", () => {
    //     const { statusCode, message } = validateUser({ ...userData, Initiation_Date:  })
    //     expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "Initiation_Date Is Required" })
    // })
    test("Validate Future Initiation Date", () => {
        const { statusCode, message } = validateUser({ ...userData, Initiation_Date: new Date("9/25/2024") })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "Initiation Date Should Not Be Of Future" })
    })
    test("Validate More Then Past 2 Month Initiation Date", () => {
        const { statusCode, message } = validateUser({ ...userData, Initiation_Date: new Date("5/5/2024") })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "Initiation Date should be not be less than of last 2 month" })
    })

    // test("Validate FirstName", () => {
    //     const { statusCode, message } = validateUser({ ...userData, Flat_Number:  })
    //     expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "Flat Number Is Required" })
    // })


    test("Validate Area", () => {
        const { statusCode, message } = validateUser({ ...userData, Area: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "Area Is Required" })
    })
    test("Validate City", () => {
        const { statusCode, message } = validateUser({ ...userData, City: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "City Is Required" })
    })
    test("Validate State", () => {
        const { statusCode, message } = validateUser({ ...userData, State: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "State Is Required" })
    })
    test("Validate Pincode", () => {
        const { statusCode, message } = validateUser({ ...userData, PinCode: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "Pincode Is Required" })
    })
    test("Validate Invalid Pincode", () => {
        const { statusCode, message } = validateUser({ ...userData, PinCode: "dsa5456" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "Invalid Pincode" })
    })
    test("Validate Status", () => {
        const { statusCode, message } = validateUser({ ...userData, Status: "" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 422, message: "Status Is Required" })
    })
    test("Validate Status", () => {
        const { statusCode, message } = validateUser({ ...userData, Status: "dasdsdsds" })
        expect({ statusCode, message }).toStrictEqual({ statusCode: 409, message: "Invalid Value For Status" })
    })
    test("Valid User", () => {
        const { statusCode, message } = validateUser(userData)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "All Fields Are Valid" })
    })
})
