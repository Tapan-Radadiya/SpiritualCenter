import { ChatingData } from "@/models/chating.model"
import { UserLogin } from "@/models/userlogin.model"
import ApiResponse from "@/utils/ApiResponse"
import { headers } from "next/headers"

async function getAllUsersDataServiceApi(username:any) {

    
    const usersData: [{ UserName: string, FullName: string, ProfileImage: string }] = [{ UserName: "BroadCast", FullName: "BroadCast", ProfileImage: "SpiritualCenterLogo.jpeg" }]
    const allUserData = await UserLogin.aggregate(
        [
            {
                $lookup: {
                    from: "users",
                    localField: "UserName",
                    foreignField: "UserName",
                    as: "result",
                },
            },
            {
                $addFields: {
                    result: {
                        $arrayElemAt: ["$result", 0],
                    },
                },
            },
            {
                $addFields: {
                    UserFullName: {
                        $concat: [
                            "$result.First_Name",
                            " ",
                            "$result.Last_Name",
                        ],
                    },
                    ProfileImage: "$result.ImageUrl",
                    isActive: "$result.isOnline"
                },
            },
            {
                $project: {
                    result: 0,
                },
            },
        ]
    )
    allUserData.forEach((ele) => {
        if (ele.UserName != username) {
            const userList: any = {
                UserName: ele.UserName,
                FullName: ele.UserFullName || "admin",
                ProfileImage: ele.ProfileImage || "whatsappDefaultProfile.jpeg",
                ActiveStatus: ele.isActive
            }
            usersData.push(userList)
        }
    })
    return ApiResponse(200, "Data", usersData)
}

async function getChatMessagesServiceApi(roomName: string) {

    const checkRoomExist = await ChatingData.findOne({ RoomName: roomName })

    if (checkRoomExist) {
        return ApiResponse(200, "Data Fetched", checkRoomExist.MessageData)
    }
    else {
        const createRoom = await ChatingData.create({ RoomName: roomName, MessageData: [] })
        return ApiResponse(201, "New Room Created", createRoom.MessageData)
    }
}

async function sendMessageServiceApi(messageData: { username: string, userMessage: string, time: Date, roomName: string }) {
    const sendMessage = await ChatingData.findOneAndUpdate({ RoomName: messageData.roomName },
        {
            $push: {
                MessageData: {
                    userName: messageData.username,
                    message: messageData.userMessage,
                    time: messageData.time
                }
            }
        },
        { new: true }
    )
    if (sendMessage) {
        return ApiResponse(201, "Message sended")
    }
    else {
        return ApiResponse(500, "Error Sending Message Try After SomeTime")
    }
}
export {
    getAllUsersDataServiceApi,
    getChatMessagesServiceApi,
    sendMessageServiceApi
}