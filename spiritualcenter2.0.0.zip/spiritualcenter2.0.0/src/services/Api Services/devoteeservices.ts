import { DonationData } from "@/models/donationdata.model"
import { User } from "@/models/userdata.model"
import ApiResponse from "@/utils/ApiResponse"

async function addDonationServiceApi(donationData: { userName: string, Month: number, Year: number, Donation_Amount: number }) {

    const InitiationDate = await User.findOne({ UserName: donationData.userName })

    const newDate = new Date(`${donationData.Month}/02/${donationData.Year}`)
    const initDate = new Date(InitiationDate.Initiation_Date)

    if (newDate < initDate) {
        return ApiResponse(400, "Donation Date Can Not Be Of Past Of Your Initiation Date")
    }
    else if (newDate > new Date()) {
        return ApiResponse(400, "Donation Date Can Not Be Of Future Of Your Initiation Date")
    }
    const addDonation = await DonationData.create({
        UserName: donationData.userName,
        Month: Number(donationData.Month),
        Year: Number(donationData.Year),
        Donation_Amount: Number(donationData.Donation_Amount)
    })
    if (!addDonation) {
        return ApiResponse(500, "Error Making Donation Try After SomeTime")
    }
    return ApiResponse(201, "Thank Your For Your Donation ❤️ ❤️ ❤️")
}

async function getUserProfileServiceApi(username: string) {

    const getData = await User.findOne({ UserName: username })
    if (!getData) {
        return ApiResponse(404, "User Not Found")
    }
    return ApiResponse(200, "Data Fetched", getData)
}

async function getTotalDonationServiceApi(username: string) {
    const getData = await DonationData.aggregate(
        [
            {
                $match: {
                    UserName: username
                }
            },
            {
                $group: {
                    _id: { UserName: "$UserName", Month: "$Month", Year: "$Year" },
                    totalDonation: {
                        $sum: "$Donation_Amount"
                    }
                }
            },
            {
                $sort: {
                    totalDonation: 1
                }
            }
        ]
    )
    console.log(getData);

    if (getData.length == 0) {
        return ApiResponse(200, "No Data Found", getData)
    }
    return ApiResponse(200, "Data Fetched", getData)
}

export {
    addDonationServiceApi,
    getUserProfileServiceApi,
    getTotalDonationServiceApi
}