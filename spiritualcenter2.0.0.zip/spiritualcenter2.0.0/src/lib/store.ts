import { configureStore } from "@reduxjs/toolkit"
import userdataslice from "./features/userdataslice"
import donationdataslice from "./features/donationdataslice"
import searchBoxslice from "./features/searchBoxslice"
import chatingSlice from "./features/chatingSlice"

export const Store = configureStore({
    reducer: {
        userdataslice: userdataslice,
        donationdataslice: donationdataslice,
        searchBoxslice:searchBoxslice,
        chatingSlice:chatingSlice
    }
})