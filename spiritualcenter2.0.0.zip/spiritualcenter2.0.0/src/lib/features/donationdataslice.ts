import { createSlice } from "@reduxjs/toolkit";

const donationslice = createSlice(
    {
        name: "AddDonationData",
        initialState: {
            donationData: [],
            unpaidDonationData: []
        },
        reducers: {
            addData: (state: any, action: any) => {
                return {
                    ...state,
                    donationData: action.payload
                }
            },
            addUnpaidDonationData: (state: any, action: any) => {
                return {
                    ...state,
                    unpaidDonationData: action.payload
                }
            }
        }
    }
)
export const { addData ,addUnpaidDonationData} = donationslice.actions
export default donationslice.reducer