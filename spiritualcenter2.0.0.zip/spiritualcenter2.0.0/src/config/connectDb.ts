import { NextResponse } from "next/server";
import ApiResponse from "../utils/ApiResponse";
import mongoose from "mongoose";

export async function connectDb() {
    try {
        const connection = await mongoose.connect(`${process.env.MONGODB_URL}/${process.env.MONGODB_DATABASE}`)
        if (connection.connection.host) {
            return true
        }
        else { return false }

    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}