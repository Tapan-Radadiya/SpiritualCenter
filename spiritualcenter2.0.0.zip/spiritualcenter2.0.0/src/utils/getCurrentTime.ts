export default function getTime(date: Date) {
    const hours = new Date(date).getHours() >= 13 ? new Date(date).getHours() - 12 : new Date(date).getHours()
    const minutes = new Date(date).getMinutes() < 10 ? "0" + new Date(date).getMinutes() : new Date(date).getMinutes()
    const timeFormat = new Date(date).getHours() >= 12 ? "PM" : "AM"
    return `${hours}:${minutes} ${timeFormat}`
}