import { ChatingData_Interface } from "@/app/interfaces/chatingData.interface";
import mongoose from "mongoose";

const ChatingDataSchema = new mongoose.Schema<ChatingData_Interface>({
    RoomName: {
        type: String,
        unique: true,
        required: true
    },
    MessageData: [
        {
            userName: {
                type: String,
                required: true
            },
            message: {
                type: String,
                required: true
            },
            time: {
                type: Date,
                required: true
            }
        }
    ]
}, { timestamps: true })

export const ChatingData = mongoose.models.ChatingData || mongoose.model("ChatingData", ChatingDataSchema)