import { User_Interface } from "@/app/interfaces/userData.interface";
import mongoose from "mongoose";
import validator from "validator";

const UserSchema = new mongoose.Schema<User_Interface>({
    First_Name: {
        type: String,
        required: true,
        minlength: [3, "For First Name minimum 3 char required"],
        maxlength: [15, "For First Name maximum 15 char allowed"]
    },
    Middle_Name: {
        type: String,
        required: true,
        minlength: [3, "For Middle Name minimum 3 char required"],
        maxlength: [15, "For Middle Name maximum 15 char allowed"]
    },
    Last_Name: {
        type: String,
        required: true,
        minlength: [3, "For Last Name minimum 3 char required"],
        maxlength: [15, "For Last Name maximum 15 char allowed"]
    },
    UserName: {
        type: String,
        required: true
    },
    Password: {
        type: String,
        required: true,
        default:"password"
    },
    Email_Id: {
        type: String,
        required: true,
        validate: [validator.isEmail, "Please enter valid email"]
    },
    Initiation_Date: {
        type: Date,
        required: true
    },
    Flat_Number: {
        type: Number,
        required: true
    },
    Area: {
        type: String,
        required: true
    },
    City: {
        type: String,
        required: true
    },
    State: {
        type: String,
        required: true
    },
    PinCode: {
        type: String,
        required: true,
        length: [6, "For Pincode maximum 6 digit allowed"]
    },
    ImageUrl: {
        type: String
    },
    Status: {
        type: String,
        enum: {
            values: ["ACTIVE", "INACTIVE"],
            message: "Invalid Value"
        }

    },
    isOnline:{
        type:Boolean,
        default:false
    }
}, { timestamps: true })


export const User = mongoose.models.User || mongoose.model("User", UserSchema)