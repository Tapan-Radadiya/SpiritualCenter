'use client'
import Image from "next/image"
import issueImage from "../../images/issue.png"
import userlogoutaction from "@/actions/userlogoutaction"
import { useRouter } from "next/navigation"
export default function InvalidValue() {
    return (
        <>
            <div className="container d-flex justify-content-center mt-5">
                <Image
                    src={issueImage}
                    alt={"Issue Please Login"}
                    width={500}
                    height={500}
                />
            </div>
            <div className="container mt-5 text-center">
                <h1>There Is Some Issue Please Login Again</h1>
                <button className="btn btn-success mt-4" type="button" style={{ fontSize: "20px" }} onClick={() => userlogoutaction()}>Please Login</button>
            </div>
        </>
    )
}