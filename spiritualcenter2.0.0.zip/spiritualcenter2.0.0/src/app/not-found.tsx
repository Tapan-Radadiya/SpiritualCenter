import Image from "next/image";
import image from "../../public/confused-travolta.2cb7b484.gif"
export default function Page() {
    return (
        <>
            <div className="container text-center mt-5">
                <h1>Page you are looking for is not available</h1>
                <Image
                 className="mt-5"
                    src={image}
                    alt="404"
                    width={1000}
                    height={500}
                />
            </div>
        </>
    )
}