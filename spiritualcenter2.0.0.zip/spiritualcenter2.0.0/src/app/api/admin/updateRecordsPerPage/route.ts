import { AppSettings } from "@/models/appsettings.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import mongoose from "mongoose";
import { NextRequest, NextResponse } from "next/server";
import { updateRecordsPerPageServiceApi } from "@/services/Api Services/adminservices";

export async function PATCH(req: NextRequest) {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Db"))
    }
    const { RecordsValue } = await req.json()
    if (!RecordsValue) {
        return NextResponse.json(ApiResponse(422, "Records Value Is Required"))
    }
    else if (Number(RecordsValue) <= 0) {
        return NextResponse.json(ApiResponse(409, "Record Value Should Not Be Less Then 1"))
    }

    try {
    
        const { statusCode, message } = await updateRecordsPerPageServiceApi(RecordsValue)

        return NextResponse.json(ApiResponse(statusCode, message))
    } catch (error) {
        console.log(error);
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}