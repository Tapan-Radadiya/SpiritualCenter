import { User_Interface } from "@/app/interfaces/userData.interface";
import { User } from "@/models/userdata.model";
import { UserLogin } from "@/models/userlogin.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { compareData } from "@/utils/bcryptFunc";
import { connectDb } from "@/config/connectDb";
import { uploadImageToS3 } from "@/utils/imageUpload";
import { validateUser } from "@/utils/validateUserData";
import { cookies, headers } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { createUserServiceApi } from "@/services/Api Services/adminservices";

export async function POST(req: NextRequest) {
    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    const formData: any = await req.formData()
    const data = Object.fromEntries(formData)
    const First_Name = data.First_Name
    const Middle_Name = data.Middle_Name
    const Last_Name = data.Last_Name
    const Email_Id = data.Email_Id
    const Initiation_Date = data.Initiation_Date
    const Flat_Number = data.Flat_Number
    const Area = data.Area
    const City = data.City
    const State = data.State
    const PinCode = data.PinCode
    const ImageData = data.ImageUrl
    const Password = data.Password

    const userType: User_Interface = {
        First_Name: First_Name,
        Middle_Name: Middle_Name,
        Last_Name: Last_Name,
        UserName: "",
        Email_Id: Email_Id,
        Initiation_Date: Initiation_Date,
        Flat_Number: Flat_Number,
        Area: Area,
        City: City,
        State: State,
        PinCode: PinCode,
        Status: "ACTIVE",
        Password: "password" || Password, //Intentionally Doing
        isOnline: false
    }
    const { statusCode, message }: any = validateUser(userType, ImageData)
    if (statusCode == 422) {
        return NextResponse.json(ApiResponse(statusCode, message))
    }
    else if (statusCode == 409) {
        return NextResponse.json(ApiResponse(statusCode, message))
    }

    const uniqueName = `${new Date(Initiation_Date).getFullYear()}-${First_Name.slice(0, 2)}-${Last_Name.slice(0, 2)}-${new Date(Initiation_Date).getMonth() + 1}`

    const checkUserNameExist = await User.findOne({ UserName: uniqueName })
    try {

        if (checkUserNameExist) {
            return NextResponse.json(ApiResponse(403, "UserName Already Exist"))
        }
        
            const { statusCode, message, data }: any = await createUserServiceApi(userType, ImageData)
        return NextResponse.json(ApiResponse(statusCode, message, data))

    } catch (error) {
        console.log(error)

        // if user created but get error in logincredentials
        await UserLogin.findOneAndDelete({ UserName: uniqueName })
        await User.findOneAndDelete({ UserName: uniqueName })
        return NextResponse.json(ApiResponse(500, "Error In CreateUser"))
    }
}