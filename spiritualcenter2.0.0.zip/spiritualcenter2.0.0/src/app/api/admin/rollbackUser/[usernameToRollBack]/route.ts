import { User } from "@/models/userdata.model"
import { UserLogin } from "@/models/userlogin.model"
import ApiResponse from "@/utils/ApiResponse"
import authUser from "@/utils/authUser"
import { connectDb } from "@/config/connectDb"
import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"
import { rollbackUserServiceApi } from "@/services/Api Services/adminservices"

export async function PATCH(req: NextRequest, { params }: any) {
    
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    const { usernameToRollBack } = params
    if (!usernameToRollBack) {
        return NextResponse.json(ApiResponse(422, "UserName Is Required"))
    }

    try {
        const { statusCode, message } = await rollbackUserServiceApi(usernameToRollBack)
        return NextResponse.json(ApiResponse(statusCode, message))
    } catch (error) {
        console.log(error);

        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}