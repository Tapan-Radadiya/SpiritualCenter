import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies, headers } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { getUserProfileServiceApi } from "@/services/Api Services/devoteeservices";

export async function GET(req: NextRequest) {

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Host"))
    }
    try {
        const username = headers().get("Username")
        if (!username) {
            return NextResponse.json(ApiResponse(404, "Unable To Find UserName Please Login Again"))
        }
        
        const { statusCode, message, data } = await getUserProfileServiceApi(username)
        return NextResponse.json(ApiResponse(statusCode, message, data))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}