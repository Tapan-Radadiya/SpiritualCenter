'use client'
import { User_Interface } from "@/app/interfaces/userData.interface";
import { setSearchValue } from "@/lib/features/searchBoxslice";
import { addUserData, adduserForm, dataOperation, deleteUserState, setCurrentPage, setPages, setTotalRecordsValue } from "@/lib/features/userdataslice";
import { deleteUserService, getCurrectRecordsPerPageService, getTotalPagesService, getUserDataService } from "@/services/adminservices";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
export default function UserList() {
    const dispatch = useDispatch()
    document.title = "Dashboad Admin | Spiritual Center"
    const currentPage = useSelector((state: any) => state.userdataslice.currentPageNumber)

    const userData = useSelector((state: any) => state.userdataslice.userData)
    const operationData = useSelector((state: any) => state.userdataslice.operationData)
    const pages = useSelector((state: any) => state.userdataslice.totalPages)

    const searchBoxValue = useSelector((state: any) => state.searchBoxslice.searchValue)

    useEffect(() => {
        sendReq(currentPage)
        getTotalPages()
        fetchCurrectRecordsValue()
    }, [])

    const router = useRouter()

    async function fetchCurrectRecordsValue() {
        const { statusCode, message, data } = await getCurrectRecordsPerPageService()
        if (statusCode == 200) {
            dispatch(setTotalRecordsValue(data.curRecordsPerPage))
        }
    }


    async function sendReq(pagenumber: number) {

        const { statusCode, message, data }: any = await getUserDataService(pagenumber)
        if (statusCode == 200) {
            dispatch(addUserData(data))
            dispatch(dataOperation(data))
        }
        else {
            toast.error(message)
        }

    }
    async function getTotalPages() {
        const { statusCode, message, data } = await getTotalPagesService()
        if (statusCode == 200) {
            dispatch(setPages(data))
        }
    }
    function sortInAscOrder() {
        let data: any = [...operationData]
        data.sort((item1: any, item2: any) => {
            if (item1.Area.toUpperCase() > item2.Area.toUpperCase()) {
                return 1
            }
            else {
                return -1
            }
        })
        dispatch(dataOperation(data))
    }

    function sortInDescOrder() {
        let data: any = [...operationData]
        data = data.sort((item1: any, item2: any) => {
            if (item1.Area.toUpperCase() > item2.Area.toUpperCase()) {
                return -1
            }
            else {
                return 1
            }
        })
        dispatch(dataOperation(data))
    }
    function searchValue() {
        const searchUser = userData.filter((elem: User_Interface) => elem.Area == searchBoxValue)
        const pagesData: [] | any = []
        dispatch(setPages(pagesData))
        dispatch(dataOperation(searchUser))
    }
    function resetValue(e: any) {
        const { value } = e.target
        if (value != "") {
            dispatch(setSearchValue(value))
        }
        else {
            getTotalPages()
            dispatch(dataOperation(userData))
        }
    }


    // Api Calling
    function editUser(userName: string) {
        const userDetails = userData.filter((elem: User_Interface) => userName == elem.UserName)
        dispatch(adduserForm(userDetails[0]))
        router.push("/admin/edituser")
    }
    async function deleteUser(userName: any) {
        const { statusCode, message }: any = await deleteUserService(userName)
        if (statusCode == 200) {
            toast.success(message)
            dispatch(deleteUserState(userName))
            if (operationData.length == 1 && currentPage != 1) {
                sendReq(currentPage - 1)
                getTotalPages()
            }
            else {
                sendReq(currentPage)
                getTotalPages()
            }
        }
        else if (statusCode == 422) {
            toast.warning(message)
        }
        else {
            toast.error(message)
        }
    }
    function nextPage(key: number | any) {
        dispatch(setCurrentPage(key))
        sendReq(key)
    }
    return (
        <>
            <div className="container-fluid mb-5">
                <div className="container">
                    <p className="display-6 text-center text-uppercase mt-4" style={{ fontWeight: "300", letterSpacing: "2px" }}>Devotees Data</p>
                </div>
                <div className="container row float-right p-3 mt-2">
                    <div className="col-md-4"></div>
                    <div className="col-md-5 d-flex">
                        <input type="text" id="searchValue" className=" m-1 form-control border border-dark" placeholder="Search" onChange={(e) => resetValue(e)} />
                        <button className="btn btn-success ml-4 m-1" onClick={() => searchValue()}>Search</button>
                    </div>
                    <button className="btn btn-secondary m-1 col-md-1" onClick={() => sortInAscOrder()}> Asc</button>
                    <button className="btn btn-secondary m-1 col-md-1" onClick={() => sortInDescOrder()}> Desc</button>
                </div>
                <div className="container-fluid" style={{ marginTop: "15vh", maxHeight: "100vh", height: "auto", overflow: "scroll" }}>
                    <table className="table text-center">
                        <thead className="thead-dark">
                            <tr>
                                <th>DevoteeId</th>
                                <th>First Name</th>
                                <th>Middle Name</th>
                                <th>Last Name</th>
                                <th>Email Id</th>
                                <th>Initiation Date</th>
                                <th>Flat Number</th>
                                <th>Area</th>
                                <th>City</th>
                                <th>State</th>
                                <th>PinCode</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                operationData.map((key: User_Interface, value: any) => (
                                    <tr key={value}>
                                        <td>{key.UserName}</td>
                                        <td>{key.First_Name}</td>
                                        <td>{key.Middle_Name}</td>
                                        <td>{key.Last_Name}</td>
                                        <td>{key.Email_Id}</td>
                                        <td>{new Date(key.Initiation_Date).toLocaleDateString("en-us")}</td>
                                        <td>{String(key.Flat_Number)}</td>
                                        <td>{key.Area}</td>
                                        <td>{key.City}</td>
                                        <td>{key.State}</td>
                                        <td>{key.PinCode}</td>
                                        <td><button id={`editBtn-${key.UserName}`} onClick={() => editUser((key.UserName).toString())} className="btn btn-warning w-100">Edit User <i className="fa fa-solid fa-pen-to-square"></i></button></td>
                                        <td><button id={`deleteBtn-${key.UserName}`} onClick={() => deleteUser((key.UserName).toString())} className="btn btn-danger w-100">Delete <i className="fa fa-solid fa-trash"></i></button></td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
                <div className="container d-flex justify-content-center">
                    {
                        pages.map((key: any, value: any) => (
                            <button className="btn" key={value} onClick={() => nextPage(key)}>{key}</button>
                        ))
                    }
                </div>
            </div>
        </>
    )
}