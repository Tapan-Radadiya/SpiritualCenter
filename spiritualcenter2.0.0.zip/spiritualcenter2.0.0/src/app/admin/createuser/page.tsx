'use client'
import { User_Interface } from "@/app/interfaces/userData.interface";
import { createUserService } from "@/services/adminservices";
import { verifyInitiaionDate } from "@/utils/verifyDate";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import validator from "validator";

export default function CreateUser() {
    document.title = "Register User | Spiritual Center"
    const { handleSubmit, setError, formState: { errors }, register } = useForm<User_Interface>({ mode: "onBlur" })
    const [btnStatus, setBtnStatus] = useState(false)
    const dispatch = useDispatch()
    const router = useRouter()
    async function createuser(user_data: any) {
        toast.loading("Creating User")
        if (user_data.ImageUrl.length != 0) {
            const fileData = user_data.ImageUrl[0].name.split(".")
            const fileExtension = fileData[fileData.length - 1]

            if (fileExtension != "jpeg" && fileExtension != "png" && fileExtension != "jpg") {
                console.log("invaid")
                return setError("ImageUrl", { message: "Only Jpeg, Png And Jpg File Allowed" })
            }
            if (user_data.ImageUrl[0].size > 10000000) {
                return setError("ImageUrl", { message: "Image File Should Not Be More Then 10 Mb" })
            }
        }
        const { statusCode, message, data }: any = await createUserService(user_data)
        toast.dismiss()
        if (statusCode == 201) {
            toast.success(message)
            router.push("/admin/userlist")
        }
        else if (statusCode == 409 || statusCode == 422) {
            toast.warning(message)
        }
        else {
            toast.error(message)
        }
    }
    return (
        <>
            <div className="container">
                <p className="display-6 text-center text-uppercase mt-5">Register Devotee</p>
            </div>
            <div className="container p-4 border border-dark w-50">
                <form onSubmit={handleSubmit((data) => createuser(data))}>
                    <div className="form-group mt-3">
                        <label htmlFor="firstName" className="form-label">First Name</label>
                        <input type="text" id="firstName" {...register("First_Name", {
                            required: { value: true, message: "First Name is required" },
                            minLength: { value: 3, message: "For First Name minimum 3 char required" },
                            maxLength: { value: 16, message: "For First Name maximum 15 char allowed" }
                        })} className="form-control border border-dark" />
                        {errors.First_Name && <span className="text-danger" id="firstNameErr">{errors.First_Name.message}</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="middleName" className="form-label">Middle Name</label>
                        <input type="text" id="middleName" {...register("Middle_Name", {
                            required: { value: true, message: "Middle Name is required" },
                            minLength: { value: 3, message: "For Middle Name minimum 3 char required" },
                            maxLength: { value: 16, message: "For Middle Name maximum 15 char allowed" }
                        })} className="form-control border border-dark" />
                        {errors.Middle_Name && <span className="text-danger" id="middleNameErr">{errors.Middle_Name.message}</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="lastName" className="form-label">Last Name</label>
                        <input type="text" id="lastName" {...register("Last_Name", {
                            required: { value: true, message: "Last Name is required" },
                            minLength: { value: 3, message: "For Last Name minimum 3 char required" },
                            maxLength: { value: 16, message: "For Last Name maximum 15 char allowed" }
                        })} className="form-control border border-dark" />
                        {errors.Last_Name && <span className="text-danger" id="lastNameErr">{errors.Last_Name.message}</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="emailId" className="form-label">Email Id</label>
                        <input type="text" id="emailId" {...register("Email_Id", {
                            required: { value: true, message: "Email is required" },
                            validate: (email: any) => {
                                if (!validator.isEmail(email)) {
                                    return "Pleae enter valid email"
                                }
                            },
                        })} className="form-control border border-dark" />
                        {errors.Email_Id && <span className="text-danger" id="emailIdErr">{errors.Email_Id.message}</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="initiationDate" className="form-label">Initiation Date</label>
                        <input type="date" id="initiationDate" {...register("Initiation_Date", {
                            required: { value: true, message: "Initiation Date is required" },
                            validate: verifyInitiaionDate
                        })} className="form-control border border-dark" />
                        {errors.Initiation_Date && <span className="text-danger" id="initiationDateErr">{errors.Initiation_Date.message}</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="flatNumber" className="form-label">Flat Number</label>
                        <input type="text" id="flatNumber" {...register("Flat_Number", { required: true })} className="form-control border border-dark" />
                        {errors.Flat_Number && <span className="text-danger" id="areaErr">Flat Number is required</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="area" className="form-label">Area</label>
                        <input type="text" id="area" {...register("Area", { required: true })} className="form-control border border-dark" />
                        {errors.Area && <span className="text-danger" id="areaErr">Area is required</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="city" className="form-label">City</label>
                        <input type="text" id="city"  {...register("City", { required: true })} className="form-control border border-dark" />
                        {errors.City && <span className="text-danger" id="cityErr">City is required</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="state" className="form-label">State</label>
                        <input type="text" id="state"  {...register("State", { required: true })} className="form-control border border-dark" />
                        {errors.State && <span className="text-danger" id="stateErr">State is required</span>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="pinCode" className="form-label">Pincode</label>
                        <input type="text" id="pinCode" {...register("PinCode", {
                            required: { value: true, message: "Pincode is required" },
                            pattern: { value: /^[0-9]{6}$/i, message: "Pincode should not contain non digit characters" },
                            minLength: { value: 6, message: "For Pincode maximum 6 digit allowed" },
                            maxLength: { value: 6, message: "For Pincode maximum 6 digit allowed" }
                        })} className="form-control border border-dark" />
                        {errors.PinCode && <span className="text-danger" id="pinCodeErr">{errors.PinCode.message}</span>}
                    </div>
                    <div className="form-group">
                        <label htmlFor="imageUrl" className="form-label">Select Profile Image</label>
                        <input type="file" id="imageUrl" {...register("ImageUrl")} className="form-control border border-dark" />
                        {errors.ImageUrl && <span className="text-danger">{errors.ImageUrl.message}</span>}
                    </div>
                    <div className="form-group mt-5 mb-5 d-flex justify-content-center">
                        {
                            btnStatus ?
                                <button className="btn btn-success w-75" disabled>
                                    <span className="spinner-border spinner-border-sm mr-2"></span>
                                    <span>Creating User.....</span>
                                </button> :
                                <button className="btn btn-success w-75" id="submit">Create User</button>
                        }
                    </div>
                </form>
            </div>
        </>
    )
}