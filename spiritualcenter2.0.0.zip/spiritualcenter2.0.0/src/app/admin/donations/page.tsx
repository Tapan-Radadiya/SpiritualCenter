'use client'
import { addData, addUnpaidDonationData } from "@/lib/features/donationdataslice";
import { getAllDonationDataService, getUnpaidDonationDataService } from "@/services/adminservices";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";


export default function DonationData() {
    document.title = "Donation Data | Spiritual Center"
    const [dataStatus, setDataStatus] = useState(1)

    const dispatch = useDispatch()
    const donationData = useSelector((state: any) => state.donationdataslice.donationData)
    const unpaidDonationData = useSelector((state: any) => state.donationdataslice.unpaidDonationData)

    useEffect(() => {
        fetchDonationData()
        fetchUnpaidDonationData()
    }, [])

    async function fetchDonationData() {
        const { statusCode, message, data }: any = await getAllDonationDataService()
        if (statusCode == 200) {
            dispatch(addData(data))
        }
        else {
            toast.error(message)
        }
    }
    async function fetchUnpaidDonationData() {
        const { statusCode, message, data }: any = await getUnpaidDonationDataService()
        if (statusCode == 200) {
            dispatch(addUnpaidDonationData(data))
        }
    }
    function getData(e: any) {
        const { value } = e.target
        if (value == "unpaid") {
            setDataStatus(2)
        }
        else {
            setDataStatus(1)
        }
    }
    return (
        <>
            <div className="container mt-5">
                <div className="container">
                    {
                        dataStatus == 1 ?
                            <p className="display-6 text-uppercase text-center mt-3" style={{ letterSpacing: "2px" }}>
                                Donation Details
                            </p> :
                            <p className="display-6 text-uppercase text-center mt-3" style={{ letterSpacing: "2px" }}>
                                Unpaid Donation
                            </p>
                    }

                </div>
                <div className="container row m-2 mt-4">
                    <div className="form-group col-md-5">
                        <select id="donationMenu" className="form-select border border-dark w-50" onChange={(e) => getData(e)}>
                            <option id="allPayment" value="All_Payments">All Payments</option>
                            <option id="Unpaid" value="unpaid">Unpaid Donation</option>
                        </select>
                    </div>
                </div>
                <div className="container text-center">
                    {
                        dataStatus == 1 ?
                            <table className="table" id="allPaymentList">
                                <thead className="thead-dark">
                                    <tr>
                                        <th>UserName</th>
                                        <th>Month</th>
                                        <th>Year</th>
                                        <th>Donation_Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        donationData.map((key: any, value: any) => (
                                            <tr key={value} className={key.totalDonation > 10000 ? "bg-success" : ""}>
                                                <td>{key._id.UserName}</td>
                                                <td>{key._id.Month}</td>
                                                <td>{key._id.Year}</td>
                                                <td>{key.totalDonation}</td>
                                            </tr>
                                        ))
                                    }
                                </tbody>
                            </table>
                            :
                            <table className="table" id="allUnpaidList">
                                <thead className="thead-dark">
                                    <tr>
                                        <th>DevoteeId</th>
                                        <th>First Name</th>
                                        <th>Middle Name</th>
                                        <th>Last Name</th>
                                        <th>Email Id</th>
                                        <th>Flat no</th>
                                        <th>Area</th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>PinCode</th>
                                        <th>Initiation Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        unpaidDonationData.map((key: any, value: any) => (
                                            <tr key={value}>
                                                <td>{key.UserName}</td>
                                                <td>{key.First_Name}</td>
                                                <td>{key.Middle_Name}</td>
                                                <td>{key.Last_Name}</td>
                                                <td>{key.Email_Id}</td>
                                                <td>{key.Flat_Number}</td>
                                                <td>{key.Area}</td>
                                                <td>{key.City}</td>
                                                <td>{key.State}</td>
                                                <td>{key.PinCode}</td>
                                                <td>{new Date(key.Initiation_Date).toLocaleDateString("en-us")}</td>
                                            </tr>
                                        ))
                                    }
                                </tbody>
                            </table>
                    }
                </div>
            </div>
        </>
    )
}