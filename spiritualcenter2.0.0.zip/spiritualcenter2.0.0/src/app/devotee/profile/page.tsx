'use client'
import { addUserProfile } from "@/lib/features/userdataslice"
import Image from "next/image"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import style from "../../css/devoteeProfile.module.css"
import { getDevpteeProfileService } from "@/services/devoteeservices"
export default function Profile() {
    document.title = "User Profile | Spiritual Center"
    useEffect(() => {
        sendReq()
    }, [])
    const dispatch = useDispatch()
    const userData = useSelector((state: any) => state.userdataslice.userProfile)
    async function sendReq() {
        const { statusCode, message, data }: any = await getDevpteeProfileService()
        if (statusCode == 200) {
            dispatch(addUserProfile(data))
        }
    }
    return (
        <>
            <div className="container mt-5">
                <div className="container mt-5 p-5 mb-5 " style={{ borderRadius: "20px", boxShadow: "0px 0px 50px 5px" }}>

                    <div className="container row p-1 d-flex justify-content-center">
                        <h2 className="" style={{ letterSpacing: "2px", fontWeight: "100" }}>Welcome, <span style={{ fontWeight: "500" }}>{userData.First_Name}</span></h2>
                        <div className="col-md-5 text-center ml-5">

                            {userData.ImageUrl ?
                                <Image
                                    src={`${process.env.NEXT_PUBLIC_S3_URL}/${userData.ImageUrl}`}
                                    alt="User Profile Image"
                                    quality={100}
                                    style={{ marginTop: "20px", marginBottom: "20px", borderRadius: "50%" }}
                                    width={400}
                                    height={400}
                                /> : <></>
                            }
                        </div>
                        <div className="col-md-5 p-1" style={{ marginLeft: "10%" }}>
                            <div className="form-group d-flex" id="body">
                                <p className={`${style.profileElement}`}>User Id</p>
                                <p className={`${style.profileDataEle} ml-3`}>{userData.UserName}</p>
                            </div>
                            <div className="form-group d-flex" id="body">
                                <p className={`${style.profileElement}`}> Name</p>
                                <p className={`${style.profileDataEle} ml-3`}>{userData.First_Name} {userData.Middle_Name} {userData.Last_Name}</p>
                            </div>
                            <div className="form-group d-flex">
                                <p className={`${style.profileElement}`}>User EmailId</p>
                                <p className={`${style.profileDataEle} ml-3`}>{userData.Email_Id}</p>
                            </div>
                            <div className="form-group d-flex">
                                <p className={`${style.profileElement}`}>Flat Number</p>
                                <p className={`${style.profileDataEle} ml-3`}>{userData.Flat_Number}</p>
                            </div>
                            <div className="form-group d-flex">
                                <p className={`${style.profileElement}`}>Area</p>
                                <p className={`${style.profileDataEle} ml-3`}>{userData.Area}</p>
                            </div>
                            <div className="form-group d-flex">
                                <p className={`${style.profileElement}`}>City</p>
                                <p className={`${style.profileDataEle} ml-4`}>{userData.City}</p>
                            </div>
                            <div className="form-group d-flex">
                                <p className={`${style.profileElement}`}>State</p>
                                <p className={`${style.profileDataEle} ml-4`}>{userData.State}</p>
                            </div>
                            <div className="form-group d-flex">
                                <p className={`${style.profileElement}`}>Pincode</p>
                                <p className={`${style.profileDataEle} ml-4`}>{userData.PinCode}</p>
                            </div>
                            <div className="form-group d-flex">
                                <p className={`${style.profileElement}`}>Initiation Date</p>
                                <p className={`${style.profileDataEle} ml-4`}>{new Date(userData.Initiation_Date).toLocaleDateString("en-us")}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}