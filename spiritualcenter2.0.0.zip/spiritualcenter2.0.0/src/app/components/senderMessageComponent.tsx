import getTime from "@/utils/getCurrentTime";

export default function SenderMessageComponent({ message, time }: { message: string, time: Date }) {
    return (
        <div className="container d-flex justify-content-end">
            <div className="row mt-3" style={{ backgroundColor: "#144d37", borderRadius: "20px", maxWidth: "800px", minWidth:"300px" }}>
                <p className="col-md text-light mt-3" style={{ overflowWrap: "break-word" }}>
                    {message}
                </p>
                <div className="col-md-4 d-flex mb-2 float-right" >
                    <small style={{fontSize:""}} className="mt-4 text-light text-light">{getTime(time)}</small>
                </div>
            </div>
        </div>
    )
}