import { useEffect, useState } from "react"
import { socket } from "../../socket"
import { useDispatch, useSelector } from "react-redux"
import { addBroadCastChatData } from "@/lib/features/chatingSlice"

export default function BroadCastChat({ curUser }: { curUser: string }) {
    const dispatch = useDispatch()
    const [message, setMessage] = useState("")
    const [err, setErr] = useState(false)
    useEffect(() => {
        socket.on("RECEIVE_BROADCAST_MESSAGE", (data: any) => {
            console.log(data);
            dispatch(addBroadCastChatData(data))
        })
    }, [socket])
    const broadCastMessages = useSelector((state: any) => state.chatingSlice.BroadCastChat)
    function sendMessage() {
        if (message != "") {
            socket.emit("BROADCAST_MESSAGE", { userName: curUser, message: message })
        }
        else {
            setErr(true)
        }
    }
    return (
        <>
            <div style={{ height: "72vh" }}>
                {
                    broadCastMessages.map((key: any, value: any) => (
                        key.userName == curUser ?
                            <div className="container d-flex justify-content-end" key={value}>
                                <p className="bg-dark text-light p-3 rounded">
                                    {key.message}
                                    <i className="ml-5 fa fa-solid fa-check-double" style={{ color: " #74C0FC" }}></i>
                                </p>
                                <p className="mt-4 ml-2">You</p>
                            </div> :
                            <div className="container d-flex justify-content-start" key={value}>
                                <p className="mt-4 mr-2">{key.userName}</p>
                                <p className="bg-secondary text-light p-3 rounded">
                                    {key.message}
                                </p>
                            </div>
                    ))
                }
            </div>
            <div className="container mt-4">
                <div className="form-group d-flex justify-content-center ">
                    <input type="text" className="form-control border border-dark mr-3 w-100" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Enter A Message" />
                    <button className="btn btn-primary" onClick={() => sendMessage()}><i className="fa fa-regular fa-paper-plane"></i></button>

                </div>{
                    err ?
                        <span className="text-danger">Please Enter Message</span>
                        : <></>
                }
            </div>
        </>
    )
}