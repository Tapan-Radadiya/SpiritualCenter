'use client'
import { useForm } from "react-hook-form"
import { Userlogin } from "../interfaces/login.interface"
import { useEffect, useState } from "react"
import ApiResponse from "@/utils/ApiResponse"
import { useRouter } from "next/navigation"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
import { socket } from "../../socket"

export default function LoginComponent() {
    document.title = "Login | Spiritual Center"
    const router = useRouter()


    const [showOtp, setShowOtp] = useState(false)
    const [userValidated, setUserValidated] = useState(false)
    const [userName, setUserName] = useState("")
    const { register, formState: { errors }, handleSubmit, setError } = useForm<Userlogin>({ mode: "onBlur" })


    async function userLoginData(user_data: Userlogin) {
        if (!userValidated) {
            toast.loading("Loggin You In Please Wait . . .")
            const { statusCode, message, data }: any = await userLoginService(user_data)
            if (statusCode == 200) {
                if (data.Role == "ADMIN") {
                    setUserValidated(true)
                    setUserName(data.Username)
                    socket.connect()
                    router.push("/admin/userlist")
                    toast.dismiss()
                    toast.success(`Welcome ${userName}`)
                }
                else if (data.Role == "DEVOTEE") {
                    setUserName(data.Username)
                    setUserValidated(true)
                    setShowOtp(true)
                    toast.dismiss()
                    toast.success("Otp Has Been Sent To Your EmailId")
                }
            }
            else if (statusCode == 422) {
                toast.dismiss()
                toast.warning(message)
                return
            }
            else {
                toast.dismiss()
                toast.error(message)
                return
            }
        }
        else if (userValidated) {
            if (!user_data.Otp) {
                return setError("Otp", { message: "Otp is required" })
            }
            else if (user_data.Otp != "000000") {
                return setError("Otp", { message: "Invalid Otp" })
            }
            else {
                toast.dismiss()
                toast.success(`Welcome ${userName}`)
                socket.connect()
                router.push("/devotee/mypayments")
            }
        }
    }

    async function userLoginService(user_data: Userlogin) {
        const sendReq = await fetch("http://localhost:3000/api/login", {
            method: "POST",
            body: JSON.stringify(user_data)
        })
        const { statusCode, message, data } = await sendReq.json()
        return ApiResponse(statusCode, message, data)
    }

    return (
        <>
            <div className="container mt-4">
                <p className="display-6 text-center text-uppercase" style={{ letterSpacing: "3px", fontWeight: "500" }}>Welcome To Spiritual Center</p>
            </div>
            <div className="container mt-5">
                <div className="container row p-4 border border-dark" style={{ borderRadius: "20px" }}>
                    <div className="container col-md p-4 m-1">
                        <p className="text-uppercase text-left" style={{ marginTop: "70px", fontSize: "30px" }}>Spiritual Center</p>
                        <p className="text-left mt-4 mr-5" style={{ fontSize: "18px" }}>The mystical place exists within you and can be accessed through practices like <span className="text-success"> yoga and meditation </span>, which often encourage you to &quot;ground and center&quot; yourself. Your spiritual center is where you feel completely at ease with yourself and your surroundings.</p>
                    </div>
                    <div className="container col-md p-4 m-1">
                        <h1 className="text-center" style={{ letterSpacing: "2px", fontWeight: "200" }}>Login</h1>
                        <div className="container">
                            <form onSubmit={handleSubmit((data) => userLoginData(data))} >
                                <div className="form-group mt-4">
                                    <label htmlFor="username" className="form-label">Username</label>
                                    <input type="text" {...register("UserName", {
                                        required: { value: true, message: "Username is required" }
                                    })} id="username" className="form-control border border-dark" />
                                    {errors.UserName && <span id="usernameErr" className="text-danger">{errors.UserName.message}</span>}
                                </div>
                                <div className="form-group mt-4">
                                    <label htmlFor="username" className="form-label">Password</label>
                                    <input type="password" {...register("Password", {
                                        required: { value: true, message: "Password is required" }
                                    })} id="password" className="form-control border border-dark" />
                                    {errors.Password && <span id="passwordErr" className="text-danger">{errors.Password.message}</span>}
                                </div>
                                <div className="form-group mt-4">
                                    <label htmlFor="role" className="form-label">Role</label>
                                    <select id="role" {...register("Role", {
                                        required: { value: true, message: "Role is required" }
                                    })} className="form-select border border-dark">
                                        <option value="">- - Select Role- - </option>
                                        <option value="ADMIN">Admin</option>
                                        <option value="DEVOTEE">Devotee</option>
                                    </select>
                                    {errors.Role && <span id="roleErr" className="text-danger">{errors.Role.message}</span>}
                                </div>

                                {
                                    showOtp ? <div className="form-group mt-4">
                                        <label htmlFor="otp" className="form-label">Enter Otp</label>
                                        <input type="text" {...register("Otp")} id="otp" className="form-control border border-dark" />
                                        {errors.Otp && <span id="otpErr" className="text-danger">{errors.Otp.message}</span>}
                                    </div> : <></>
                                }

                                <div className="form-group mt-5">
                                    <button className="btn w-100 btn-success" id="submit" style={{ fontSize: "20px" }}>
                                        Submit Credential
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}