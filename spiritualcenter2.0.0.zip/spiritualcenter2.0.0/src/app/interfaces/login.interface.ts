export interface Userlogin {
    UserName:string,
    Password:string,
    Role:string,
    Otp?:string,
}