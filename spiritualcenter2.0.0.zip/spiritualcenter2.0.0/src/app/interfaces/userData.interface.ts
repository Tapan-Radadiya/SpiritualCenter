export interface User_Interface {
    First_Name: String
    Middle_Name: String
    Last_Name: String
    UserName: String
    Password: String
    Email_Id: String
    Initiation_Date: Date
    Flat_Number: Number
    Area: String
    City: String
    State: String
    PinCode: String
    ImageUrl?: String
    Status: String,
    isOnline: Boolean
}