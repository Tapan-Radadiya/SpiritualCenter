// import { Car, carList } from "./car"

export let carOwnerList: CarOwner[] = []
interface CarOwner_Inerface {
    owner_emailId: string
    owner_name: string
    owner_mobileNo: number
    owner_gender: string
    car_Id: string
    owner_password: string
    addCarOwner(carOwnerData: CarOwner): void
    displayCarOwner(): Array<CarOwner>
    validateCarOwner(ownerId: string, ownerPass: string): CarOwner
    removeCarOwner(carId: string): void
}

export class CarOwner implements CarOwner_Inerface {
    owner_emailId: string
    owner_name: string
    owner_mobileNo: number
    owner_gender: string
    car_Id: string
    owner_password: string
    constructor(
        owner_emailId: string,
        owner_name: string,
        owner_mobileNo: number,
        owner_gender: string,
        car_Id: string,
        owner_password: string,
    ) {
        this.owner_emailId = owner_emailId
        this.owner_name = owner_name
        this.owner_mobileNo = owner_mobileNo
        this.owner_gender = owner_gender
        this.car_Id = car_Id
        this.owner_password = owner_password
    }
    validateCarOwner(ownerId: string, ownerPass: string): CarOwner {
        throw new Error("Method not implemented.")
    }
    addCarOwner(carOwnerData: CarOwner): void {
        carOwnerList.push(carOwnerData)
    }
    displayCarOwner(): CarOwner[] {
        return carOwnerList
    }
    removeCarOwner(carId: string): void {
        for (let i of carOwnerList) {
            if (carId == i.car_Id) {
                carOwnerList.splice(carOwnerList.indexOf(i), 1)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------

export function displayCarOwner() {
    return carOwnerList
}
export function removeCarOwner(carId: string): void {
    for (let i of carOwnerList) {
        if (carId == i.car_Id) {
            carOwnerList.splice(carOwnerList.indexOf(i), 1)
        }
    }
}
export function validateCarOwner(carOwnerId: string, carOwnerPass: string):CarOwner {
    for (let i of carOwnerList) {
        if (carOwnerId == i.owner_emailId && carOwnerPass == i.owner_password) {
            return i
        }
    }
    return new CarOwner("","",0,"","",""); // Sending empty object 
}