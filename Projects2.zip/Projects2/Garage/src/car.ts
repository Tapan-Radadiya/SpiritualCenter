export let carList: Array<Car_interface> = []
export interface Car_interface {
    car_Id: string // Generate by adding brand+model+year
    car_Brand: string
    car_model: string
    car_model_year: number
    car_type: string
    car_in_date: string
    car_out_date: string
    car_issue: string
    car_ownerId: string // Generate by adding brand+model+ownerName+last 4 digit mob number
    car_status: CarStatus
    car_expance: number
    addCar(ele: Car): void
    displayCars(): Array<Car>
    removeCar(carId: string): void
    changeCarStatus(carId: string, carStatus: string): Boolean
}

export class Car implements Car_interface {
    car_Id: string
    car_Brand: string
    car_model: string
    car_model_year: number
    car_type: string
    car_in_date: string
    car_out_date: string
    car_issue: string
    car_ownerId: string
    car_status: CarStatus
    car_expance: number
    constructor(car_Id: string, car_Brand: string, car_model: string, car_model_year: number, car_type: string, car_in_date: string, car_out_date: string, car_issue: string, car_ownerId: string, car_status: CarStatus, car_expance: number) {
        this.car_Id = car_Id
        this.car_Brand = car_Brand
        this.car_model = car_model
        this.car_model_year = car_model_year
        this.car_type = car_type
        this.car_in_date = car_in_date
        this.car_out_date = car_out_date
        this.car_issue = car_issue
        this.car_ownerId = car_ownerId
        this.car_status = car_status
        this.car_expance = car_expance
    }
    changeCarStatus(carId: string, carStatus: string): Boolean {
        console.log(carId);
        console.log(carStatus);       
        return true
    }
    removeCar(carId: string): void {
        console.log("Remove Car");

        for (let i of carList) {
            if (carId == i.car_Id) {
                let carIndex = carList.indexOf(i)
                carList.splice(carIndex - 1, 1)
            }
        }
    }
    addCar(ele: Car): void {
        carList.push(ele)
    }
    displayCars(): Car[] {
        return carList
    }
}

export enum CarStatus {
    Outside_Garage,
    Inside_Garage,
    Working_Start,
    Working_End,
    Washing,
    Work_Completed,
    Payment_Pending,
    Payment_Complete
}

export function displayCars(): Car[] { return carList }

export function removeCar(carId: string): void {
    console.log("Remove Car");

    for (let i of carList) {
        if (carId == i.car_Id) {
            carList.splice(carList.indexOf(i), 1)
        }
    }
}

export function changeCarStatus(carOwnerId: string, curCarStatus: number): Boolean {
    for (let i of carList) {
        if (carOwnerId == i.car_ownerId) {
            i.car_status = curCarStatus
            return true
        }
    }
    return false
}