export let expanceList: Expance[] = []
interface Expance_interface {
    expancefor: string
    expance: number
    productQuantity: number
    expanceDate: string
   readonly totalExpance: number
    addExpance(expance:Expance):void
}

export class Expance implements Expance_interface {
    expancefor: string
    expance: number
    productQuantity: number
    expanceDate: string
    totalExpance: number
    constructor(expancefor: string,
        expance: number,
        productQuantity: number,
        expanceDate: string,
        totalExpance: number,) {
        this.expancefor = expancefor
        this.expance = expance
        this.productQuantity = productQuantity
        this.expanceDate = expanceDate
        this.totalExpance = totalExpance
    }
    addExpance(expance: Expance): void {
        expanceList.push(expance)
    }
}

export function addSalary() {
    let salaryDate = new Date().getDate()
    if (salaryDate == 12) {
        let salaryDate = new Date().toLocaleDateString("en-US")
        let totalSalary = 5 * 5000
        let salaryObj = new Expance("Salary",5000,5,salaryDate,totalSalary)
        expanceList.push(salaryObj)
    }
}