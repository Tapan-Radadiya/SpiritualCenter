import { Car,carList } from "./car"

// Payment method
export interface GarageOwner_Interface {
    Garage_Name:string
    Garage_Address:string
    Garage_MobileNo:number
    Garage_EmailId:string
    Garage_CarList:Car[]
}
export class GarageOwner implements GarageOwner_Interface{
    Garage_Name:string
    Garage_Address:string
    Garage_MobileNo:number
    Garage_EmailId:string
    Garage_CarList:Car[]
    constructor(Garage_Name:string,
        Garage_Address:string,
        Garage_MobileNo:number,
        Garage_EmailId:string,
        Garage_CarList:Car[]){
            this.Garage_Name = Garage_Name
            this.Garage_Address = Garage_Address
            this.Garage_MobileNo = Garage_MobileNo
            this.Garage_EmailId = Garage_EmailId
            this.Garage_CarList = Garage_CarList
        }

}

let curGarageOwner = new GarageOwner("Janta","High Street",1234567890,"janta.garage@janta.com",carList)


export function setGarageData(){
    $("#garageOwner").text(`Owner : ${curGarageOwner.Garage_Name} |`)
    $("#garageAddr").text(`Address : ${curGarageOwner.Garage_Address} |`)
    $("#email").html("<i class='fa fa-envelope'></i>").text(`Email Id : ${curGarageOwner.Garage_EmailId} | `)
    $("#mobile").html(" <i class='fa fa-phone'></i>").text(`Mobile number : ${curGarageOwner.Garage_MobileNo} |`)
}