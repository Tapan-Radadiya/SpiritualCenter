import { Car, CarStatus } from "../car"
import { Invoice_list, invoiceDataType } from "../Invoice"
import { CarOwner } from "../car_owner"
import { Expance } from "../expance"

let carData = [
    {
        car_Id: "1",
        car_Brand: "BMW",
        car_model: "X5",
        car_model_year: 2002,
        car_type: "FWD",
        car_in_date: "2/22/2024",
        car_out_date: "2/22/2024",
        car_issue: "Washing",
        car_ownerId: "adam@gmail.com",
        car_status: CarStatus.Inside_Garage,
        car_expance: 1000
    },
    {
        car_Id: "2",
        car_Brand: "Kia",
        car_model: "Seltos",
        car_model_year: 2022,
        car_type: "FWD",
        car_in_date: "2/25/2024",
        car_out_date: "2/28/2024",
        car_issue: "Engine break",
        car_ownerId: "john@gmail.com",
        car_status: CarStatus.Payment_Complete,
        car_expance: 50000
    },
    {
        car_Id: "3",
        car_Brand: "Hyundai",
        car_model: "Elentra",
        car_model_year: 2024,
        car_type: "FWD",
        car_in_date: "1/1/2024",
        car_out_date: "1/5/2024",
        car_issue: "Tyre change",
        car_ownerId: "micky@gmail.com",
        car_status: CarStatus.Washing,
        car_expance: 20000
    },
    {
        car_Id: "4",
        car_Brand: "Hyundai",
        car_model: "Elentra",
        car_model_year: 2023,
        car_type: "FWD",
        car_in_date: "1/1/2024",
        car_out_date: "1/10/2024",
        car_issue: "Accidental car",
        car_ownerId: "Oliver@gmail.com",
        car_status: CarStatus.Washing,
        car_expance: 100000
    },
    {
        car_Id: "5",
        car_Brand: "Kia",
        car_model: "Seltos",
        car_model_year: 2023,
        car_type: "4WD",
        car_in_date: "3/1/2024",
        car_out_date: "3/5/2024",
        car_issue: "Windshieled change",
        car_ownerId: "james@gmail.com",
        car_status: CarStatus.Payment_Pending,
        car_expance: 150000,
    }
]
carData.forEach((ele) => {
    let carObj = new Car(ele.car_Id, ele.car_Brand, ele.car_model, ele.car_model_year, ele.car_type, ele.car_in_date, ele.car_out_date, ele.car_issue, ele.car_ownerId, ele.car_status, ele.car_expance)
    carObj.addCar(carObj)
})


let invoiceTempData: invoiceDataType[] = [
    {
        car_Id: "1",
        car_in_date: "2/23/2024",
        car_out_date: "2/25/2024",
        invoiceDate: "3/10/2024",
        car_expance: 1000,
        car_ownerId: "archie@gmail.com",
        car_issue: "Washing",
        car_owner_name: "Archie",
        car_Payement_Method: 1
    },
    {
        car_Id: "2",
        car_in_date: "2/20/2024",
        car_out_date: "2/29/2024",
        invoiceDate: "2/11/2024",
        car_expance: 50000,
        car_ownerId: "ashton@gmail.com",
        car_issue: "Engine break",
        car_owner_name: "Ashton",
        car_Payement_Method: 2
    },
    {
        car_Id: "3",
        car_in_date: "1/5/2024",
        car_out_date: "1/8/2024",
        invoiceDate: "1/17/2024",
        car_expance: 5000,
        car_ownerId: "oscar@gmail.com",
        car_issue: "Break repair",
        car_owner_name: "Oscar",
        car_Payement_Method: 3
    }
]
invoiceTempData.forEach((ele) => {
    Invoice_list.push(ele)
})


let carOwnerData = [
    {
        owner_emailId: "adam@gmail.com",
        owner_name: "Adam",
        owner_mobileNo: 3364457420,
        owner_gender: "male",
        car_Id: "1",
        owner_password: "AdamX57420"
    },
    {
        owner_emailId: "john@gmail.com",
        owner_name: "John",
        owner_mobileNo: 6265988004,
        owner_gender: "male",
        car_Id: "2",
        owner_password: "JohnSelt8004"
    },
    {
        owner_emailId: "micky@gmail.com",
        owner_name: "Micky",
        owner_mobileNo: 3697516998,
        owner_gender: "female",
        car_Id: "3",
        owner_password: "MickyElen6998"
    },
    {
        owner_emailId: "Oliver@gmail.com",
        owner_name: "Oliver",
        owner_mobileNo: 9765234700,
        owner_gender: "female",
        car_Id: "4",
        owner_password: "OliverElen4700"
    },
    {
        owner_emailId: "james@gmail.com",
        owner_name: "James",
        owner_mobileNo: 9637292200,
        owner_gender: "male",
        car_Id: "5",
        owner_password: "JamesSelt2200"
    },
]

carOwnerData.forEach((element) => {
    let carOwnerObj = new CarOwner(element.owner_emailId, element.owner_name, element.owner_mobileNo, element.owner_gender, element.car_Id, element.owner_password)
    carOwnerObj.addCarOwner(carOwnerObj)
})

let expanceData = [
    {
        expancefor: "Windshield",
        expance: 200,
        expanceDate: "2/22/2024",
        productQuantity: 2,
        totalExpance: 800
    },
    {
        expancefor: "Tyres",
        expance: 2000,
        expanceDate: "2/25/2024",
        productQuantity: 20,
        totalExpance: 8000
    },
    {
        expancefor: "Seat",
        expance: 4000,
        expanceDate: "3/15/2024",
        productQuantity: 10,
        totalExpance: 16000
    },
    {
        expancefor: "Salary",
        expance: 5000,
        expanceDate: "3/1/2024",
        productQuantity: 5,
        totalExpance: 20000
    },
    {
        expancefor: "Car Hood",
        expance: 20000,
        expanceDate: "11/2/2023",
        productQuantity: 2,
        totalExpance: 40000
    }
]
expanceData.forEach((element) => {
    let expanceObj = new Expance(element.expancefor, element.expance, element.productQuantity, element.expanceDate, element.totalExpance)
    expanceObj.addExpance(expanceObj)
})