import { Invoice_list } from "./Invoice"
import { expanceList } from "./expance"
export function printAccDetails(monthId: number, year: number) {
    displayIncome(monthId, year)
    displayExpance(monthId, year)
    printTotalAmount()
}
console.log("Invoice Data ", Invoice_list);

// Filter data
function displayIncome(monthId: number, year: number): void {
    let total_income: number = 0
    $("#table_body_account_data").html("")
    for (let i of Invoice_list) {
        let invoiceDate = new Date(i.invoiceDate).getMonth()
        let invoiceYear = new Date(i.invoiceDate).getFullYear()
        console.log("--->", invoiceYear);

        if (monthId == invoiceDate && year == invoiceYear) {
            let tableRow = $("<tr></tr>").appendTo($("#table_body_account_data"))
            $("<td></td>").text(i.car_Id).appendTo($(tableRow))
            $("<td></td>").text(i.car_in_date).appendTo($(tableRow))
            $("<td></td>").text(i.car_out_date).appendTo($(tableRow))
            $("<td></td>").text(i.invoiceDate).appendTo($(tableRow))
            $("<td></td>").text(i.car_issue).appendTo($(tableRow))
            $("<td></td>").text(i.car_owner_name).appendTo($(tableRow))
            $("<td></td>").text(i.car_ownerId).appendTo($(tableRow))
            $("<td></td>").text(i.car_Payement_Method).appendTo($(tableRow))
            $("<td></td>").text(i.car_expance).css("color", "green").appendTo($(tableRow))
            total_income += i.car_expance
        }
    }
    let amountRow = $("<tr></tr>").appendTo($("#table_body_account_data"))
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").text("Total Income").appendTo(amountRow)
    $("<td></td>").text(total_income).attr("id", "total_income").appendTo(amountRow)
}

function displayExpance(monthId: number, year: number): void {
    let total_expance = 0
    $("#table_body_expance_data").html("")

    for (let i of expanceList) {
        let expanceDate = new Date(i.expanceDate).getMonth()
        let invoiceYear = new Date(i.expanceDate).getFullYear()
        if (expanceDate == monthId && year == invoiceYear) {
            let tableRow = $("<tr></tr>").appendTo($("#table_body_expance_data"))
            $("<td></td>").text(i.expancefor).appendTo($(tableRow))
            $("<td></td>").text(i.expance).appendTo($(tableRow))
            $("<td></td>").text(i.productQuantity).appendTo($(tableRow))
            $("<td></td>").text(i.expanceDate).appendTo($(tableRow))
            $("<td></td>").text(i.totalExpance).css("color", "red").appendTo($(tableRow))
            total_expance += i.totalExpance
        }
    }
    let amountRow = $("<tr></tr>").appendTo($("#table_body_expance_data"))
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").appendTo(amountRow)
    $("<td></td>").text("Total : Expance").appendTo(amountRow)
    $("<td></td>").text(total_expance).attr("id", "total_expance").appendTo(amountRow)
}
function printTotalAmount() {
    let income = Number($("#total_income").text())
    let expance = Number($("#total_expance").text())
    let totalProfit = income - expance
    if (totalProfit <= 0) {
        $("#total_profit").attr("class", "text-danger").text(`Total Loss ${totalProfit}`)
    }
    else {
        $("#total_profit").attr("class", "text-success").text(`Total Profit ${totalProfit}`)
    }
}