import { displayCars, Car, carList, CarStatus, removeCar, changeCarStatus } from "./car" //changeCarStatus,
import { printAccDetails } from "./accountDetails"
import { CarOwner, carOwnerList, validateCarOwner, displayCarOwner, removeCarOwner } from "./car_owner"
import { Invoice } from "./Invoice"
import { Expance } from "./expance"
import { setGarageData } from "./garage_owner"

// --------------------------------------------------------------------------

// Login validation
// localStorage.setItem("ownerLogin", "janta.garage@garage.com")
// localStorage.setItem("ownerPassword", "Janta.garage@123")
setGarageData()
let carBrandData
async function carData() {
  let data = await fetch("src/Data/carBrands.json")
  carBrandData = await data.json()
  return carBrandData
}
await carData()


localStorage.setItem("ownerLogin", "admin")
localStorage.setItem("ownerPassword", "admin")

$("#garage_owner_btn").on("click", function () {
  let garageOwnerId = $("#garage_owner_id").val()
  let garageOwnerPass = $("#garage_owner_pass").val()
  let ownerId = localStorage.getItem("ownerLogin")
  let ownerPassword = localStorage.getItem("ownerPassword")

  if (ownerId == garageOwnerId && ownerPassword == garageOwnerPass) {
    $(".frontPage").hide()
    $("#home_btn").show()
    $(".ownerPage").show()
  }
  else {
    alert("Wrong ")
  }
})
// Responsive Nav Button

$("#displayNav").on("click", function () {
  let className = $(".topNav").attr("class")
  if (className === "topNav") {
    $(".topNav").addClass(" responsive")
  }
  else {
    $(".topNav").attr("class", "topNav")
  }
})
$(".btnNav").on("click", function () {
  $(".topNav").removeClass(" responsive")
})

$("#garage_owner").on("click", function () {
  $(".car_owner_login").hide()
  $(".garage_owner_login").slideToggle(500)
})

$("#car_owner").on("click", function () {
  $(".garage_owner_login").hide()
  $(".car_owner_login").slideToggle(500)
})




let quant = 1
while (quant <= 16) {
  $("<option></option>").text(quant).attr("value", quant).appendTo("#quantity_select")
  quant += 1
}
// Adding month names to the select / option

let monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
let monthData = 0
let curMonth = new Date().getMonth()
while (monthData <= 11) {
  if (monthData == curMonth) {
    $("<option></option>").text(monthNames[monthData]).attr({ "selected": true, "value": monthData }).appendTo($("#filter_month"))
  }
  $("<option></option>").text(monthNames[monthData]).attr("value", monthData).appendTo($("#filter_month"))
  monthData += 1
}

// calculate  
$("#expance_form").on("change", function () {
  let totalExpance: number = 0
  let expanceVal = Number($("#expance").val())
  let quan = Number($("#quantity_select").val())
  if (isNaN(expanceVal)) {
    $("#expanceErr").text("Numbers only*").removeAttr("hidden")
  }
  totalExpance = expanceVal * quan
  $("#total_expance_input").val(totalExpance)
})

$("#add_expance").on("click", function () {
  if (!$("#expance_for").val()) {
    $("#expanceForErr").removeAttr("hidden")
    return
  }
  else if (!$("#expance").val()) {
    $("#expanceErr").removeAttr("hidden")
    return
  }
  else if (!$("#expance_date").val()) {
    $("#expanceDateErr").removeAttr("hidden")
    return
  }
  let expance_for = String($("#expance_for").val())
  let expance = Number($("#expance").val())
  let productQuan = Number($("#quantity_select").val())
  let expanceDate: string = new Date(String($("#expance_date").val())).toLocaleDateString("en-US")
  let total_expance = Number($("#total_expance_input").val())

  let expanceObj = new Expance(expance_for, expance, productQuan, expanceDate, total_expance)
  expanceObj.addExpance(expanceObj)
  $("input").val("")
  $("span").val("")
})

$("#goback").on("click", function () {
  $("#add_car_div").show()
  $(".invoice").hide()
  $(".account_details").show()
  $("#display_cars").hide()
  $("#add_car_owner_div").hide()
  $(".car_owner_details").hide()
})
$(".home_btn").on("click", function () {
  $(".frontPage").show()
  $(this).hide()
  $(".car_owner_login").hide()
  $(".garage_owner_login").hide()
  $(".ownerPage").hide()
})
$("#home_btn_car_owner").on("click", function () {
  $(".frontPage").show()
  $(this).hide()
  $(".car_owner_page").hide()
})


// Invoice field

// View cars





// Check account
$("#check_account").on("click", function () {
  // addSalary()
  printAccDetails(Number($("#filter_month").val()), Number($("#filter_year").val()))
  $(".account_details").show()
  $(".invoice").hide()
  $("#add_car_div").hide()
  $(".car_owner_details").hide()
  $("#display_cars").hide()
  $(".garage_expance_div").hide()
})
$("#garage_expance").on("click", function () {
  $(".account_details").hide()
  $(".invoice").hide()
  $("#add_car_div").hide()
  $(".car_owner_details").hide()
  $("#display_cars").hide()
  $(".garage_expance_div").show()
})
$("#monthFilterBtn").on("click", function () {
  printAccDetails(Number($("#filter_month").val()), Number($("#filter_year").val()))
})

// --------------------Add Car Functions---------------------------
$("#btn_add_car").on("click", function () {
  $("#add_car_div").show()
  $(".account_details").show()
  $(".account_details").hide()
  $(".invoice").hide()
  $(".car_owner_details").hide()
  $("#display_cars").hide()
  $(".garage_expance_div").hide()
})

let carBrandName = Object.keys(await carData())
carBrandName.forEach((ele) => {
  $("<option></option>").text(ele).attr("value", ele).appendTo("#car_brand")
})

$("#car_brand").on("change", async function () {
  let data = await carData()
  $("#car_model").html("")
  for (let i in data) {
    if (i == $(this).val()) {
      let carModel = Object.keys(data[i])
      carModel.forEach((ele) => {
        $("<option></option>").text(ele).appendTo($("#car_model"))
      })
    }
  }
})
$("#car_model").on("change", async function () {
  let data = await carData()
  $("#car_model_year").html("")
  data = data[String($("#car_brand").val())][String($(this).val())]
  for (let i of data) {
    $("<option></option>").text(i).appendTo($("#car_model_year"))
  }
})

// Car add page validation
$("#next_page").on("click", function () {
  if (!$("#car_id").val()) {
    $("#carIdErr").text("Please Enter Car Chassis Number*").removeAttr("hidden")
    return
  }
  else if (!$("#car_brand").val()) {
    $("#carBrandErr").removeAttr("hidden")
    return
  }
  else if (!$("#car_model").val()) {
    $("#carModelErr").removeAttr("hidden")
    return
  }
  else if (!$("#car_model_year").val()) {
    $("#carModelYearErr").removeAttr("hidden")
    return
  }
  else if (!$("#car_type").val()) {
    $("#carCarTypeErr").removeAttr("hidden")
    return
  }
  else if (!$("#car_in_date").val()) {
    $("#carInDateErr").removeAttr("hidden")
    return
  }
  else if (!$("#car_out_date").val()) {
    $("#carOutDateErr").removeAttr("hidden")
    return
  }
  else if (!$("#issue_car").val()) {
    $("#carIssueErr").removeAttr("hidden")
    return
  }
  else if (!$("#expected_expance").val()) {
    $("#carExpanceErr").removeAttr("hidden")
    return
  }
  else {
    let todaysDate = new Date().getTime()
    let curDateIn: number = new Date(String($("#car_in_date").val())).getTime()
    let curDateOut: number = new Date(String($("#car_out_date").val())).getTime()
    if (curDateOut < curDateIn) {
      alert("Date should not be lesser than car in date")
      return
    }
    else if (curDateIn < todaysDate) {
      alert("Please select date from today")
      return
    }
    for (let i of carList) {
      if ($("#car_id").val() == i.car_Id) {
        $("#carIdErr").text("Car Already There").removeAttr("hidden")
        return
      }
    }
    $("#add_car_div").hide()
    $("#add_car_owner_div").show()
  }
})

// Car owner page validation
let displayCarData
$("#addCar").on("click", function () {
  if (!$("#owner_name").val()) {
    $("#ownerNameErr").removeAttr("hidden")
  }
  else if (!$("#owner_emailId").val()) {
    $("#ownerEmailErr").text("Please Enter Car Owner Email Id*").removeAttr("hidden")
  }
  else if (!$("#owner_mobile").val()) {
    $("#ownerMobErr").removeAttr("hidden")
  }
  else if (!$("input[name=gender]:checked").val() === undefined) {
    $("#genderErr").removeAttr("hidden")
  }
  else {

    for (let i of carOwnerList) {
      if ($("#owner_emailId").val() == i.owner_emailId) {
        $("#ownerEmailErr").text("Email Id already exist").removeAttr("hidden")
        return
      }
      else if ($("#owner_mobile").val() == i.owner_mobileNo) {
        $("#ownerMobErr").text("Mobile number already in use").removeAttr("hidden")
        return
      }
      // else {
      //   let mobNumber:string = String($("#ownerMobErr").val())
      //   const regexMob = /^([0-9]{10})/
      //   console.log("Reges result ",!regexMob.test(mobNumber));        
      //   if(!regexMob.test(mobNumber)){
      //     $("#ownerMobErr").text("Provide Valid Mobile Number").removeAttr("hidden")
      //     return
      //   }
      // }
    }
    $("#alertMessage").text("Car Added Successfully")
    $(".alert").slideDown(500, function () {
      setTimeout(() => {
        $(this).slideUp(500)
      }, 2000)
    })
    let carId = String($("#car_id").val())
    let car_brand = String($("#car_brand").val())
    let car_model = String($("#car_model").val())
    let car_model_year = Number($("#car_model_year").val())
    let car_type = String($("#car_type").val())
    let car_in_date: string = new Date(String($("#car_in_date").val())).toLocaleDateString("en-US")
    let car_out_date: string = new Date(String($("#car_out_date").val())).toLocaleDateString("en-US")
    let car_issue = String($("#issue_car").val())
    let car_expance = Number($("#expected_expance").val())
    let owner_name = String($("#owner_name").val())
    let owner_email = String($("#owner_emailId").val())
    let owner_mobile = Number($("#owner_mobile").val())
    let gender = String($("input[name=gender]:checked").val())
    const carStatus = CarStatus.Outside_Garage
    let carObj = new Car(carId, car_brand, car_model, car_model_year, car_type, car_in_date, car_out_date, car_issue, owner_email, carStatus, car_expance)

    let carOwnerPassword = owner_name + car_model + (owner_mobile.toString().slice(6, 10))
    let carOwnerObj = new CarOwner(owner_email, owner_name, owner_mobile, gender, carId, carOwnerPassword)
    carObj.addCar(carObj)
    displayCarData = carObj.displayCars()

    carOwnerObj.addCarOwner(carOwnerObj)
    printCarOwnerData()
    alert(`Car owner ID:${owner_email} || Car Owner Password: ${carOwnerPassword}`)
    $("input").val("")
    $("span").val("")
    $("#add_car_div").show()
    $(".invoice").hide()
    $("#display_cars").hide()
    $("#add_car_owner_div").hide()
  }
})
$("#total_cars").text()

// ----------------------------------display Car Class Functionss------------------------------------

$("#view_cars").on("click", function () {

  $("#table_body").html("")
  $("#display_cars").show()
  $(".invoice").hide()
  $(".account_details").hide()
  $("#add_car_owner_div").hide()
  $(".car_owner_details").hide()
  $(".garage_expance_div").hide()
  $("#add_car_div").hide()
  printCars()
})

let carStatus: string[] = ["Outside_Garage", "Inside_Garage", "Working_Start", "Working_End", "Washing", "Work_Completed", "Payment_Pending", "Payment_Completed"]
let carStatusnum = 0
carStatus.forEach((element) => {
  $("<option></option>").text(element).attr("value", carStatusnum).appendTo($("#carStatus"))
  carStatusnum++
})

function printCars(): void {
  $("#table_body").html("")

  console.log("---->", displayCars);

  let carList = displayCars()
  console.log("Car list ata", carList);

  if (carList.length === 0) {
    alert("No Data")
  }
  else {
    for (let i of carList) {
      let tableRow = $("<tr></tr>")
      $("<td></td>").text(i.car_Id).appendTo($(tableRow))
      $("<td></td>").text(i.car_Brand).appendTo($(tableRow))
      $("<td></td>").text(i.car_model).appendTo($(tableRow))
      $("<td></td>").text(i.car_model_year).appendTo($(tableRow))
      $("<td></td>").text(i.car_type).appendTo($(tableRow))
      $("<td></td>").text(String(i.car_in_date)).appendTo($(tableRow))
      $("<td></td>").text(String(i.car_out_date)).appendTo($(tableRow))
      $("<td></td>").text(i.car_issue).appendTo($(tableRow))
      $("<td></td>").text(carStatus[i.car_status]).appendTo($(tableRow))
      $("<td></td>").text(i.car_expance).appendTo($(tableRow))
      $("<td></td>").text(i.car_ownerId).appendTo($(tableRow))
      let button = $("<td></td>").appendTo($(tableRow))
      let editBtn = $("<button></button>").html("<i class='fa fa-edit'></i>").text("Change Status").attr("id", i.car_Id).attr("class", "btn btn-outline-success m-1").appendTo($(button))

      tableRow.appendTo($("#table_body"))

      $($(editBtn)).on("click", function () {
        $(".editCarData").show()
        $("#carOwnerId").text(i.car_ownerId)// Hidden field
        $("#carStatus").val(i.car_status)
      })
    }
  }
}

// car status change
$("#change_status").on("click", function () {
  if (changeCarStatus($("#carOwnerId").text(), Number($("#carStatus").val()))) {
    printCars()
    $(".editCarData").hide()
  }
})
// --------------------------Invoice Insert-------------------
$("#make_invoice").on("click", function () {
  $(".invoice").show()
  $(".account_details").hide()
  $("#add_car_div").hide()
  $(".car_owner_details").hide()
  $("#display_cars").hide()
  $(".garage_expance_div").hide()
  printInvoiceAvailCars()
})
function printInvoiceAvailCars() {
  $("#car_id_invoice").html("")
  for (let i of carList) {
    if (i.car_status == 7) {
      $("<Option></option>").text(i.car_Id).appendTo($("#car_id_invoice"))
    }
  }
}

$("#addInvoice").on("click", function () {
  if (!$("#car_id_invoice").val()) {
    $("#carIdErr_invoice").removeAttr("hidden")
    return
  }
  else if (!$("#payment_method").val()) {
    $("#invoiceMethodErr").removeAttr("hidden")
    return
  }
  let invoiceObj = new Invoice(String($("#car_id_invoice").val()), String($("#payment_method").val()))
  let invoiceStatus = invoiceObj.addInvoice(invoiceObj)
  if (invoiceStatus != "-1") {
    $("#car_id_invoice").val("")
    $("#payment_method").val("")
    removeCar(invoiceStatus)
    removeCarOwner(invoiceStatus)
    printInvoiceAvailCars()
  }
  else {
    $("#alertMessage").text("Error creating invoice try after sometime")
  }
})


// --------------------- Car Owner Functions -----------------------------

$("#owner_details").on("click", function () {
  printCarOwnerData()
  $(".car_owner_details").show()
  $("#add_car_div").hide()
  $(".invoice").hide()
  $(".garage_expance_div").hide()
  $(".account_details").hide()
  $("#display_cars").hide()
  $("#add_car_owner_div").hide()
})
function printCarOwnerData() {
  $("#car_owner_details_table").html("")
  let carOwnerList = displayCarOwner()

  for (let i of carOwnerList) {
    let tableRow = $("<tr></tr>")
    $("<td></td>").text(i.car_Id).appendTo($(tableRow))
    $("<td></td>").text(i.owner_name).appendTo($(tableRow))
    $("<td></td>").text(i.owner_emailId).appendTo($(tableRow))
    $("<td></td>").text(i.owner_gender).appendTo($(tableRow))
    $("<td></td>").text(i.owner_mobileNo).appendTo($(tableRow))
    tableRow.appendTo($("#car_owner_details_table"))
  }
  console.log("--------Car Owners----------");
  console.log(carOwnerList);
}

// --------------------------------Car owner login --------------
$("#car_owner_btn").on("click", function () {
  let carOwnerId = String($("#car_owner_id").val())
  let carOwnerPass = String($("#car_owner_pass").val())
  let ownerValidObj = validateCarOwner(carOwnerId, carOwnerPass)

  if (ownerValidObj.car_Id != "") {
    $(".frontPage").hide()
    $(".car_owner_page").show()
    $("#home_btn_car_owner").show()
    $("#greet").text(`Welcome, ${ownerValidObj.owner_name}`)
    $("#owner_mob_number").text(ownerValidObj.owner_mobileNo)
    $("#owner_emailId_data").text(ownerValidObj.owner_emailId)
    for (let j of carList) {
      if (ownerValidObj.car_Id == j.car_Id) {
        $("#car_name").text(j.car_Brand)
        $("#car_model_data").text(j.car_model)
        $("#car_year_data").text(j.car_model_year)
        $("#car_type_data").text(j.car_type)
        $("#car_in_date_data").text(j.car_in_date)
        $("#car_out_date_data").text(j.car_out_date)
        $("#car_issue_data").text(j.car_issue)
        carStatusChange(j.car_status)
      }
    }
  }
  else{
    alert("Please Provide Right Crediantials")
  }
})
function carStatusChange(curCarStatus: number) {
  switch (curCarStatus) {
      case 0: {
          $("#carStatusProgress").css("width", "5%")
          break;
      }
      case 1: {
          $("#carStatusProgress").css("width", "19%")
          break;
      }
      case 2: {
          $("#carStatusProgress").css("width", "31%")
          break;
      }
      case 3: {
          $("#carStatusProgress").css("width", "44%")
          break;
      }
      case 4: {
          $("#carStatusProgress").css("width", "58%")
          break;
      }
      case 5: {
          $("#carStatusProgress").css("width", "69%")
          break;
      }
      case 6: {
          $("#carStatusProgress").css("width", "82%")
          break;
      }
      case 7: {
          $("#carStatusProgress").css("width", "100%")
          break;
      }
      default: console.log("No status found");
  }
}