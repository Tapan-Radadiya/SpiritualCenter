import { carList } from "./car"
import { carOwnerList } from "./car_owner"
export let Invoice_list: invoiceDataType[] = []
interface Invoice_interface {
    car_Id: string
    car_Payement_Method: string
    addInvoice(invoiceData: Invoice): string //To be changed
}
export type invoiceDataType = {
    car_Id: string
    car_in_date: string
    car_out_date: string
    invoiceDate: string
    car_expance: number
    car_ownerId: string
    car_issue: string
    car_owner_name: string
    car_Payement_Method: number
}
export class Invoice implements Invoice_interface {
    car_Id: string
    car_Payement_Method: string
    constructor(
        car_Id: string,
        car_Payement_Method: string,
    ) {
        this.car_Id = car_Id
        this.car_Payement_Method = car_Payement_Method
    }
    addInvoice(invoiceData: Invoice): string {
        let todaysDate: string = new Date().toLocaleDateString("en-US")
        for (let i of carList) {
            let carOwnerName:string = ""
            if (i.car_Id == invoiceData.car_Id) {
                for(let j of carOwnerList){
                    if(j.owner_emailId == i.car_ownerId){
                        carOwnerName = j.owner_name
                    }
                }
                let createInvoice:invoiceDataType = {
                    car_Id: i.car_Id,
                    car_in_date: i.car_in_date,
                    car_out_date: i.car_out_date,
                    invoiceDate: todaysDate,
                    car_expance: i.car_expance,
                    car_ownerId: i.car_ownerId,
                    car_issue: i.car_issue,
                    car_owner_name: carOwnerName,
                    car_Payement_Method: 0
                }
                Invoice_list.push(createInvoice)
                return invoiceData.car_Id
            }
        }
        return "-1"
    }
}

