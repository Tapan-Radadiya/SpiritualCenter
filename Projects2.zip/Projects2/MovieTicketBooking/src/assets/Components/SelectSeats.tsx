import { useEffect } from "react"
import { useNavigate, useParams } from "react-router-dom"
import PrintSeats from "./PrintSeats"
import { venueDataStruct } from "../../App"
export default function SelectSeats({ venueData, price, setPrice, setBookedSeatsArr, bookedSeatsArr }: any) {
    const { MovieName, venueId } = useParams()
    const navigate = useNavigate()

    let curVenueData: venueDataStruct = {
        VenueId: 0,
        VenueName: "",
        Address: "",
        IsAvailable: false,
        SilverSeats: [],
        GoldSeats: [],
        BalconySeats: [],
        SilverSeatPrice: 0,
        GoldSeatPrice: 0,
        BalconySeatPrice: 0
    }
    venueData.map((key: any, _: any) => {
        if (key.VenueId == venueId) {
            curVenueData.VenueId = key.VenueId
            curVenueData.VenueName = key.VenueName
            curVenueData.IsAvailable = key.IsAvailable
            curVenueData.SilverSeats = key.SilverSeats
            curVenueData.GoldSeats = key.GoldSeats
            curVenueData.BalconySeats = key.BalconySeats
            curVenueData.SilverSeatPrice = key.SilverSeatPrice
            curVenueData.GoldSeatPrice = key.GoldSeatPrice
            curVenueData.BalconySeatPrice = key.BalconySeatPrice
        }
    })
    function checkOut(price: number) {
        navigate(`/checkOut/${MovieName}/${price}/${curVenueData.VenueId}`)
    }
    return (
        <>
            <div className="container p-3 text-center">
                <p className="display-4">Welcome To {curVenueData.VenueName}</p>
                <p className="h3" style={{ fontWeight: "0px" }}>Select your Seats For {MovieName}</p>
            </div>
            <div className="container text-uppercase">
                <span className="dot bg-danger"></span>Booked &nbsp;&nbsp;&nbsp;&nbsp;
                <span className="dot bg-success"></span>Gold &nbsp;&nbsp;&nbsp;&nbsp;
                <span className="dot bg-primary"></span>Silver &nbsp;&nbsp;&nbsp;&nbsp;
                <span className="dot bg-warning"></span>Balcony &nbsp;&nbsp;&nbsp;&nbsp;
            </div>
            <div className="container mt-5 ">
                <div className="row g-4 p-5">
                    {
                        curVenueData.BalconySeats.Balcony.map((key: any, index: any) => (

                            <PrintSeats keyVal={key}
                                indexVal={index}
                                seatType={"baclcony"}
                                venueId={venueId}
                                bookedSeatsArr={bookedSeatsArr}
                                setBookedSeatsArr={setBookedSeatsArr}
                                setPrice={setPrice}
                                venueData={venueData}
                                SilverSeatPrice={key.SilverSeatPrice}
                                GoldSeatPrice={key.GoldSeatPrice}
                                BalconySeatPrice={key.BalconySeatPrice}
                                curVenueData={curVenueData}
                            />
                        ))
                    }
                </div>

                <div className="row g-4 p-5">
                    {
                        curVenueData.GoldSeats.Gold.map((key: any, index: any) => (
                            <PrintSeats keyVal={key}
                                indexVal={index}
                                seatType={"Mezzanine"}
                                venueId={venueId}
                                bookedSeatsArr={bookedSeatsArr}
                                setBookedSeatsArr={setBookedSeatsArr}
                                setPrice={setPrice}
                                venueData={venueData}
                                curVenueData={curVenueData}
                            />
                        ))
                    }
                </div>
                <div className="row g-4 p-5">
                    {
                        curVenueData.SilverSeats.Silver.map((key: any, index: any) => (
                            <PrintSeats keyVal={key}
                                indexVal={index}
                                seatType={"Orchestra"}
                                venueId={venueId}
                                bookedSeatsArr={bookedSeatsArr}
                                setBookedSeatsArr={setBookedSeatsArr}
                                setPrice={setPrice}
                                venueData={venueData}
                                curVenueData={curVenueData}
                            />
                        ))
                    }
                </div>
            </div>
            <div className="container border border-muted border-5 text-center" style={{ marginTop: "100px" }}></div>
            <p className="text-center mt-4 display-6">Screen This Side</p>
            <div className="container-fluid bg-danger p-4 text-white">
                <div className="row">
                    <div className="col-md-8"></div>
                    <div className="col-md-2 text-center">
                        <button className="btn btn-dark text-white p-3 w-100" onClick={() => checkOut(price)}>CheckOut</button>
                    </div>
                    <div className="col-md-2 text-center" style={{ fontSize: "30px" }}>Total {price} ₹</div>
                </div>
            </div>
        </>
    )
}