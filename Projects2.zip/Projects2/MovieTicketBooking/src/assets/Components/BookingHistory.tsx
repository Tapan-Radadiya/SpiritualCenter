import { useNavigate } from "react-router-dom";

export default function BookingHistory({ bookingHistory, setBookingHistory }: any) {
    const navigate = useNavigate()
    function homePage() {
        navigate("/")
    }
    console.log(bookingHistory.length);
    if (bookingHistory.length == 0) {
        return (
            <div>
                <div className="container text-center lead mt-5">
                    <p className="display-6 mt-5">You Have Not Booked Any Tickets Yet</p>
                </div>
                <div className="container text-center mt-5">
                    <button className="btn btn-outline-primary btn-lg p-3" onClick={() => homePage()}>Book Tickets Now</button>
                </div>
            </div>
        )
    }
    else {
        return (
            <><div className="d-flex">
                {
                    bookingHistory.map((key: any, index: any) => (
                        <div className="card m-4 border border-3" key={index} style={{ width: "18rem" }}>
                            <div className="card-body">
                                <p className="card-title">Booked For Movie : <b> {key.MovieName}</b></p>
                                <p className="card-text">Theatre Name :      <b> {key.VenueName}</b></p>
                                <p className='card-text'>Your Booked Seats : <b> {key.Seats.toString()}</b></p>
                                <p className="card-text">Total Purchased :   <b> {key.TotalCost} ₹</b></p>
                            </div>
                        </div>
                    ))
                }
            </div>
                <div className="container text-center mt-5">
                    <button className="btn btn-outline-primary" onClick={() => homePage()}>Go Back To Home Page</button>
                </div>
            </>
        )
    }
}