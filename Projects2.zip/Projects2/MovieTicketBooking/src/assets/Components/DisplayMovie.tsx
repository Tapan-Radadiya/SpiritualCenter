import { useNavigate } from "react-router-dom"

export default function DisplayMovie({ movieData }: any) {
    const navigate = useNavigate()
    function SelectVenue(movieId: number) {
        navigate(`selectVenue/${movieId}`)
    }
    
    return (
        <>
            <div className="container text-center text-uppercase mt-1">
                <p className="display-6">Select Your Movie</p>
            </div>
            <div className="row g-0">
                {
                    movieData.map((key: any, index: any) => (
                        <div className="container w-25 border border-dark text-center col-md-4 p-5" key={index}>
                            <img src={key.MoviePoster} className="card-img-top col-md p-3" alt="" />
                            <div className="card-body col-md">
                                <h5 className="card-title mt-5">{key.MovieName}</h5>
                                <button className="btn btn-outline-primary btn-lg mt-3" onClick={() => SelectVenue(key.MovieId)}>Select Movie</button>
                            </div>
                        </div>
                    ))
                }
            </div>
        </>
    )
}