export default function PrintSeats({ keyVal,
    indexVal,
    seatType,
    setPrice,
    curVenueData,
    setBookedSeatsArr,
    bookedSeatsArr }: any) {

    function selectSeat(seatNo: string, _: number) {
        let silverSeatPrice = curVenueData.SilverSeatPrice
        let goldSeatPrice = curVenueData.GoldSeatPrice
        let balconySeatPrice = curVenueData.BalconySeatPrice
    
        const data = $(`#${seatNo}`).attr("class")
        const seatType = seatNo.charAt(0)


        switch (seatType) {
            case 'A':
                if (data?.includes("outline")) {
                    $(`#${seatNo}`).removeClass()
                    $(`#${seatNo}`).addClass("btn btn-success text-white w-100")
                    setPrice((prevPrice: any) => prevPrice + silverSeatPrice)
                    setBookedSeatsArr([...bookedSeatsArr, seatNo])
                }
                else {
                    $(`#${seatNo}`).removeClass()
                    $(`#${seatNo}`).addClass("btn btn-outline-success w-100")
                    setPrice((prevPrice: any) => prevPrice - silverSeatPrice)
                    setBookedSeatsArr(bookedSeatsArr.filter((seatNo: any) => bookedSeatsArr != seatNo))
                }
                break;
            case 'B':
                if (data?.includes("outline")) {
                    $(`#${seatNo}`).removeClass()
                    $(`#${seatNo}`).addClass("btn btn-primary text-white w-100")
                    setPrice((prevPrice: any) => prevPrice + goldSeatPrice)
                    setBookedSeatsArr([...bookedSeatsArr, seatNo])
                }
                else {
                    $(`#${seatNo}`).removeClass()
                    $(`#${seatNo}`).addClass("btn btn-outline-primary w-100")
                    setPrice((prevPrice: any) => prevPrice - goldSeatPrice)
                    setBookedSeatsArr(bookedSeatsArr.filter((seatNo: any) => bookedSeatsArr != seatNo))
                }
                break;
            case 'C':
                if (data?.includes("outline")) {
                    $(`#${seatNo}`).removeClass()
                    $(`#${seatNo}`).addClass("btn btn-warning text-dark w-100")
                    setPrice((prevPrice: any) => prevPrice + balconySeatPrice)
                    setBookedSeatsArr([...bookedSeatsArr, seatNo])
                }
                else {
                    $(`#${seatNo}`).removeClass()
                    $(`#${seatNo}`).addClass("btn btn-outline-warning text-dark w-100")
                    setPrice((prevPrice: any) => prevPrice - balconySeatPrice)
                    setBookedSeatsArr(bookedSeatsArr.filter((seatNo: any) => bookedSeatsArr != seatNo))
                }
                break;
        }
    }
    return (
        <div className="col-sm" key={indexVal}>
            {keyVal.IsAvailable ?
                seatType == "baclcony" ?
                    <button className="btn btn-outline-warning text-dark w-100" id={keyVal.SeatNo} onClick={() => selectSeat(keyVal.SeatNo, indexVal)}>{keyVal.SeatNo}</button> :
                    seatType == "Mezzanine" ?
                        <button className="btn btn-outline-primary w-100" id={keyVal.SeatNo} onClick={() => selectSeat(keyVal.SeatNo, indexVal)}>{keyVal.SeatNo}</button>
                        : <button className="btn btn-outline-success w-100" id={keyVal.SeatNo} onClick={() => selectSeat(keyVal.SeatNo, indexVal)}>{keyVal.SeatNo}</button>
                : <button className="btn btn-secondary w-100" disabled>{keyVal.SeatNo}</button>}
        </div>
    )
}