import { useNavigate } from "react-router-dom"
import pageNotFound from "../svg/404.png"
export default function PageNotFound() {
    const navigate = useNavigate()
    function homePage() {
        navigate("/")
    }
    return (
        <>
            <div className="container mt-5 text-center">
                <p className="display-4 mt-5">
                    <img src={pageNotFound} className="mt-5" alt="" />
                </p>
                <button className="btn btn-outline-warning text-dark p-3 w-50 mt-5" onClick={() => homePage()}>Go Back To Right Side</button>
            </div>
        </>
    )
}