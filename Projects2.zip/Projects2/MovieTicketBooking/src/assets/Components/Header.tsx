import { useNavigate } from "react-router-dom"
import film from "../svg/film.png"
export default function Header() {
    const navigate = useNavigate()
    function bookingHistory(){
        navigate("bookingHistory")
    }
    return (
        <>
            <div className="container-fluid bg-primary row">
                <div className="col-md-4 mt-3 text-white">
                    <h2><img src={film} style={{ background: "transparent", height: "80px", marginRight: "30px" }} />Book Your Movie Tickets</h2>
                </div>
                <div className="col-md-6"></div>
                <div className="col-md-2">
                    <button className="btn btn-dark btn-lg w-100 mt-4" type="button" onClick={() => bookingHistory()}>View Booking History</button>
                </div>
            </div>
        </>
    )
}