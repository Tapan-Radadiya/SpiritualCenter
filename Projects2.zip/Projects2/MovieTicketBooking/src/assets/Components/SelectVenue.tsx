import { useNavigate, useParams } from "react-router-dom"
import { venueDataStruct } from "../../App"

export default function SelectVenue({ movieData, venueData, setVenueData }: any) {
    const navigate = useNavigate()
    const { MovieId } = useParams()

    const curMovie = movieData.filter((item: any) => item.MovieId == MovieId)
    const venueList = curMovie[0].Venue

    function bookTicket(venueId: number) {
        let flag: boolean = false
        // If id present in use state then dont add new obj, if not then add new Obj
        const venueDetails = venueList.filter((item: any) => venueId == item.VenueId)

        venueData.map((key: any, _: any) => {
            if (key.VenueId == venueId) flag = true
        })

        if (!flag) {
            const venueDetailsObj: venueDataStruct = {
                VenueId: venueDetails[0].VenueId,
                VenueName: venueDetails[0].VenueName,
                Address: venueDetails[0].Address,
                IsAvailable: venueDetails[0].IsAvailable,
                SilverSeats: venueDetails[0].Seats[0],
                GoldSeats: venueDetails[0].Seats[1],
                BalconySeats: venueDetails[0].Seats[2],
                SilverSeatPrice: venueDetails[0].Seats[0].Price,
                GoldSeatPrice: venueDetails[0].Seats[1].Price,
                BalconySeatPrice: venueDetails[0].Seats[2].Price
            }
            setVenueData([...venueData, venueDetailsObj])
        }
        navigate(`/ticketBook/${curMovie[0].MovieName}/${venueId}`)
    }
    return (
        <>
            <div className="container text-center text-uppercase p-4 mt-3">
                <p className="display-6">Select your Theatre</p>
            </div>
            {venueList.map((key: any, index: any) => (
                <div className="container border border-muted border-2 mt-3" key={index}>
                    <div className="row">
                        <div className="col-md-1"></div>
                        <div className="col-md-4 p-4">
                            <img src="https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg" className="w-50" alt="" />
                        </div>
                        <div className="col-md-6 text-center mt-5 p-3">
                            <div className="lead">
                                <p>Theater Name : {key.VenueName}</p>
                                <p>Theater Address : {key.Address}</p>
                            </div>
                            {
                                key.IsAvailable ? <button className="btn btn-outline-success w-75 mt-5 p-3" onClick={() => bookTicket(key.VenueId)}>Book Tickets </button> :
                                    <button className="btn btn-outline-success w-75 mt-5 p-3" disabled>Movie Not Available </button>
                            }
                        </div>
                    </div>
                </div>
            ))}
        </>
    )
}