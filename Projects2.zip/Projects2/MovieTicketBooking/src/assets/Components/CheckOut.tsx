import { useNavigate, useParams } from "react-router-dom"
import BookingHistory from "./BookingHistory"
import { bookingHistoryStruct } from "../../App"
export default function CheckOut({
    venueData,
    setVenueData,
    checkoutForm,
    setPrice,
    setBookedSeatsArr,
    setCheckoutForm,
    bookedSeatsArr,
    bookingHistory,
    setBookingHistory }: any) {
    const navigate = useNavigate()
    const { MovieName, TotalPrice, VenueId } = useParams()

    let venueName = ""
    const totalGst = Number(TotalPrice) + (Number(TotalPrice) * 18) / 100
    function checkData(e: any) {
        $("span").hide()
        const { name, value } = e.target
        setCheckoutForm({ ...checkoutForm, [name]: value })
    }
    function bookSeates() {
        let silverSeat: any[] = []
        let goldSeat: any[] = []
        let balconySeat: any[] = []
        venueData.map((key: any, _: any) => {
            if (key.VenueId == VenueId) {
                venueName = key.VenueName
                silverSeat = key.SilverSeats.Silver
                goldSeat = key.GoldSeats.Gold
                balconySeat = key.BalconySeats.Balcony
            }
        })

        bookedSeatsArr.map((key: any, _: any) => {
            const seatType = key.charAt(0)
            switch (seatType) {
                case 'A':
                    silverSeat.map((silverSeat: any, _: any) => {
                        if (key === silverSeat.SeatNo) {
                            silverSeat.IsAvailable = false
                        }
                    })
                    break;
                case 'B':
                    goldSeat.map((goldSeatNo: any, _: any) => {
                        if (key === goldSeatNo.SeatNo) {
                            goldSeatNo.IsAvailable = false
                        }
                    })
                    break;
                case 'C':
                    balconySeat.map((balconySeatNo: any, _: any) => {
                        if (key == balconySeatNo.SeatNo) {
                            balconySeatNo.IsAvailable = false
                        }
                    })
                    break;
            }
        })

        setVenueData((venueData: any) => {
            let copyData = [...venueData]
            copyData.map((key: any, _: any) => {
                console.log("page Id ", VenueId);
                if (key.VenueId == VenueId) {
                    key.BalconySeats.Balcony = balconySeat
                    key.GoldSeats.Gold = goldSeat
                    key.SilverSeats.Silver = silverSeat
                }
            })
            return copyData
        })
        setBookedSeatsArr([])
    }
    function addBookingHistory() {
        const bookingHistoryObj: bookingHistoryStruct = {
            MovieName: MovieName,
            VenueName: venueName,
            Seats: bookedSeatsArr,
            TotalCost: TotalPrice
        }
       
        setBookingHistory((prevData) => [...prevData,bookingHistoryObj])
    }
    function confirmTicket() {

        if (!checkoutForm.Firstname) {
            $("#firstNameErr").show()
            return
        }
        else if (!checkoutForm.Lastname) {
            $("#lastNameErr").show()
            return
        }
        else if (!checkoutForm.FirstFour) {
            $("#firstFourErr").show()
            return
        }
        else if (!checkoutForm.SecondFour) {
            $("#secondFourErr").show()
            return
        }
        else if (!checkoutForm.LastFour) {
            $("#lastFourErr").show()
            return
        }
        // else if(!checkoutForm.MobileNum){
        //     $("#mobileNumErr").show()
        //     return
        // }
        else {
            if (checkoutForm.FirstFour.length != 4) {
                $("#firstFourErr").show()
                return
            }
            else if (checkoutForm.SecondFour.length != 4) {
                $("#secondFourErr").show()
                return
            }
            else if (checkoutForm.LastFour.length != 4) {
                $("#lastFourErr").show()
                return
            }
            // else if(checkoutForm.MobileNum.length != 10){
            //     $("mobileNumErr").text("Enter Valid Mobile Number").show()
            //     return
            // }
        }
        bookSeates()
        addBookingHistory()
        setPrice(0)
        alert("Your Tickets Are Confirmed")
        navigate("/")
    }

    return (
        <>
            <div className="container text-center text-uppercase mt-2">
                <p className="display-6">Checkout</p>
            </div>
            <div className="container mt-3">
                <div className="row">
                    <div className="col-md-2"></div>
                    <div className="col-md-4">
                        <div className="form-group">
                            <label htmlFor="firstName" className="form-label">Enter First Name</label>
                            <input type="text" name="Firstname" className="form-control border border-dark" id="firstName" placeholder="FirstName" onChange={(e) => checkData(e)} />
                            <span id="firstNameErr" style={{ color: "red", display: "none" }}>Please Enter First Name</span>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="form-group">
                            <label htmlFor="lastName" className="form-label">Enter Last Name</label>
                            <input type="text" name="Lastname" className="form-control border border-dark" id="lastName" placeholder="LastName" onChange={(e) => checkData(e)} />
                            <span id="lastNameErr" style={{ color: "red", display: "none" }}>Please Enter Last Name</span>
                        </div>
                    </div>
                    <div className="col-md-2"></div>
                </div>

                <div className="row mt-2 g-4">
                    <div className="col-md-2"></div>
                    <div className="col-sm-2"><label htmlFor="cardData" className="form-label"> Enter Card Details</label></div>
                </div>
                <div className="row">
                    <div className="col-md-2"></div>
                    <div className="col-md-1">
                        <div className="form-group">
                            <input type="text" name="FirstFour" className="form-control border border-dark" id="" placeholder="0000" onChange={(e) => checkData(e)} />
                            <span id="firstFourErr" style={{ color: "red", display: "none" }}>Please Enter Valid Card Details</span>
                        </div>
                    </div>
                    <div className="col-md-1">
                        <div className="form-group">
                            <input type="text" name="SecondFour" className="form-control border border-dark" id="" placeholder="0000" onChange={(e) => checkData(e)} />
                            <span id="secondFourErr" style={{ color: "red", display: "none" }}>Please Enter Valid Card Details</span>
                        </div>
                    </div>
                    <div className="col-md-1">
                        <div className="form-group">
                            <input type="text" name="LastFour" className="form-control border border-dark" id="" placeholder="0000" onChange={(e) => checkData(e)} />
                            <span id="lastFourErr" style={{ color: "red", display: "none" }}>Please Enter Valid Card Details</span>
                        </div>
                    </div>
                    <div className="col-md-2"></div>
                </div>
                <div className="row mt-4">
                    <div className="col-md-2"></div>
                    <div className="col-md-4">
                        <div className="form-group">
                            <label htmlFor="phoneNum">Enter Your Phone Number</label>
                            <input type="text" name="MobileNum" id="phoneNum" className="form-control border border-dark" />
                            <span id="mobileNumErr" style={{ color: "red", display: "none" }}>Please Enter Mobile Number</span>
                        </div>
                    </div>
                </div>
                <div className="row lead mt-5">
                    <div className="col-md-6"></div>
                    <div className="d-flex align-items-end flex-column col-md-4">
                        <div className="p-2"> Total Price <b>: {TotalPrice}</b></div>
                        <div className="p-2"> Gst Charges <b>: 18%</b></div>
                        <div className="p-2"> Platform Charges <b>: +50</b></div>
                        <div className="p-1">----------------------------------------------------------</div>
                        <div className="p-1">To Pay <b>: {totalGst + 50}</b></div>
                    </div>
                    <div className="col-md-4"></div>
                </div>
                <div className="row mt-3">
                    <div className="col-md-8"></div>
                    <div className="col-md-2"><button className="btn btn-outline-primary w-100" onClick={() => confirmTicket()}>Book Tickets</button></div>
                </div>
            </div>
        </>
    )
}