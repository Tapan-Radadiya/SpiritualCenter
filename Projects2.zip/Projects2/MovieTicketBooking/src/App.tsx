import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import DisplayMovie from './assets/Components/DisplayMovie'
import SelectSeats from './assets/Components/SelectSeats'
import CheckOut from './assets/Components/CheckOut'
import SelectVenue from './assets/Components/SelectVenue'
import movieDataJson from './assets/MovieData/MovieData.json'
import { useEffect, useState } from 'react'
import Header from './assets/Components/Header'
import PageNotFound from './assets/Components/PageNotFound'
import BookingHistory from './assets/Components/BookingHistory'
export type venueDataStruct = {
  VenueId: number
  VenueName: string
  Address: string
  IsAvailable: boolean
  SilverSeats: []
  SilverSeatPrice: number
  GoldSeats: []
  GoldSeatPrice: number
  BalconySeats: []
  BalconySeatPrice: number
}
export type bookingHistoryStruct = {
  MovieName: string
  VenueName: string
  Seats: []
  TotalCost: number
}
function App() {
  const [movieData, setMovieData] = useState([{}])
  const [venueData, setVenueData] = useState<venueDataStruct[]>([])
  const [price, setPrice] = useState(0)
  const [bookingHistory, setBookingHistory] = useState<bookingHistoryStruct[]>([])
  const [bookedSeatsArr, setBookedSeatsArr] = useState([])
  function AddMovieData() {
    setMovieData(movieDataJson)
  }
  useEffect(() => {
    AddMovieData()
  }, [movieData])
  type checkOutFormStruct = {
    Firstname: string
    Lastname: string
    FirstFour: string
    SecondFour: string
    LastFour: string
    MobileNum: string
  }
  const [checkoutForm, setCheckoutForm] = useState<checkOutFormStruct>({
    Firstname: "",
    Lastname: "",
    FirstFour: "",
    SecondFour: "",
    LastFour: "",
    MobileNum: ""
  })
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path='' element={<DisplayMovie
            movieData={movieData}
          />} />
          <Route path='selectVenue/:MovieId' element={<SelectVenue
            movieData={movieData}
            venueData={venueData}
            setVenueData={setVenueData}
          />} />
          <Route path='ticketBook/:MovieName/:venueId' element={<SelectSeats
            venueData={venueData}
            setVenueData={setVenueData}
            price={price}
            setPrice={setPrice}
            setBookedSeatsArr={setBookedSeatsArr}
            bookedSeatsArr={bookedSeatsArr}
          />} />
          <Route path='checkOut/:MovieName/:TotalPrice/:VenueId' element={<CheckOut
            checkoutForm={checkoutForm}
            setCheckoutForm={setCheckoutForm}
            venueData={venueData}
            setPrice={setPrice}
            setVenueData={setVenueData}
            setBookedSeatsArr={setBookedSeatsArr}
            bookedSeatsArr={bookedSeatsArr}
            bookingHistory={bookingHistory}
            setBookingHistory={setBookingHistory}
          />} />
          <Route path='bookingHistory' element={<BookingHistory
            bookingHistory={bookingHistory}
            setBookingHistory={setBookingHistory}
          />} />
          <Route path='*' element={<PageNotFound />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
