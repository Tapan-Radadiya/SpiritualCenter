export interface UserLogin_interface {
    EmailId: string | String
    Password: string | String
    Role:string|String
}