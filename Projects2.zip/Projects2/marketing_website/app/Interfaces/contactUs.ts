export interface ContactUs_interface {
    FullName: String | string,
    Email: String | string,
    Message: String | string
}