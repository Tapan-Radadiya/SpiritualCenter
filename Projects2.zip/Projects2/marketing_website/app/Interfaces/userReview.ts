export interface userReview_Interface {
    FullName: String | string
    Message: String | string,
}