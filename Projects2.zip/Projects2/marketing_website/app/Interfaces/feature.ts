export interface Feature_interface {
    Title: string | String
    Feature_Detail: string | String
}