export interface User_Register_Interface {
    UserName: string | String
    UserEmail: string | String
    DateOfBirth: Date
    Gender: string | String
    City: string | String
    ZipCode: string | String
    Password: string | String
}