// const printFullName = {
//     fullName: function (greet) {
//         return greet + this.FirstName + " " + this.LastName
//     }
// }

// const user1 = {
//     FirstName: "John",
//     LastName: "Doe"
// }
// // console.log(printFullName.fullName.call(user1, " : Hello "))

// // console.log(printFullName.fullName.apply(user1, [" : Hello "]));


// const company = {
//     name: "Something",
//     Type: "Real Estate",
//     moto: function () {
//         return `Company ${this.name} is Type Of ${this.Type} And Moto Is To Became Best`
//     }
// }
// const company2 = {
//     name: "Something But Better Then Something",
//     Type: "Real Estate",
// }
// // console.log(company.moto());
// const companyMoto = company.moto.bind(company2)
// // console.log(companyMoto());



// const userData = {
//     FirstName: "John",
//     LastName: "Doe",
//     fullName: function () {
//         console.log(this.FirstName + " " + this.LastName);
//         return this.FirstName + " " + this.LastName
//     }
// }
// // setTimeout(userData.fullName, 3000) // Undefind Because We lost this in callback
// // const bindedMethod = userData.fullName.bind(userData)
// // setTimeout(bindedMethod, 3000)

// function addData() {
//     let counter = 0

//     function plus() { counter += 1 }
//     plus()
//     return counter
// }

// const add = (function () {
//     let counter = 0
//     // console.log("Yoo");
//     return function () { counter += 1; return counter }
// })()
// // console.log(addData());
// // console.log(addData());
// // console.log(addData());
// // console.log(add());
// // console.log(add());
// // console.log(add());


// class Car {
//     constructor(name, year) {
//         this.name = name
//         this.year = year
//     }
//     age(carAge) {
//         const date = new Date()
//         return carAge - this.year
//     }
// }
// const car1 = new Car("XUV3XO", 2024)

// class myCar extends Car {
//     constructor(brand) {
//         super()
//         this.brand = brand
//     }
// }


// class Speak {
//     constructor(sound) {
//         this.sound = sound
//     }
//     soundsLike() {
//         console.log(`sound ${this.sound}`);
//         return `sound ${this.sound}`
//     }
// }

// class Animal extends Speak {
//     constructor(AnimalName, sound) {
//         super(sound)
//         this.AnimalName = AnimalName
//     }
//     printAnimal() {
//         console.log(`Animal Is ${this.AnimalName}`);
//         return `Animal Is ${this.AnimalName}`
//     }
// }

// const dog = new Animal("Dog","Barks")
// // console.log(dog);

// class C1{
//     constructor(){
        
//     }
//     static greet(){
//         return "Hello"
//     }
// }
// const first = new C1()
// console.log(first.greet());