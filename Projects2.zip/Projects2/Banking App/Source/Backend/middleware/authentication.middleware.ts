import { Context, Next } from "koa";
import { parseCookie } from "koa-cookies";
import ApiResponse from "../utils/apiResponse"
import jwt from "jsonwebtoken"

export default async function AuthenticateUser(ctx: Context, next: Next) {
    const cookie = await parseCookie("userdata")(ctx)

    if (!cookie) {
        ctx.status = 401
        return ctx.body = ApiResponse(401, "Please Login")
    }
    try {
        const { Id, UserName }: any = jwt.verify(cookie, `${process.env.JWT_SECRET_KEY}`)
        ctx.userData = { Id: Id, UserName: UserName }
        await next()
    } catch (error) {
        ctx.status = 500
        return ctx.body = ApiResponse(500, "Internal Server Error (Middleware)")
    }
}