import { Context, Next } from "koa";
import ApiResponse from "../utils/apiResponse"

export default function AuthorizeUser(allowedRole: string[]) {
    return async (ctx: Context, next: Next) => {
        let isAllowed: boolean = false
        const curRole = ctx.userData.Role
        allowedRole.forEach((ele: string) => {
            if (ele.toUpperCase() == curRole.toUpperCase()) {
                isAllowed = true
            }
        })
        if (isAllowed) {
            await next()
        }
        else {
            ctx.status = 401
            return ctx.body = ApiResponse(401, "You Are Not Authorized")
        }
    }
}