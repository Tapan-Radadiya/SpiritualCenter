import Router from "koa-router"

import {
    insertBankAccount,
    insertEmployee,
    insertUsers
} from "../controller/insertData.controller"
const router = new Router({ prefix: "/initData" })

router.post("/addUserData", insertUsers)
router.post("/addBankAccountData", insertBankAccount)
router.post("/addEmployeeData", insertEmployee)

export default router