import Router from "koa-router";
import {
    getEmployeeWallet,
    addFund,
    sendMoney,
    getEmployeeData,
    getTransactionHistoryData
} from "../controller/employee.controller"
import AuthenticateUser from "../middleware/authentication.middleware"

const router = new Router({ prefix: "/employee" })

router.get("/getWalletData", AuthenticateUser, getEmployeeWallet)
router.post("/addFunds", AuthenticateUser, addFund)
router.post("/sendMoney", AuthenticateUser, sendMoney)
router.get("/getEmployeeData", AuthenticateUser, getEmployeeData)
router.get("/historyData",AuthenticateUser,getTransactionHistoryData)
export default router