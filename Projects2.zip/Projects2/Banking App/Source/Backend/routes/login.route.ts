import Router from "koa-router"
import { loginUser } from "../controller/login.controller"

const router = new Router()

router.post("/login", loginUser)

export default router