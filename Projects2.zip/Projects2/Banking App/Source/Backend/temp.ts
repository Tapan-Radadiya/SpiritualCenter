const year = {}
console.log(year ?? 2024);
