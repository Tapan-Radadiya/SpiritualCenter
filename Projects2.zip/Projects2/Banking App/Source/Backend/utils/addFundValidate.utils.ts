import ApiResponse from "./apiResponse";

export function ValidateAddFund(fundValue: any) {
    if (fundValue == "") {
        return ApiResponse(400, "Amount is required.")
    }
    else if (!Number(fundValue)) {
        return ApiResponse(400, "The input value must be numeric")
    }
    else if (fundValue <= 0) {
        return ApiResponse(400, "Amount must be greater than 0.")
    }
    else if (fundValue.toString().length > 8) {
        return ApiResponse(400, "Amount cannot be more than 8 digits.")
    }
    else {
        return ApiResponse(200, "All OK")
    }
}