export default function ParseData(data: any) {
    if (typeof data == "string") {
        return JSON.parse(data)
    }
    else return data
}