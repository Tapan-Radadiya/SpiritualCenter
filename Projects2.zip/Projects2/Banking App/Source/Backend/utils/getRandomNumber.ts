export default function randomNumber() {
    return Math.floor(Math.random() * 101)
}