import mongoose from "mongoose";
import { Employee_Interface } from "../interface/Employee.interface";

const employeeSchema = new mongoose.Schema<Employee_Interface>({

    EmployeeId: {
        type: Number,
        required: true,
        unique: true
    },

    FirstName: {
        type: String,
        required: true
    },

    LastName: {
        type: String,
        required: true
    },

    Email: {
        type: String,
        required: true
    }
});

export const Employee = mongoose.model("Employee", employeeSchema)