import mongoose from "mongoose";
import { Wallet_Interface } from "../interface/Wallet.interface";

const walletSchema = new mongoose.Schema<Wallet_Interface>({
    WalletId: {
        type: Number,
        required: true,
        unique: true
    },

    EmployeeId: {
        type: Number,
        required: true
    },

    Balance: {
        type: Number,
        required: true
    },
}, { timestamps: true });

export const Wallet = mongoose.model("Wallet", walletSchema)