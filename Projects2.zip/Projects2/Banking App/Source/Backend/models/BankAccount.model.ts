import mongoose from "mongoose";
import { BankAccount_Interface } from "../interface/BankAccount.interface";

const bankAccountSchema = new mongoose.Schema<BankAccount_Interface>({

    BankAccountId: {
        type: Number,
        required: true,
        unique: true
    },

    EmployeeId: {
        type: Number,
        required: true
    },

    BankName: {
        type: String,
        required: true
    },

    AccountNumber: {
        type: String,
        required: true
    },

    Balance: {
        type: Number,
        required: true
    },

});

export const BankAccount = mongoose.model("BankAccount", bankAccountSchema)