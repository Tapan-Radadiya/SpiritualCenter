import mongoose from "mongoose";
import { User_Interface } from "../interface/User.interface";

const userSchema = new mongoose.Schema<User_Interface>({
    Id: {
        type: Number,
        required: true,
        unique: true
    },
    Username: {
        type: String,
        required: true
    },
    Password: {
        type: String,
        required: true
    },
});
export const User = mongoose.model("User", userSchema)
