import mongoose from "mongoose";
import { TransactionHistory_Interface } from "../interface/TransactionHistory.interface";

const TransactionHistorySchema = new mongoose.Schema<TransactionHistory_Interface>({
    SenderName: {
        type: String,
        required: true
    },
    ReceiverName: {
        type: String,
        required: true
    },
    Amount: {
        type: Number,
        required: true
    },
    TimeStamp: {
        type: Date,
        required: true,
        default: new Date()
    },
    SenderId: {
        type: Number,
        required: true
    }
})
export const TransactionHistory = mongoose.model("TransactionHistory", TransactionHistorySchema)