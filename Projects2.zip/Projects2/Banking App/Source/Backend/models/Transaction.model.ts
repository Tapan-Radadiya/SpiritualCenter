import mongoose from "mongoose";
import { Transaction_Interface } from "../interface/Transaction.interface";

const transactionSchema = new mongoose.Schema<Transaction_Interface>({

    TransactionId: {
        type: Number,
        required: true,
        unique: true
    },

    SenderId: {
        type: Number,
        required: true
    },

    ReceiverId: {
        type: Number,
        required: true
    },

    Amount: {
        type: Number,
        required: true
    },

    Timestamp: {
        type: Date,
        default: Date.now()
    },
});
export const Transaction = mongoose.model("Transaction", transactionSchema)