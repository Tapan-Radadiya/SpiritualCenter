const bankAccounts = [

    {

        BankAccountId: 1,

        EmployeeId: 1,

        BankName: "Bank A",

        AccountNumber: "1234567890",

        Balance: 1000,

    },

    {

        BankAccountId: 2,

        EmployeeId: 2,

        BankName: "Bank B",

        AccountNumber: "2345678901",

        Balance: 1500,

    },

    {

        BankAccountId: 3,

        EmployeeId: 3,

        BankName: "Bank C",

        AccountNumber: "3456789012",

        Balance: 2000,

    },

    {

        BankAccountId: 4,

        EmployeeId: 4,

        BankName: "Bank D",

        AccountNumber: "4567890123",

        Balance: 2500,

    },

    {

        BankAccountId: 5,

        EmployeeId: 5,

        BankName: "Bank E",

        AccountNumber: "5678901234",

        Balance: 3000,

    },

    {

        BankAccountId: 6,

        EmployeeId: 6,

        BankName: "Bank F",

        AccountNumber: "6789012345",

        Balance: 3500,

    },

    {

        BankAccountId: 7,

        EmployeeId: 7,

        BankName: "Bank G",

        AccountNumber: "7890123456",

        Balance: 4000,

    },

    {

        BankAccountId: 8,

        EmployeeId: 8,

        BankName: "Bank H",

        AccountNumber: "8901234567",

        Balance: 4500,

    },

    {

        BankAccountId: 9,

        EmployeeId: 9,

        BankName: "Bank I",

        AccountNumber: "9012345678",

        Balance: 5000,

    },

    {

        BankAccountId: 10,

        EmployeeId: 10,

        BankName: "Bank J",

        AccountNumber: "0123456789",

        Balance: 5500,

    },

];

const employees = [

    {

        EmployeeId: 1,

        FirstName: "John",

        LastName: "Doe",

        Email: "john.doe@example.com",

    },

    {

        EmployeeId: 2,

        FirstName: "Jane",

        LastName: "Smith",

        Email: "jane.smith@example.com",

    },

    {

        EmployeeId: 3,

        FirstName: "Emily",

        LastName: "Johnson",

        Email: "emily.johnson@example.com",

    },

    {

        EmployeeId: 4,

        FirstName: "Michael",

        LastName: "Brown",

        Email: "michael.brown@example.com",

    },

    {

        EmployeeId: 5,

        FirstName: "Sarah",

        LastName: "Davis",

        Email: "sarah.davis@example.com",

    },

    {

        EmployeeId: 6,

        FirstName: "David",

        LastName: "Miller",

        Email: "david.miller@example.com",

    },

    {

        EmployeeId: 7,

        FirstName: "Laura",

        LastName: "Wilson",

        Email: "laura.wilson@example.com",

    },

    {

        EmployeeId: 8,

        FirstName: "James",

        LastName: "Moore",

        Email: "james.moore@example.com",

    },

    {

        EmployeeId: 9,

        FirstName: "Linda",

        LastName: "Taylor",

        Email: "linda.taylor@example.com",

    },

    {

        EmployeeId: 10,

        FirstName: "Robert",

        LastName: "Anderson",

        Email: "robert.anderson@example.com",

    },

];

const users = [

    { Id: 1, Username: "john_doe", Password: "password1" },

    { Id: 2, Username: "jane_smith", Password: "password2" },

    { Id: 3, Username: "emily_johnson", Password: "password3" },

    { Id: 4, Username: "michael_williams", Password: "password4" },

    { Id: 5, Username: "sarah_brown", Password: "password5" },

    { Id: 6, Username: "david_jones", Password: "password6" },

    { Id: 7, Username: "laura_garcia", Password: "password7" },

    { Id: 8, Username: "james_martinez", Password: "password8" },

    { Id: 9, Username: "linda_hernandez", Password: "password9" },

    { Id: 10, Username: "robert_lopez", Password: "password10" },

];

export {
    bankAccounts,
    employees,
    users
}