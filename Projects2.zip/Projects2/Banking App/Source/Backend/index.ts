import "dotenv/config"
import app from "./app"
import connectDb from "./config/connectDb"
import { createServer } from "node:http"
import { Server } from "socket.io"


const server = createServer(app.callback())
export const io = new Server(server, { cors: { origin: `${process.env.CORS_ORIGIN}` } })
connectDb()
    .then(() => {
        io.on("connection", (socket: any) => {
            socket.on("USER_ADDED", (userId: any) => {
                socket.join(userId.toString())
            })
        })
        server.listen(process.env.PORT || 8080, () => {
            console.log(`Server Listening On Port ${process.env.PORT || 8080}`);
        })
    })
    .catch((err) => {
        console.error(err);
    })
