import mongoose from "mongoose"
import ApiResponse from "../utils/apiResponse"
export default async function connectDb() {
    try {
        const connectStatus = await mongoose.connect(`${process.env.MONGODB_URI}/${process.env.MONGODB_DB_NAME}`)
        if (connectStatus.connection.host) {
            console.log(`Db Connected With Host ${connectStatus.connection.host}`);
        }
        else {
            console.log("Error Connecting With Host");
        }
    } catch (error) {
        return ApiResponse(500, "Error Connecting With DB")
    }
}