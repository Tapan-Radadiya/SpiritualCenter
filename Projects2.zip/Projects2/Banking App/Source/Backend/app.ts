import koa from "koa"
import koaBody from "koa-body"
import cors from "@koa/cors"
import { parseCookie } from "koa-cookies"
import initData from "./routes/initData.route"
import loginRouter from "./routes/login.route"
import employeeRouter from "./routes/employee.route"
import { io } from "."

const app = new koa()

app.use(parseCookie())
app.use(cors({ origin: `${process.env.CORS_ORIGIN}`, credentials: true }))
app.use(koaBody({ multipart: true, urlencoded: true }))

app.use(initData.routes()).use(initData.allowedMethods())
app.use(loginRouter.routes()).use(loginRouter.allowedMethods())
app.use(employeeRouter.routes()).use(employeeRouter.allowedMethods())
export default app