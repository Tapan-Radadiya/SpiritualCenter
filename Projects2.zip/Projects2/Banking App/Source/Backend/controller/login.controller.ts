import { Context } from "koa";
import ApiResponse from "../utils/apiResponse"
import { userLoginService } from "../services/login.services";
import ParseData from "../utils/parseJson"
const loginUser = async (ctx: Context) => {
    const {
        UserName,
        Password
    }: any = ParseData(ctx.request.body)
    if (!UserName) {
        ctx.status = 400
        return ctx.body = ApiResponse(400, "UserName Required")
    }
    if (!Password) {
        ctx.status = 400
        return ctx.body = ApiResponse(400, "Password Required")
    }

    try {
        const { statusCode, message, data } = await userLoginService(UserName, Password)
        if (statusCode == 200) {
            
            
            ctx.cookies.set("userdata", data)
            ctx.status = statusCode
            return ctx.body = ApiResponse(statusCode, message, data)
        }
        else {
            ctx.status = statusCode
            return ctx.body = ApiResponse(statusCode, message)
        }
    } catch (error) {
        ctx.status = 500
        return ctx.body = ApiResponse(500, "Error Login Try After SomeTime")
    }
}
export {
    loginUser
}