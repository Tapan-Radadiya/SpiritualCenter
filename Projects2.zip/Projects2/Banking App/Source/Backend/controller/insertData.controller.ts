import { Context } from "koa";
import {
    bankAccounts,
    employees,
    users
} from "../Data/InitialData"
import ApiResponse from "../utils/apiResponse"
import { Employee } from "../models/Employee.model"
import { BankAccount } from "../models/BankAccount.model"
import { User } from "../models/User.model"

const insertEmployee = async (ctx: Context) => {
    try {
        Employee.insertMany(employees)
            .then(() => {
                ctx.status = 201
                return ctx.body = ApiResponse(201, "Employee Inserted")
            })
            .catch((err) => {
                console.log(err);
                ctx.status = 500
                return ctx.body = ApiResponse(500, "Error Inserting Data")
            });


    } catch (error) {
        console.log(error);
        ctx.status = 500
        return ctx.body = ApiResponse(500, "Error Inserting Employee")
    }
}

const insertBankAccount = async (ctx: Context) => {
    try {
        BankAccount.insertMany(bankAccounts)
            .then(() => {
                ctx.status = 201
                return ctx.body = ApiResponse(201, "Bank Account Data Inserted")
            })
            .catch((err) => {
                console.log(err);
                ctx.status = 500
                return ctx.body = ApiResponse(500, "Error Inserting Data")
            });


    } catch (error) {
        console.log(error);
        ctx.status = 500
        return ctx.body = ApiResponse(500, "Error Inserting BankAccount Data")
    }
}

const insertUsers = async (ctx: Context) => {
    try {
        User.insertMany(users)
            .then(() => {
                ctx.status = 201
                return ctx.body = ApiResponse(201, "User Data Inserted")
            })
            .catch((err) => {
                console.log(err);
                ctx.status = 500
                return ctx.body = ApiResponse(500, "Error Inserting Data")
            });

    } catch (error) {
        console.log(error);
        ctx.status = 500
        return ctx.body = ApiResponse(500, "Error Inserting Users Data")
    }
}

export {
    insertEmployee,
    insertBankAccount,
    insertUsers
}