import { Context } from "koa"
import ApiResponse from "../utils/apiResponse"
import {
    addFundService,
    getEmployeeWalletService,
    sendMoneyService,
    getEmployeeDataService,
    getTransactionHistoryDataService
} from "../services/employee.services"

import { ValidateAddFund } from "../utils/addFundValidate.utils"
import ParseData from "../utils/parseJson"
import { io } from ".."

const addFund = async (ctx: Context) => {
    const {
        amount
    } = ParseData(ctx.request.body)
    const userData = ctx.userData
    const { statusCode, message } = ValidateAddFund(amount)
    if (statusCode != 200) {
        ctx.status = statusCode
        return ctx.body = ApiResponse(statusCode, message)
    }
    try {
        const { statusCode, message }: any = await addFundService(amount, userData)
        ctx.status = statusCode
        return ctx.body = ApiResponse(statusCode, message)

    } catch (error) {
        ctx.status = 500
        return ctx.body = ApiResponse(500, "Error Adding Fund")
    }
}

const sendMoney = async (ctx: Context) => {
    const {
        Recipient,
        Amount
    } = ParseData(ctx.request.body)
    if (!Recipient) {
        return ApiResponse(400, "Recipient is required.")
    }
    const { statusCode, message } = ValidateAddFund(Amount)
    if (statusCode != 200) {
        ctx.status = statusCode
        return ctx.body = ApiResponse(statusCode, message)
    }

    try {
        const { statusCode, message }: any = await sendMoneyService(Recipient, Amount, ctx.userData.Id, ctx.userData.UserName)

        ctx.status = statusCode
        return ctx.body = ApiResponse(statusCode, message)

    } catch (error) {
        console.log(error);

        ctx.status = 500
        return ctx.body = ApiResponse(500, "Error In Sending Money Try After SomeTime")
    }
}

const getEmployeeWallet = async (ctx: Context) => {
    const { Id, UserName } = ctx.userData
    if (!Id) {
        ctx.status = 400
        return ctx.body = ApiResponse(400, "Unable To Get Id Please Login Again")
    }
    if (!UserName) {
        ctx.status = 400
        return ctx.body = ApiResponse(400, "Unable To Get UserName Please Login Again")
    }

    try {

        const { statusCode, message, data } = await getEmployeeWalletService(Id)
        ctx.status = statusCode
        return ctx.body = ApiResponse(statusCode, message, data)
    } catch (error) {
        ctx.status = 500
        return ctx.body = ApiResponse(500, "Error Fetching Wallet Data")
    }
}

const getEmployeeData = async (ctx: Context) => {
    try {
        const { statusCode, message, data } = await getEmployeeDataService(ctx.userData)
        ctx.status = statusCode
        return ctx.body = ApiResponse(statusCode, message, data)
    } catch (error) {
        ctx.status = 500
        ctx.body = ApiResponse(500, "Error Fetching Employee Data")
    }
}

const getTransactionHistoryData = async (ctx: Context) => {
    try {
        const { statusCode, message, data } = await getTransactionHistoryDataService(ctx.userData)
        ctx.status = statusCode
        return ctx.body = ApiResponse(statusCode, message, data)
    } catch (error) {
        ctx.status = 500
        ctx.body = ApiResponse(500, "Error Fetching Transaction History Data")
    }
}

export {
    addFund,
    getEmployeeWallet,
    sendMoney,
    getEmployeeData,
    getTransactionHistoryData
}