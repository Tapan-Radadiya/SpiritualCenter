export interface Employee_Interface{
    EmployeeId:number
    FirstName:string
    LastName:string,
    Email:string
}