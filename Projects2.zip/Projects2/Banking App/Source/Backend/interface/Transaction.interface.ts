export interface Transaction_Interface {
    TransactionId: number
    SenderId: number
    ReceiverId: number
    Amount: number
    Timestamp: Date
}