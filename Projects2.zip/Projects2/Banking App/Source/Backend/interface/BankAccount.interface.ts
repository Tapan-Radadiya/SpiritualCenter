export interface BankAccount_Interface {
    BankAccountId: number
    EmployeeId: number
    BankName: string
    AccountNumber: string
    Balance: number
}