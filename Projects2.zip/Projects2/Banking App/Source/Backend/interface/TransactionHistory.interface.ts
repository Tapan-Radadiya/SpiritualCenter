export interface TransactionHistory_Interface {
    SenderName: string
    SenderId:number
    ReceiverName: string
    Amount: number
    TimeStamp: Date
}