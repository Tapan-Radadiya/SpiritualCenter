export interface Wallet_Interface {
    WalletId: number
    EmployeeId: number
    Balance: number
}