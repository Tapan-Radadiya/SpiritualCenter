export interface User_Interface {
    Id:number
    Username:string
    Password:string
}