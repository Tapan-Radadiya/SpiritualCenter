import { ValidateAddFund } from "../utils/addFundValidate.utils"

describe("Fund Validate TestCases", () => {
    test("Passing Empty Value", () => {
        const { statusCode, message } = ValidateAddFund("")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Amount is required." })
    })
    test("Passing Amount LessThen 0", () => {
        const { statusCode, message } = ValidateAddFund(-123)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Amount must be greater than 0." })
    })
    test("Passing Amount Greater Then 99999999", () => {
        const { statusCode, message } = ValidateAddFund(1234567890)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "Amount cannot be more than 8 digits." })
    })
    test("Passing Character Data", () => {
        const { statusCode, message } = ValidateAddFund("dasdas")
        expect({ statusCode, message }).toStrictEqual({ statusCode: 400, message: "The input value must be numeric" })
    })
    test("Passing Valid Value", () => {
        const { statusCode, message } = ValidateAddFund(123)
        expect({ statusCode, message }).toStrictEqual({ statusCode: 200, message: "All OK" })
    })

})