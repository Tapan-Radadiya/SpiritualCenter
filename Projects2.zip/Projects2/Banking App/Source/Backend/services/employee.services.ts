import { Wallet } from "../models/Wallet.model"
import ApiResponse from "../utils/apiResponse"
import { BankAccount } from "../models/BankAccount.model"
import { User } from "../models/User.model"
import { TransactionHistory } from "../models/TransactionHistory.model"
import { io } from ".."
import { Transaction } from "../models/Transaction.model"
import randomNumber from "../utils/getRandomNumber"


const addFundService = async (amount: number, userData: { Id: number, UserName: string }) => {
    const checkSufficientBalance = await BankAccount.findOne({ EmployeeId: userData.Id })

    if (!checkSufficientBalance) {
        return ApiResponse(401, "Unauthorized Access Or Please Login")
    }
    else if (amount > checkSufficientBalance.Balance) {
        io.to(userData.Id.toString()).emit("INSUFFICIENT_FUND_WALLET", { message: "Insufficient funds in the bank account." })
        return ApiResponse(400, "Insufficient funds in the bank account.")
    }
    else {
        const walletAvailable = await Wallet.findOne({ EmployeeId: userData.Id })
        if (walletAvailable) {
            const addFundInWallet = await Wallet.findOneAndUpdate({ EmployeeId: userData.Id }, { $inc: { Balance: amount } }) // Add Funds In Wallet
            await BankAccount.findOneAndUpdate({ EmployeeId: userData.Id }, { Balance: Number(checkSufficientBalance.Balance - amount) }) // Minus Amount From The BankAccount
            io.to(userData.Id.toString()).emit("FUNDS_ADDED", { message: `Funds added: ${amount}` })
            return ApiResponse(201, `Funds added: ${amount}`)
        }
        else {
            const createWallet = await Wallet.create({ // Creating New Wallet And Adding Amount
                WalletId: userData.Id,
                EmployeeId: userData.Id,
                Balance: amount
            })
            if (createWallet) {
                await BankAccount.findOneAndUpdate({ EmployeeId: userData.Id }, { Balance: Number(checkSufficientBalance.Balance - amount) }) // Minus Amount From The BankAccount
                io.to(userData.Id.toString()).emit("FUNDS_ADDED", { message: `Funds added: ${amount}` })
                return ApiResponse(201, `Funds added: ${amount}`)
            }
        }
    }
}

const sendMoneyService = async (Recipient: number, Amount: number, EmployeeId: number, EmployeeName: string) => {
    if (!EmployeeId) {
        return ApiResponse(400, "Unable To Get Employee Id Please Login Again")
    }
    const checkRecipientExist = await User.findOne({ Id: Recipient })
    if (!checkRecipientExist) {
        return ApiResponse(404, "No Recipient Found")
    }
    const curEmployeeWallet: any = await Wallet.findOne({ EmployeeId: EmployeeId })
    if (!curEmployeeWallet) {
        return ApiResponse(404, "You Don't Have Wallet")
    }

    if (await Wallet.findOne({ EmployeeId: Recipient })) {
        if (Amount > curEmployeeWallet?.Balance) {
            io.to(EmployeeId.toString()).emit("INSUFFICIENT_BALANCE")
            return ApiResponse(400, "Insufficient funds")
        }

        const updateRecipient = await Wallet.findOneAndUpdate({ EmployeeId: Recipient }, { $inc: { Balance: Amount } })
        if (updateRecipient) {
            await Wallet.findOneAndUpdate({ EmployeeId: EmployeeId }, { Balance: Number(curEmployeeWallet.Balance - Amount) })

            while (true) {
                let transactionId = randomNumber()
                if (!await Transaction.findOne({ TransactionId: transactionId })) {
                    await Transaction.create({
                        Amount: Amount,
                        ReceiverId: Recipient,
                        SenderId: EmployeeId,
                        TransactionId: Math.floor(Math.random() * 1001)
                    })
                    break
                }
            }
            io.to(EmployeeId.toString()).emit("PAYMENT_SUCCESS", { message: `Payment Sent: ${Amount}` })
            io.to(Recipient.toString()).emit("PAYMENT_RECEIVED", { message: `Payment received: ${Amount}` })
            return ApiResponse(200, `Payment Sent: ${Amount}`)
        }
    }
    else {
        io.to(EmployeeId.toString()).emit("WALLET_NOT_EXIST")
        return ApiResponse(404, "Wallet not exist")
    }
}

const getEmployeeWalletService = async (EmployeeId: number) => {
    const walletData = await BankAccount.aggregate(
        [
            {
                $match: {
                    EmployeeId: EmployeeId
                }
            },
            {
                $lookup: {
                    from: "wallets",
                    localField: "EmployeeId",
                    foreignField: "EmployeeId",
                    as: "result"
                }
            },
            {
                $addFields: {
                    result: {
                        $arrayElemAt: ["$result", 0]
                    }
                }
            }
        ]
    )

    return ApiResponse(200, "Data Fetched", walletData[0])
}


const getEmployeeDataService = async (user: { Id: number, UserName: string }) => {

    const userData: any = []
    const employeeData = await User.find({})
    employeeData.forEach((userDetails) => {
        if (userDetails.Id != user.Id) {
            const [firstName, lastName]: any = userDetails.Username.split("_")
            const data = {
                Id: userDetails.Id,
                UserName: firstName + " " + lastName
            }
            userData.push(data)
        }
    })
    return ApiResponse(200, "Data Fetched", userData)
}

const getTransactionHistoryDataService = async (userData: { Id: number, UserName: string }) => {
    const historyData = await Transaction.aggregate(
        [
            {
                $match: {
                    $or: [
                        { SenderId: userData.Id },
                        { ReceiverId: userData.Id }
                    ]
                }
            },
            {
                $lookup: {
                    from: "users",
                    localField: "SenderId",
                    foreignField: "Id",
                    as: "SenderEmpName"
                }
            },
            {
                $lookup: {
                    from: "users",
                    localField: "ReceiverId",
                    foreignField: "Id",
                    as: "ReceiverEmpName"
                }
            },
            {
                $addFields: {
                    SenderEmpName: { $arrayElemAt: ["$SenderEmpName", 0] },
                    ReceiverEmpName: { $arrayElemAt: ["$ReceiverEmpName", 0] }
                }
            },
            {
                $addFields: {
                    SenderEmpName: "$SenderEmpName.Username",
                    ReceiverEmpName: "$ReceiverEmpName.Username"
                }
            },
            {
                $project: {
                    ReceiverId: 0,
                    __v: 0,
                    _id: 0
                }
            }
        ]
    )
    return ApiResponse(200, "Data Fetched", historyData)
}
export {
    addFundService,
    getEmployeeWalletService,
    sendMoneyService,
    getEmployeeDataService,
    getTransactionHistoryDataService
}