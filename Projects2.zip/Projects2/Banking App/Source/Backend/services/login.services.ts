import { createTextChangeRange } from "typescript"
import { User } from "../models/User.model"
import ApiResponse from "../utils/apiResponse"
import jwt from "jsonwebtoken"

export const userLoginService = async (UserName: string, Password: string) => {

    const validateUser = await User.findOne({ Username: UserName })
    if (!validateUser) {
        return ApiResponse(400, "No UserFound")
    }
    if (validateUser.Password !== Password) {
        return ApiResponse(401, "Invalid Password")
    }
    const jwtData = {
        Id: validateUser.Id,
        UserName: validateUser.Username
    }
    const jwtToken = jwt.sign(jwtData, `${process.env.JWT_SECRET_KEY}`)
    return ApiResponse(200, "User logged In", jwtToken)
}