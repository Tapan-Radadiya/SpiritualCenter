export default function ApiResponse(statusCode: number, message: string, data?: any, err?: any) {
    return {
        statusCode: statusCode,
        message: message,
        data: data,
        err: err
    }
}