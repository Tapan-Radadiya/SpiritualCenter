"use client"
import Cookies from "js-cookie"
import { jwtDecode } from "jwt-decode"
import { socket } from "@/socket"
export function joinUser() {
    const cookie: any = Cookies.get("userdata")
    const userData: any = jwtDecode(cookie)
    socket.emit("USER_ADDED", userData.Id)
}

