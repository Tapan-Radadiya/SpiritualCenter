import { configureStore } from "@reduxjs/toolkit";
import employeeSlice from "./features/employeeSlice";

export const Store = configureStore({
    reducer: {
        employeeSlice: employeeSlice
    }
})