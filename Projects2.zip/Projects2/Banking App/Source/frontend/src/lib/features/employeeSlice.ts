import { createSlice } from "@reduxjs/toolkit";

const employeeSlice = createSlice({
    name: "Employee Slice",
    initialState: {
        EmployeeData: [],
        userWalletData: {},
        curUser: {},
        TransactionHistory: []
    },
    reducers: {
        addEmployeeData: (state: any, action: any) => {
            return {
                ...state,
                EmployeeData: action.payload
            }
        },
        addUserWalletData: (state: any, action: any) => {
            return {
                ...state,
                userWalletData: action.payload
            }
        },
        addCurUser: (state: any, action: any) => {
            return {
                ...state,
                curUser: action.payload
            }
        },
        addTransactionHistory: (state: any, action: any) => {
            return {
                ...state,
                TransactionHistory: action.payload
            }
        }
    }
})
export const {
    addEmployeeData,
    addUserWalletData,
    addCurUser,
    addTransactionHistory
} = employeeSlice.actions

export default employeeSlice.reducer