import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

export default function middleware(req: NextRequest) {
    const cookie = cookies().get("userdata")

    if (!cookie) {
        if (req.nextUrl.pathname.startsWith("/login")) {
            return NextResponse.next()
        }
        else if (!req.nextUrl.pathname.startsWith("/login")) {
            return NextResponse.redirect(new URL("/login", req.url))
        }
    }
    else if (cookie && req.nextUrl.pathname.startsWith("/login")) {
        return NextResponse.redirect(new URL("/wallet", req.url))
    }
    else if (cookie && !req.nextUrl.pathname.startsWith("/login")) {
        return NextResponse.next()
    }
}
export const config = {
    matcher: [
        "/login",
        "/wallet/:path*"
    ]
}
