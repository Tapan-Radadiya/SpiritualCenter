"use client"
import { socket } from "@/socket"
import { useEffect, useState } from "react"

export default function UserNotify() {
    const [serverRes, setServerRes] = useState("")

    useEffect(() => {
        socket.on("FUNDS_ADDED", (message) => {
            setServerRes(message.message)
        })
        socket.on("INSUFFICIENT_FUND_WALLET", (message) => {
            setServerRes(message.message)
        })
        socket.on("WALLET_NOT_EXIST", () => {
            setServerRes("Wallet not exist")
        })
        socket.on("INSUFFICIENT_BALANCE", () => {
            setServerRes("Insufficient funds")
        })
        socket.on("PAYMENT_SUCCESS", (message) => {
            setServerRes(message.message)
        })
        socket.on("PAYMENT_RECEIVED", (message) => {
            setServerRes(message.message)
        })

        return () => {
            socket.off("FUNDS_ADDED")
            socket.off("INSUFFICIENT_FUND_WALLET")
            socket.off("WALLET_NOT_EXIST")
            socket.off("INSUFFICIENT_BALANCE")
            socket.off("PAYMENT_SUCCESS")
            socket.off("PAYMENT_RECEIVED")
        }
    }, [])
    if (serverRes != "") {
        setTimeout(() => {
            setServerRes("")
        }, 5000)
    }
    return (
        <>
            {
                serverRes ?
                    <div style={{ backgroundColor: "#93ebc2" }}>
                        <p id="notification" className="p-3" style={{ fontSize: "20px" }}>
                            {serverRes}
                        </p>
                    </div>
                    : <></>
            }
        </>
    )
}