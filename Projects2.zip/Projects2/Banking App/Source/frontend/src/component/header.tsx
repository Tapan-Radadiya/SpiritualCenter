"use client"
import { useRouter } from "next/navigation"
import style from "../css/header.module.css"
import Cookies from "js-cookie"
import { useDispatch, useSelector } from "react-redux"
import { addCurUser } from "@/lib/features/employeeSlice"
import { jwtDecode } from "jwt-decode"
import { useEffect } from "react"
export default function Header() {
    const router = useRouter()
    const curUser = useSelector((state: any) => state.employeeSlice.curUser)
    const dispatch = useDispatch()

    useEffect(() => {
        const cookies = Cookies.get("userdata")
        if (cookies) {
            checkUserLoggedIn(cookies)
        }
    }, [])
    function checkUserLoggedIn(cookie: any) {
        const decodeData: any = jwtDecode(cookie)
        dispatch(addCurUser(decodeData))
    }
    function logoutHandler() {
        Cookies.remove("userdata");
        router.push("/login");
        const data: any = {}
        dispatch(addCurUser(data))
    }
    return (
        <>
            <div className="row bg-dark">
                <div onClick={() => router.push("/wallet")} className={`col-md p-2 ${style.headerLinks}`}><p className="text-center text-uppercase text-light mt-3">Wallet Balance</p></div>
                <div onClick={() => router.push("/wallet/add-funds")} className={`col-md p-2 ${style.headerLinks}`}><p className="text-center text-uppercase text-light mt-3">Add Funds</p></div>
                <div onClick={() => router.push("/wallet/send-money")} className={`col-md p-2 ${style.headerLinks}`}><p className="text-center text-uppercase text-light mt-3">Send Money</p></div>
                <div onClick={() => router.push("/wallet/transaction-history")} className={`col-md p-2 ${style.headerLinks}`}><p className="text-center text-uppercase text-light mt-3">Transaction History</p></div>
                {
                    curUser?.Id ?
                        <div id="btnlogout" onClick={() => logoutHandler()} className={`col-md p-2 ${style.headerLinks}`}><p className="text-center text-uppercase text-light mt-3">Logout</p></div> :
                        <div id="btnlogout" onClick={() => { router.push("/login") }} className={`col-md p-2 ${style.headerLinks}`}><p className="text-center text-uppercase text-light mt-3">Login</p></div>
                }
            </div>
        </>
    )
}