"use client"

import { Login_Interface } from "@/interfaces/login.interface"
import { addCurUser } from "@/lib/features/employeeSlice";
import { LoginService } from "@/services/login.services";
import { socket } from "@/socket";
import Cookies from "js-cookie";
import { jwtDecode } from "jwt-decode";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form"
import { useDispatch } from "react-redux";


export default function Login() {
    const { register, handleSubmit, formState: { errors } } = useForm<Login_Interface>()
    const router = useRouter()
    const dispatch = useDispatch()
    async function loginHandler(userLoginData: Login_Interface) {
        const { statusCode, message, data }: any = await LoginService(userLoginData)
        if (statusCode == 200) {
            const userData: any = jwtDecode(data)
            socket.emit("USER_ADDED", userData.Id)
            
            dispatch(addCurUser(userData))
            Cookies.set("userdata", data)
            router.push("/wallet")
        }
        else {
            alert(message)
            console.log(statusCode, message, data);
        }
    }
    return (
        <>
            <div className="container mt-5 w-50">
                <form onSubmit={handleSubmit((data) => loginHandler(data))}>
                    <div className="form-group mt-3">
                        <label htmlFor="username" className="form-label">Username</label>
                        <input type="text" id="username" {...register("UserName", {
                            required: { value: true, message: "Username Required" }
                        })} className="form-control border border-dark" />
                        {errors.UserName && <div className="form-text text-danger">{errors.UserName.message}</div>}
                    </div>
                    <div className="form-group mt-3">
                        <label htmlFor="userName" className="form-label">Password</label>
                        <input type="password" id="password" {...register("Password", {
                            required: { value: true, message: "Password Required" }
                        })} className="form-control border border-dark" />
                        {errors.Password && <div className="form-text text-danger">{errors.Password.message}</div>}
                    </div>
                    <div className="form-group mt-3 d-flex justify-content-center">
                        <button className="btn w-50 btn-primary" id="btnSubmit">Login </button>
                    </div>
                </form>
            </div>
        </>
    )
}