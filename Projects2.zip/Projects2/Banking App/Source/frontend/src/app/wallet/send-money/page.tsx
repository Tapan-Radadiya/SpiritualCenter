"use client"
import { addEmployeeData } from "@/lib/features/employeeSlice"
import { getEmployeeDataService, sendMoneyService } from "@/services/employee.services"
import { socket } from "@/socket"
import { joinUser } from "@/utils/socketJoin"
import { useEffect, useState } from "react"
import { useForm } from "react-hook-form"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
type SendMoney_Type = {
    Recipient: number,
    Amount: number
}
export default function SendMoney() {
    useEffect(() => {
        getEmployeeData()
        joinUser()
    }, [])

    const { register, handleSubmit, formState: { errors } } = useForm<SendMoney_Type>({ mode: "all" })
    const [serverRes, setServerRes] = useState("")

    const dispatch = useDispatch()
    const employeeData = useSelector((state: any) => state.employeeSlice.EmployeeData)
    async function getEmployeeData() {
        const { statusCode, message, data } = await getEmployeeDataService()
        if (statusCode == 200) {
            dispatch(addEmployeeData(data))
        }
        else {
            setServerRes(message)
        }
    }

    async function sendMoneyHandler(moneyData: SendMoney_Type) {
        await sendMoneyService(moneyData)
    }

    return (
        <>
            <div className="container">
                <div className="container">
                    <p className="display-6 text-center mt-5">
                        Send Money
                    </p>
                </div>
                <div className="container w-50 mt-5" >
                    <form onSubmit={handleSubmit((data) => sendMoneyHandler(data))}>
                        <div className="form-group mt-3">
                            <label htmlFor="recipientInput">Recipient</label>
                            <select id="recipientInput" {...register("Recipient", {
                                required: { value: true, message: "Recipient is required." }
                            })} className="form-select border border-dark">
                                <option value="">------------</option>
                                {
                                    employeeData.map((key: any, _: any) => (
                                        <option value={key.Id} key={key.Id}>{key.UserName}</option>
                                    ))
                                }
                            </select>
                            {errors.Recipient && <div id="recipientError" className="form-text text-danger">{errors.Recipient.message}</div>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="amountInput" className="form-label">Amount</label>
                            <input type="text" className="form-control border border-dark" id="amountInput" {...register("Amount", {
                                required: { value: true, message: "Amount is required." },
                                validate: (value) => {
                                    if (Number(value) <= 0) {
                                        return "Amount must be greater than 0."
                                    }
                                    else if (value.toString().length > 8) {
                                        return "Amount cannot exceed 8 digits"
                                    }
                                    else if (!Number(value)) {
                                        return "The input value must be numeric"
                                    }
                                }
                            })} />
                        </div>
                        {errors.Amount && <div className="form-text text-danger errordiv">{errors.Amount.message}</div>}
                        <div className="form-group d-flex justify-content-center mt-5">
                            <button className="btn btn-success w-50" id="btnSend">Send Money</button>
                        </div>
                    </form>
                    {
                        serverRes ?
                            <>{serverRes}</>
                            : <></>
                    }
                </div>
            </div>
        </>
    )
}