"use client"
import { addTransactionHistory } from "@/lib/features/employeeSlice"
import { fetchHistoryDataService } from "@/services/employee.services"
import { jwtDecode } from "jwt-decode"
import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import Cookies from "js-cookie"
import { joinUser } from "@/utils/socketJoin"

export default function Transhistory() {
    const [curUser, setCurUser] = useState("")
    useEffect(() => {
        fetchHistoryData()
        const cookie: any = Cookies.get("userdata")
        const data: any = jwtDecode(cookie)
        setCurUser(data.UserName)
        joinUser()
    }, [])
    const dispatch = useDispatch()
    const historyData = useSelector((state: any) => state.employeeSlice.TransactionHistory)
    async function fetchHistoryData() {
        const { statusCode, message, data } = await fetchHistoryDataService()
        if (statusCode == 200) {
            dispatch(addTransactionHistory(data))
        }
    }
    console.log(historyData);

    return (
        <>
            <div className="container-fluid">
                <div className="container">
                    <p className="display-6 text-center">
                        Trnasaction History
                    </p>
                </div>
                <div className="">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Transaction Id</th>
                                <th>Sender Name</th>
                                <th>Receiver Name</th>
                                <th>Amount</th>
                                <th>Time Stamp</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                historyData.map((key: any, value: any) => (
                                    <tr id={`tr${key.SenderId}`} key={value}>
                                        <td>{key.TransactionId}</td>
                                        <td>{key.SenderEmpName.split("_").join(" ")}</td>
                                        <td>{key.ReceiverEmpName.split("_").join(" ")}</td>
                                        <td>{key.Amount}</td>
                                        <td>{new Date(key.Timestamp).toLocaleDateString("en-us")}</td>
                                        <td className={key.ReceiverEmpName == curUser ? "text-success" : "text-danger"}>{key.ReceiverEmpName == curUser ? "Credit" : "Debit"}</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}