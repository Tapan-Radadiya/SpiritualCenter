"use client"
import { addUserWalletData } from "@/lib/features/employeeSlice"
import { getWalletDataService } from "@/services/employee.services"
import { socket } from "@/socket"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"

export default function WalletBalance() {
    useEffect(() => {
        getWalletData()
    }, [socket])

    const dispatch = useDispatch()
    const walletData = useSelector((state: any) => state.employeeSlice.userWalletData)
    async function getWalletData() {
        const { statusCode, message, data } = await getWalletDataService()
        if (statusCode == 200) {
            dispatch(addUserWalletData(data))
        }
        else {
            alert(message)
            console.log(statusCode, message, data);
        }
    }
    return (
        <>
            <div className="container">
                <div className="container">
                    <p className="display-5 text-center mt-5">Wallet Balance Details</p>
                </div>
                {
                    walletData.result ?
                        <div className="container text-center " style={{ marginTop: "90px" }}>
                            <p style={{ fontSize: "25px" }} id="walletbalance" className="text-success">Wallet Balance:{walletData.result?.Balance}</p>
                            <p style={{ fontSize: "25px" }} id="accountbalance">Account Balance:{walletData?.Balance}</p>
                        </div> :
                        <div className="container text-center " style={{ marginTop: "90px" }}>
                            <p style={{ fontSize: "25px" }} id="walletbalance" className="text-success">Wallet not found for the employee.</p>
                            <p style={{ fontSize: "25px" }} id="accountbalance">Account Balance:{walletData?.Balance}</p>
                        </div>
                }
            </div>
        </>
    )
}