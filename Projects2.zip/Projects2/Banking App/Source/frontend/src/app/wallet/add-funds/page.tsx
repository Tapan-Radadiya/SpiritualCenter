"use client"
import { addFundsService } from "@/services/employee.services"
import { socket } from "@/socket"
import { joinUser } from "@/utils/socketJoin"
import { useEffect, useState } from "react"
import { useForm } from "react-hook-form"
import { toast } from "react-toastify"

type addFundType = {
    amount: number
}
export default function AddFunds() {
    const { setValue, register, formState: { errors }, handleSubmit } = useForm<addFundType>({ mode: "all" })
    const [serverErr, setServerErr] = useState("")
    useEffect(() => {
        joinUser()
    }, [])
    async function addFundsHandler(fundData: addFundType) {
        const { statusCode, message, data } = await addFundsService(fundData)
        if (statusCode == 201) {
            setValue("amount", 0)
        }
        else {
            setServerErr(message)
        }
    }
    return (
        <>
            <div className="container">
                <div className="container">
                    <p className="display-6 text-center text-uppercase">Add Funds</p>
                </div>
                <div className="container mt-5 w-50">
                    <form onSubmit={handleSubmit((data) => addFundsHandler(data))}>
                        <div className="form-group mt-3">
                            <label htmlFor="amount">Amount:</label>
                            <input type="text" className="form-control border border-dark" {...register("amount", {
                                required: { value: true, message: "Amount is required." },
                                validate: (value) => {
                                    if (Number(value) <= 0) {
                                        return "Amount must be greater than 0."
                                    }
                                    else if (value.toString().length > 8) {
                                        return "Amount cannot be more than 8 digits."
                                    }
                                    else if (!Number(value)) {
                                        return "The input value must be numeric"
                                    }
                                }
                            })} id="amount" />
                            {errors.amount && <div id="errordiv" className="form-text text-danger errordiv">{errors.amount.message}</div>}
                        </div>
                        <div className="form-group mt-5 d-flex justify-content-center">
                            {
                                errors.amount ?
                                    <button className="btn btn-primary w-50" id="addFundsConfirmButton" disabled>Add Funds</button>
                                    :
                                    <button className="btn btn-primary w-50" id="addFundsConfirmButton">Add Funds</button>
                            }
                        </div>
                    </form>
                    {serverErr ? <div className="form-text text-danger" id="errBalance">Insufficient funds in the bank account.</div> : <></>}
                </div>

            </div>
        </>
    )
}