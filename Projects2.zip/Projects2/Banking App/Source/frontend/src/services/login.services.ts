"use server"
import { Login_Interface } from "@/interfaces/login.interface";
import ApiResponse from "@/utils/apiResponse";

export async function LoginService(loginData: Login_Interface) {
    const sendReq = await fetch(`http://localhost:8080/login`, {
        method: "POST",
        body: JSON.stringify(loginData),
    })
    return await sendReq.json()
}