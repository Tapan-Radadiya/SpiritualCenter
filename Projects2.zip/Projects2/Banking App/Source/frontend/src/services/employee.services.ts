async function getWalletDataService() {
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API}/employee/getWalletData`, {
        method: "GET",
        credentials: "include"
    })
    return await sendReq.json()
}

async function getEmployeeDataService() {
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API}/employee/getEmployeeData`, {
        method: "GET",
        credentials: "include"
    })
    return await sendReq.json()
}

async function sendMoneyService(moneyData: any) {
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API}/employee/sendMoney`, {
        method: "POST",
        credentials: "include",
        body: JSON.stringify(moneyData)
    })
    return await sendReq.json()
}

async function addFundsService(fundData: any) {
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API}/employee/addFunds`, {
        method: "POST",
        credentials: "include",
        body: JSON.stringify(fundData)
    })
    return await sendReq.json()
}

async function fetchHistoryDataService() {
    const sendReq = await fetch(`${process.env.NEXT_PUBLIC_API}/employee/historyData`, {
        method: "GET",
        credentials: "include",
    })
    return await sendReq.json()
}
export {
    getWalletDataService,
    getEmployeeDataService,
    sendMoneyService,
    addFundsService,
    fetchHistoryDataService
}