import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { UserLogin } from './assets/components/UserLogin'
import { ProfessorRegister } from './assets/components/AdminComponents/ProfessorRegister'
import { PageNotFound } from './assets/components/PageNotFound'
import { StudentRegister } from './assets/components/StudentComponents/StudentRegister'
import './App.css'
import "./assets/Css Files/login.style.css"
import "./assets/Css Files/professor.style.css"
import "./assets/Css Files/student.style.css"
import "./assets/Css Files/header.style.css"
import { useState } from 'react'
import { StudentInterface } from './assets/interfaces/studentinterface'
import { ProfessorInterface } from './assets/interfaces/professorInterface'
import Unauthorized from './assets/components/Unauthorized'
import ProfHeader from './assets/components/Header&Footer/ProfHeader'
import CreateExam from './assets/components/ProfessorComponents/CreateExam'
import { ExamInterface } from './assets/interfaces/examInterface'
import ViewCurrentExams from './assets/components/ProfessorComponents/ViewCurrentExams'
import AddSubject from './assets/components/ProfessorComponents/AddSubject'
import GetQuestionbankDetails from './assets/components/ProfessorComponents/GetQuestionbankDetails'
import QuestionBankData from './assets/components/ProfessorComponents/QuestionBankData'
import StudentExamData from './assets/components/ProfessorComponents/StudentExamData'
import StudentHeader from './assets/components/Header&Footer/StudentHeader'
import GiveExam from './assets/components/StudentComponents/GiveExam'
import PreviousExamResult from './assets/components/StudentComponents/PreviousExamResult'
import ExamComponent from './assets/components/StudentComponents/ExamComponent'
import CheckUser from './assets/components/CheckUser'
import AdminHeader from './assets/components/Header&Footer/AdminHeader'
import ViewProfessor from './assets/components/AdminComponents/ViewProfessor'
function App() {
  const [studentForm, setStudentForm] = useState<StudentInterface>({
    StudentName: "",
    StudentUserName: "",
    StudentEmailId: "",
    StudentPassword: ""
  })
  const [professorForm, setProfessorForm] = useState<ProfessorInterface>({
    ProfName: "",
    ProfEmailId: "",
    ProfPassword: ""
  })

  const [examForm, setExamForm] = useState<ExamInterface>({
    ExamCode: "",
    ExamName: "",
    SubjectName: "",
    ExamDuration: 0,
    ExamQuestion: 0,
    ExamTotalScore: 0,
    ExamPassingMarks: 0,
    ExamStatus: "SHOW",
    ExamStartDate: "",
    ExamEndDate: "",
  })
  const [examData, setExamData] = useState<any>({})
  const [mcqData, setMcqData] = useState([])
  const [curSelected, setCurSelected] = useState<any>([])

  return (
    <>
      <BrowserRouter>
        <Routes>
          {/* Login Route */}
          <Route element={<CheckUser />}>
            <Route path='' element={<UserLogin />} />
          </Route>

          {/* Professor Routes */}

          <Route path='/professor/createExam' element={<><ProfHeader /><CreateExam
            examForm={examForm}
            setExamForm={setExamForm}
          /></>} />
          <Route path='/professor/viewExams' element={<><ProfHeader /><ViewCurrentExams /></>} />
          <Route path='/professor/addSubject' element={<><ProfHeader /><AddSubject /></>} />
          <Route path='/professor/questionData' element={<><ProfHeader /><GetQuestionbankDetails /></>} />
          <Route path='/professor/viewQuestion/:subjectName' element={<><ProfHeader /><QuestionBankData /></>} />
          <Route path='/professor/viewStudentData' element={<><ProfHeader /><StudentExamData
          /></>} />

          {/* Student Routes */}
          <Route path='/student/studentRegister' element={<><StudentRegister
            studentForm={studentForm} setStudentForm={setStudentForm}
          /></>} />
          <Route path='/student/giveExam' element={<><StudentHeader /><GiveExam
            examData={examData}
            setExamData={setExamData}
            setMcqData={setMcqData}
            setCurSelected={setCurSelected}
          /></>} />
          <Route path='/student/viewResult' element={<><StudentHeader /><PreviousExamResult /></>} />
          <Route path='/student/startExam' element={<><ExamComponent
            examData={examData}
            mcqData={mcqData}
            curSelected={curSelected}
            setCurSelected={setCurSelected}
          /></>} />

          {/* {Admin Routes} */}
          <Route path='/admin/createExam' element={<><AdminHeader /><CreateExam
            examForm={examForm}
            setExamForm={setExamForm}
          /></>} />
          <Route path='/admin/profRegister' element={<><AdminHeader /><ProfessorRegister
            professorForm={professorForm} setProfessorForm={setProfessorForm}
          /></>} />
          <Route path='/admin/viewProfessor' element={<><AdminHeader /><ViewProfessor /></>} />
          <Route path='/admin/viewExams' element={<><AdminHeader /><ViewCurrentExams /></>} />
          <Route path='/admin/addSubject' element={<><AdminHeader /><AddSubject /></>} />
          <Route path='/admin/questionData' element={<><AdminHeader /><GetQuestionbankDetails /></>} />
          <Route path='/admin/viewQuestion/:subjectName' element={<><AdminHeader /><QuestionBankData /></>} />
          <Route path='/admin/viewStudentData' element={<><AdminHeader /><StudentExamData /></>} />
          {/* {UnAuthorized Page} */}
          <Route path='/unauthorizedUser' element={<><Unauthorized /></>} />
          <Route path='*' element={<><PageNotFound /></>} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
