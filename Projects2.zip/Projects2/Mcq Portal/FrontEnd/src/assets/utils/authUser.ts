import { jwtDecode } from "jwt-decode"
import Cookies from "js-cookie"

export default async function authUser(allowedRole: string) {
    const token: any = Cookies.get("data")
    const { ROLE }: any = jwtDecode(token)
    if (ROLE != allowedRole && ROLE != "ADMIN") {
        return true
    }
    else { return false }

}