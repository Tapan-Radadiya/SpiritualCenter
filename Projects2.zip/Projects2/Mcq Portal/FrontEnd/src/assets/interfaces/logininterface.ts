export interface LoginInterface {
    UserId: string
    UserPassword: string
}