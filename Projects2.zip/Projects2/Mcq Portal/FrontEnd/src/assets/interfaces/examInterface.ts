export interface ExamInterface {
    ExamCode: string
    ExamName: string
    SubjectName: string
    ExamDuration: number
    ExamQuestion: number
    ExamTotalScore: number
    ExamPassingMarks: number
    ExamStartDate: string
    ExamEndDate: string
    ExamStatus: string
}