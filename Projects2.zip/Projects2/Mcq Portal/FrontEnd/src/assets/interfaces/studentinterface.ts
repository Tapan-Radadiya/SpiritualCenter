export interface StudentInterface {
    StudentName: string
    StudentEmailId: string
    StudentUserName: string
    StudentPassword: string
}