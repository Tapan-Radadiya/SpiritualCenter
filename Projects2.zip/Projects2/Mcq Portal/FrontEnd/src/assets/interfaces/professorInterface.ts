export interface ProfessorInterface {
    ProfName: string
    ProfEmailId: string
    ProfPassword: string
}