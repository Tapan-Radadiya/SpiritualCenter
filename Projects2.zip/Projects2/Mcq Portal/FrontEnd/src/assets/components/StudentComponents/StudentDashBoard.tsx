import StudentHeader from "../Header&Footer/StudentHeader"

export default function StudentDashBoard() {
    return (
        <>
            <StudentHeader />
            <h1>Welcome Student</h1>
        </>
    )
}