import { useEffect, useState } from "react"
import authUser from "../../utils/authUser"

export default function PreviousExamResult() {
    const [studentExamData, setStudentExamData] = useState([])
    useEffect(() => {
        authUser("STUDENT")
        fetchStudentData()
    }, [])
    async function fetchStudentData() {
        const sendReq = await fetch("http://localhost:8080/student/getExamDetails", {
            credentials: "include",
            method: "GET"
        })
        const { statusCode, data } = await sendReq.json()
        if (statusCode == 200) {
            setStudentExamData(data)
        }
    }
    return (
        <>
            <div className="container">
                <div className="container mt-2">
                    <p className="text-center text-uppercase" style={{ fontSize: "30px" }}>Previous Exam Data</p>
                </div>
                {
                    studentExamData.map((key: any, value: any) => (
                        <div className="container">
                            <div className="container border border-dark p-3 mt-4" style={{ borderRadius: "20px", backgroundColor: key.ExamResult == "PASS" ? "#d6f5dd" : "#f7d4d7" }} key={key._id}>
                                <div className="row p-2">
                                    <div className="col-md"> <strong>Student Name : {key.StudentUserName}</strong>{ }</div>
                                    <div className="col-md"> <strong>Exam Total Question : {key.ExamQuestion}</strong>{ }</div>
                                    <div className="col-md"><strong> Exam Given Date : {new Date(key.createdAt).toLocaleDateString("en-us")}</strong>{ }</div>
                                </div>
                                <div className="row p-2">
                                    <div className="col-md"><strong>Exam Name : {key.ExamName}</strong>{ }</div>
                                    <div className="col-md"><strong>Exam Total Score : {key.ExamTotalScore}</strong>{ }</div>
                                    {key.ExamResult == "PASS" ?
                                        < div className="col-md"><strong>Exam Result : <span className="text-success">{key.ExamResult}</span></strong></div>
                                        : < div className="col-md"><strong>Exam Result : <span className="text-danger">{key.ExamResult}</span></strong></div>
                                    }
                                </div>
                                <div className="row p-2">
                                    <div className="col-md-6 text-center"><strong>Subject Name : {key.SubjectName}</strong>{ }</div>
                                    <div className="col-md-6 text-center"><strong>Obtained Marks : {key.AchievedScore} %</strong>{ }</div>
                                </div>
                            </div>
                        </div>
                    ))
                }
            </div >
        </>
    )
}