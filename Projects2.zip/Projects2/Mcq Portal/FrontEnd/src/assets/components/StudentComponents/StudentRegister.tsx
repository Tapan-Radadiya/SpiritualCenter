import { useState } from "react"
import { useNavigate } from "react-router-dom"
import validator from "validator"
import { StudentInterface } from "../../interfaces/studentinterface"


export function StudentRegister({ studentForm, setStudentForm }: any) {
    // Logic - useState - ApiCall
    const [btnStatus, setBtnStatus] = useState(false)
    const navigate = useNavigate()
    function togglePass() {
        if ($("#studentPassword").attr("type") == "text") {
            $("#studentPassword").attr("type", "password")
        }
        else {
            $("#studentPassword").attr("type", "text")
        }
    }
    // Validation
    function registerForm(e: any) {
        $("span").hide()
        $("input:text").attr("class", "form-control")
        $("input:password").attr("class", "form-control")

        const { name, value } = e.target
        setStudentForm({ ...studentForm, [name]: value })
    }
    async function registerValidation() {
        if (!$("#studentName").val()) {
            $("#nameErr").show()
            $("#studentName").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#studentuserName").val()) {
            $("#usernameErr").show()
            $("#studentuserName").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#studentEmailId").val()) {
            $("#emailErr").show().text("Please Enter Your Emailid")
            $("#studentEmailId").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#studentPassword").val()) {
            $("#passErr").show().text("Please Enter Your Password")
            $("#studentPassword").attr("class", "form-control border border-danger border-2")
            return
        }
        else {
            const emailId: any = $("#studentEmailId").val()
            const pass: any = $("#studentPassword").val()
            if (!validator.isEmail(emailId)) {
                $("#emailErr").show().text("Invalid Email Id")
                $("#studentEmailId").attr("class", "form-control border border-danger border-2")
                return
            }
            else if (!validator.isStrongPassword(pass)) {
                $("#passErr").show().text("Please Provide Strong Password")
                $("#studentPassword").attr("class", "form-control border border-danger border-2")
                return
            }
        }
        // client side validation done
        // fetch
        setBtnStatus(true)
        const reqStatus: any = await sendRequest(studentForm)
        if (reqStatus) {
            alert("Registration Successfully Please Login")
            navigate("/")
        }
    }
    async function sendRequest(studentForm: StudentInterface) {
        const myheader = new Headers()
        myheader.append("Content-Type", "application/json")
        const reqOpt = {
            method: "POST",
            headers: myheader,
            body: JSON.stringify(studentForm)
        }

        const sendData = await fetch("http://localhost:8080/student/registerStudent", reqOpt)

        const { statusCode, message }: any = await sendData.json()
        if (statusCode == 422) {
            alert(message)
            setBtnStatus(false)
        }
        else if (statusCode == 409) {
            alert(message)
            setBtnStatus(false)
        }
        else if (statusCode == 500) {
            alert(message)
            setBtnStatus(false)
        }
        else if (statusCode == 201) {
            return true
        }
    }
    return (
        <>
            <div className="studentRegister">
                <div className="container">
                    <div>
                        <p className="display-5 text-uppercase text-center p-4" style={{ letterSpacing: "5px", wordSpacing: "7px" }}>Student Registration Form</p>
                    </div>
                    <div className="container">
                        <div className="row border border-dark p-2 mt-4" style={{ borderRadius: "20px" }}>
                            <div className="col-md-5 p-5 ">
                                <img src="src/assets/Images/studentRegister.png" />
                            </div>
                            <div className="col-md-1 text-center p-4"><div className="vr" style={{ height: "600px" }}></div></div>
                            <div className="col-md-6 p-4">
                                <div>
                                    <p className="text-uppercase text-center fillDataHead">Fill All Details</p>
                                </div>
                                <div className="container p-2">
                                    <div className="form-group mt-3">
                                        <label htmlFor="studentName" className="form-label">Enter Your Name</label>
                                        <input type="text" name="StudentName" id="studentName" className="form-control" placeholder="John Doe" onChange={(e) => registerForm(e)} />
                                        <span id="nameErr" style={{ display: "none", color: "red", letterSpacing: "1px" }}>Please Enter Name</span>
                                    </div>
                                    <div className="form-group mt-4">
                                        <label htmlFor="studentuserName" className="form-label">Enter Your UserName</label>
                                        <input type="text" name="StudentUserName" id="studentuserName" className="form-control" placeholder="JohnDoe@123" onChange={(e) => registerForm(e)} />
                                        <span id="usernameErr" style={{ display: "none", color: "red", letterSpacing: "1px" }}>Please Enter Username</span>
                                    </div>
                                    <div className="form-group mt-4">
                                        <label htmlFor="studentEmailId" className="form-label">Enter Your Email-Id</label>
                                        <input type="text" name="StudentEmailId" id="studentEmailId" className="form-control text-lowercase" placeholder="john@doe" onChange={(e) => registerForm(e)} />
                                        <span id="emailErr" style={{ display: "none", color: "red", letterSpacing: "1px" }}></span>
                                    </div>
                                    <div className="form-group mt-4">
                                        <label htmlFor="studentPassword" className="form-label">Enter Your Password</label>
                                        <div className="d-flex">
                                            <input type="password" name="StudentPassword" id="studentPassword" className="form-control" placeholder="************" onChange={(e) => registerForm(e)} />
                                            <input type="checkbox" id="togglePass" className="ml-1" style={{ zoom: 2.5, border: "none" }} onClick={() => togglePass()} />
                                        </div>
                                        <small>Password Must contain 6 character, Symbol, Alphanumeric and uppercase letter</small><br />
                                        <span id="passErr" style={{ display: "none", color: "red", letterSpacing: "1px" }}></span>
                                    </div>
                                    <div className="form-group mt-5 d-flex justify-content-center">
                                        {
                                            btnStatus ?
                                                <button className="btn btn-lg btn-dark w-75 text-uppercase" style={{ letterSpacing: "8px" }} disabled>
                                                    <span className="spinner-border spinner-border-sm mr-3"></span>
                                                    <span>Registering... </span>
                                                </button>
                                                : <button className="btn btn-lg btn-dark w-75 text-uppercase" style={{ letterSpacing: "8px" }} onClick={() => registerValidation()}>Register</button>
                                        }

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}