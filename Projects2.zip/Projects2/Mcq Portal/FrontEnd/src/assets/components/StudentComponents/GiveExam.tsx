import { useState } from "react"
import { useNavigate } from "react-router-dom"
// Invalid Exam Code Please Verify Exam Code From Your Professor
export default function GiveExam({ examData, setExamData, setMcqData, setCurSelected }: any) {
    const [btnStatus, setBtnStatus] = useState(false)
    const [startExamBtn, setStartExamBtn] = useState(false)

    const navigate = useNavigate()
    async function verifyfyExamCode() {
        const examCode = $("#ExamCode").val()?.toString()
        if (!examCode) {
            $("#ExamCode").attr("class", "form-control border border-danger border-2")
            $("#examCodeErr").text("Please Enter Exam Code")
            return
        }
        if (examCode.length < 6) {
            $("#ExamCode").attr("class", "form-control border border-danger border-2")
            $("#examCodeErr").text("Exam Code have Atleast 6 Character Long")
            return
        }
        setBtnStatus(true)
        const sendReq = await fetch(`http://localhost:8080/student/giveExam/${examCode}`, {
            credentials: "include",
            method: "GET"
        })
        const { statusCode, data, message } = await sendReq.json()
        if (statusCode == 200) {
            setStartExamBtn(!startExamBtn)
            setExamData(data.ExamData)
            setMcqData(data.McqData)
            const arr = []
            for (let i = 0; i < data.McqData.length; i++) {
                arr.push({ option: [] })
            }
            setCurSelected(arr)
            return
        }
        else if (statusCode == 409) {
            $("#errorValue").text(message).show()
            $("#alertBoxError").show()
            setBtnStatus(false)
            return
        }
        else if (statusCode == 404) {
            $("#errorValue").text(message).show()
            $("#alertBoxError").show()
            setBtnStatus(false)
            return
        }
    }

    function startExam() {
        navigate("/student/startExam")
    }
    return (
        <>
            <div className="container">
                <div className="d-flex justify-content-center">
                    <div className="alert alert-danger alert-dismissible fade show" id="alertBoxError" style={{ display: "none" }}>
                        <strong className="" style={{ letterSpacing: "2px" }} id="errorValue"></strong>
                        <button type="button" className="close" data-dismiss="alert" aria-label="close">
                            <label aria-hidden="true">&times;</label>
                        </button>
                    </div>
                </div>
                <div className="container">
                    <p className="text-uppercase text-center mt-4" style={{ fontSize: "30px" }}>Enter Your Exam Code To Start Exam</p>
                </div>
                {
                    startExamBtn ?
                        <div className="container border border-dark p-3 mt-5">
                            <div className="row p-3">
                                <p className="text-center col-md-4"><strong>Exam Code</strong> {examData.ExamCode}</p>
                                <p className="text-center col-md-4"><strong>Exam Duration</strong> {examData.ExamDuration}(min)</p>
                                <p className="text-center col-md-4"><strong>Exam Name</strong> {examData.ExamName}</p>
                                <p className="text-center col-md-4"><strong>Exam Start Date</strong> {new Date(examData.ExamStartDate).toLocaleDateString("en-us")}</p>
                                <p className="text-center col-md-4"><strong>Exam End Date</strong> {new Date(examData.ExamEndDate).toLocaleDateString("en-us")}</p>
                                <p className="text-center col-md-4"><strong>Exam Subject Name </strong> {examData.SubjectName.SubjectName}</p>
                                <p className="text-center col-md-4"><strong>Total Question</strong> {examData.ExamQuestion}</p>
                                <p className="text-center col-md-4"><strong>Total Marks</strong> {examData.ExamTotalScore}</p>
                                <p className="text-center col-md-4"><strong>Passing Marks</strong> {examData.ExamPassingMarks}</p>
                            </div>
                            <hr />
                            <p style={{ fontSize: "25px" }} className="text-center form-label text-uppercase mb-5">Start Your Exam Now</p>
                            <div className="form-group mt-2 d-flex justify-content-center ">
                                <button className="btn btn-primary btn-lg w-50" onClick={() => startExam()}>Start Exam</button>
                            </div>
                        </div>
                        :

                        <div className="container border border-dark w-50 mt-5" style={{ borderRadius: "20px" }}>
                            <div className="form-group mt-2 p-3">
                                <label htmlFor="ExamCode" className="form-label">Enter Your Exam Code</label>
                                <input type="text" name="ExamCode" id="ExamCode" className="form-control border border-dark" />
                                <span id="examCodeErr" className="form-label text-danger" style={{ display: "none" }}></span>
                            </div>

                            <div className="form-group mt-3 d-flex justify-content-center mt-5 mb-4">
                                {
                                    btnStatus ? <button className="btn btn-dark btn-lg w-75" disabled>
                                        <span className="spinner-border spinner-border-sm mr-3"></span>
                                        <span>Verifying Exam Code . . . </span>
                                    </button> :
                                        <button className="btn btn-dark btn-lg w-50" onClick={() => verifyfyExamCode()}>Submit Code</button>
                                }
                            </div>
                        </div>
                }

            </div>
        </>
    )
}