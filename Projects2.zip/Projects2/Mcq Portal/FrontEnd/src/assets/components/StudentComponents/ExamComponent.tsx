import { useEffect, useRef, useState } from "react"
import { useNavigate } from "react-router-dom"
import authUser from "../../utils/authUser"
import { event } from "jquery"

export default function ExamComponent({ examData, mcqData, curSelected, setCurSelected }: any) {

    const navigate = useNavigate()
    const [tabChangedVal, setTabChangedVal] = useState(3)
    const [timer, setTimer] = useState(examData.ExamDuration * 60)
    const [mcqIndex, setMcqIndex] = useState(0)
    const divref = useRef(null)
    useEffect(() => {
        authUser("STUDENT")
        fullScr()
    }, [])

    useEffect(() => {
        if (timer > 0) {
            const timeout = setTimeout(() => {
                setTimer(timer - 1)
            }, 1000)
            return () => clearTimeout(timeout)
        }
        else {
            checkResult()
        }

    }, [timer])
    let minutes = ~~(timer / 60)
    let seconds = timer % 60

    async function fullScr() {
        const elem: any = divref.current
        if (await elem.requestFullscreen) {
            await elem.requestFullscreen()
        }
    }
    async function exitFullScr() {
        const elem: any = divref.current
        if (await elem.exitFullscreen) {
            await elem.exitFullscreen()
        }
    }
    const totalMcq = mcqData.length

    window.onblur = () => {
        alert("You Can't Change Tab When You Are In Exam")
        setTabChangedVal(tabChangedVal - 1)
    }

    if (tabChangedVal == -1) {
        setTabChangedVal(tabChangedVal + 1)
        alert("You Reached Tab Change Limit, Your Exam Is Over Thank You For Appering In Exam, Exam Will Automatically Closed")
        checkResult()
        setTimeout(() => {
            navigate("/")
            location.reload()
        }, 2000)
    }

    // Pending Work
    function checkTrueFalse(e: any, option: string) {
        const { checked, type } = e.target
        if (type == "radio") {
            curSelected[mcqIndex].option[0] = option;
            setCurSelected([...curSelected])
        }
        else {
            if (checked) {
                curSelected[mcqIndex].option.push(option)
                setCurSelected([...curSelected])
            }
            else {
                curSelected[mcqIndex].option.pop(option)
                setCurSelected([...curSelected])
            }
        }
    }

    // After Submit Button Click
    async function checkResult() {
        await exitFullScr()
        let marks = 0
        for (let i = 0; i < mcqData.length; i++) {
            const selectedAnswer = curSelected[i].option
            const actualAnswer = mcqData[i].Answers
            if (actualAnswer.length == 1) {
                if (JSON.stringify(selectedAnswer) == JSON.stringify(actualAnswer)) {
                    marks++
                }
            }
            else {
                if (selectedAnswer.length <= actualAnswer.length) {
                    actualAnswer.forEach((ele: any) => {
                        if (selectedAnswer.includes(ele)) {
                            marks += 0.5
                        }
                    })
                }
            }
        }
        await submitExam(marks)
    }
    async function submitExam(marks: number) {
        const reqBody = {
            ExamCode: examData.ExamCode,
            AchievedScore: marks
        }
        const myHeader = new Headers()
        myHeader.append("Content-Type", "application/json")
        const sendReq = await fetch(`http://localhost:8080/student/submitExam`, {
            credentials: "include",
            method: "POST",
            body: JSON.stringify(reqBody),
            headers: myHeader
        })
        const { statusCode, message } = await sendReq.json()
        if (statusCode == 200) {
            $("#examCompleteMsg").text(message)
        }
    }
    async function navigateUser() {
        navigate("/")
        location.reload()
    }
    return (
        <>

            <div className="container-fluid bg-light" ref={divref}>
                <div className="modal fade" id="examComplete" role="dialog" tabIndex={-1}>
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h3>Exam Submitted</h3>
                            </div>
                            <div className="modal-body">
                                <p id="examCompleteMsg"></p>
                            </div>
                            <div className="modal-footer">
                                <button className="btn float-right btn-success w-50" onClick={() => navigateUser()}>Ok</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="container">
                    <p className="text-center text-uppercase display-6 mt-3">Perform All Question</p>
                </div>
                <div className="container">
                    <p className="text-center text-danger">Please Don't Change Tab Or Refresh Page When You Are Giving Exam OtherWise Exam Will Be Submitted Directly</p>
                    <p className="text-center" style={{ fontSize: "20px" }}>Total Tab Change Count :<strong className="text-danger"> {tabChangedVal}</strong></p>
                </div>

                <div className="container" style={{ marginTop: "50px" }}>
                    <div className="container row">
                        <p className="col-md-11"></p>
                        <p className="col-md-1" style={{ fontSize: "25px" }}>{minutes}:{seconds}</p>
                    </div>
                    <div className="container border border-dark p-3">
                        <strong>Question No : {mcqIndex + 1}</strong>
                        <div className="m-3">
                            <p style={{ fontSize: "30px" }}> {mcqData[mcqIndex].Question}</p>
                            <div className="ml-4 mt-4">
                                <div className="form-group">
                                    <input type={mcqData[mcqIndex].Answers.length == 1 ? "radio" : "checkbox"} name={mcqData[mcqIndex].Answers.length == 1 ? "option" : "optionA"} id="optionA" className="form-input-check border border-dark" style={{ zoom: "1.5" }} onChange={(e) => checkTrueFalse(e, "OptionA")} checked={curSelected[mcqIndex].option.includes("OptionA")} />
                                    <label htmlFor="optionA" className="form-label ml-3" >{mcqData[mcqIndex].OptionA}</label>
                                </div>
                                <div className="form-group">
                                    <input type={mcqData[mcqIndex].Answers.length == 1 ? "radio" : "checkbox"} name={mcqData[mcqIndex].Answers.length == 1 ? "option" : "optionB"} id="optionB" className="form-input-check border border-dark" style={{ zoom: "1.5" }} onChange={(e) => checkTrueFalse(e, "OptionB")} checked={curSelected[mcqIndex].option.includes("OptionB")} />
                                    <label htmlFor="optionB" className="form-label ml-3" >{mcqData[mcqIndex].OptionB}</label>
                                </div>
                                {
                                    mcqData[mcqIndex].OptionC ?
                                        <div className="form-group">
                                            <input type={mcqData[mcqIndex].Answers.length == 1 ? "radio" : "checkbox"} name={mcqData[mcqIndex].Answers.length == 1 ? "option" : "optionC"} id="optionC" className="form-input-check border border-dark" style={{ zoom: "1.5" }} onChange={(e) => checkTrueFalse(e, "OptionC")} checked={curSelected[mcqIndex].option.includes("OptionC")} />
                                            <label htmlFor="optionC" className="form-label ml-3" >{mcqData[mcqIndex].OptionC}</label>
                                        </div> : <></>}
                                {mcqData[mcqIndex].OptionD ?
                                    <div className="form-group">
                                        <input type={mcqData[mcqIndex].Answers.length == 1 ? "radio" : "checkbox"} name={mcqData[mcqIndex].Answers.length == 1 ? "option" : "optionD"} id="optionD" className="form-input-check border border-dark" style={{ zoom: "1.5" }} onChange={(e) => checkTrueFalse(e, "OptionD")} checked={curSelected[mcqIndex].option.includes("OptionD")} />
                                        <label htmlFor="optionD" className="form-label ml-3" >{mcqData[mcqIndex].OptionD}</label>
                                    </div> : <></>}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="container">
                    {mcqIndex + 1 == totalMcq ? <button className="btn m-3 btn-lg col-md-1 float-right btn-success" disabled>Next &gt;</button> :
                        <button className="btn m-3 btn-lg col-md-1 float-right btn-success" onClick={() => setMcqIndex((mcqIndex) => mcqIndex + 1)}>Next &gt;</button>
                    }
                    {
                        mcqIndex == 0 ? <button className="btn m-3 btn-lg col-md-1 float-right btn-success" disabled> &lt;  Prev</button>
                            : <button className="btn m-3 btn-lg col-md-1 float-right btn-success" onClick={() => setMcqIndex((mcqIndex) => mcqIndex - 1)}> &lt;  Prev</button>
                    }
                </div>
                <div className="container mt-5 d-flex justify-content-center">
                    <button className="btn btn-lg btn-primary w-25 mt-5" onClick={() => checkResult()} data-toggle="modal" data-target="#examComplete">Submit Exam</button>
                </div>
            </div>
        </>
    )
}