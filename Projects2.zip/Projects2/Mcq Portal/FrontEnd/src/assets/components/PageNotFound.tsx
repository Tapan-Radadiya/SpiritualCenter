export function PageNotFound() {
    return (
        <>
            <div className="pageNotFoundDiv">
                <div className="container d-flex justify-content-center">
                    <img src="src/assets/Images/404 Error-amico.png" style={{ height: "700px", width: "700px" }} alt="" />
                </div>
                <div className="container d-flex justify-content-center">
                    <button className="btn btn-lg btn-outline-success w-50 text-uppercase" style={{ letterSpacing: "8px", wordSpacing: "10px" }} onClick={() => history.go(-1)}>Go Back</button>
                </div>
            </div>
        </>
    )
}