import Cookies from "js-cookie"
import { jwtDecode } from "jwt-decode"
import StudentDashBoard from "./StudentComponents/StudentDashBoard"
import ProfessorDashboard from "./ProfessorComponents/ProfessorDashboard"
import { Outlet } from "react-router-dom"
import AdminDashboard from "./AdminComponents/AdminDashboard"

export default function CheckUser() {
    const curUser: any = Cookies.get("data")
    if (!curUser) {
        return (
            <>
                <Outlet />
            </>
        )
    }
    else {
        const { ROLE }: any = jwtDecode(curUser)
        return (
            <>
                {
                    ROLE == "STUDENT" ? < StudentDashBoard /> : ROLE == "PROFESSOR" ? <ProfessorDashboard /> : <AdminDashboard />
                }
            </>
        )
    }
}