import { Editor } from "@monaco-editor/react"
import { useState } from "react"

export default function Codeeditor({ defVal, mcqData, setMcqData, subjectName }: any) {
    const [btnStatus, setBtnStatus] = useState(false)
    function setData(editor: any, monaco: any) {
        setMcqData(editor)
    }

    function mountEditor(editor: any, monaco: any) {
        setTimeout(() => {
            editor.getAction('editor.action.formatDocument').run()
        }, 300)
    }

    async function updateQuestion() {
        try {
            JSON.parse(mcqData.toString())
        } catch (error) {
            alert("You Have Error In Your Json File")
            return
        }
        setBtnStatus(true)
        const header = new Headers()
        header.append("Content-Type", "application/json")
        const sendReq = await fetch(`http://localhost:8080/professor/updateQuesion/${subjectName}`, {
            credentials: "include",
            headers: header,
            method: "POST",
            body: mcqData
        })
        const { statusCode } = await sendReq.json()
        if (statusCode == 200) {
            alert("MCQ Updated")
            location.reload()
        }
    } return (
        <> <div className="container-fluid mt-2 mb-5">
            <div className="float-right mb-1">
                {
                    btnStatus ? <button className="btn btn-md w-100 btn-primary" disabled>
                        <span className="spinner-border spinner-border-sm mr-2"></span>
                        <span>Updating Questions . . . </span>
                    </button>
                        : <button className="btn btn-md w-100 btn-primary" onClick={() => updateQuestion()}>Update Questions</button>
                }
            </div>
        </div>
            <div className="container-fluid mb-4">
                <small>Press <kbd className="bg-secondary p-3 ml-3 mr-3"> CTRL + SHIFT + I </kbd> To Format Data</small>
                <Editor
                    height={"90vh"}
                    defaultLanguage="json"
                    defaultValue={defVal}
                    theme="vs-dark"
                    onChange={setData}
                    onMount={mountEditor}
                />
            </div>

        </>
    )
}