import { useState } from "react"
import { LoginInterface } from "../interfaces/logininterface"
import Cookies from "js-cookie"
import { useNavigate } from "react-router-dom"
import ProfessorDashboard from "./ProfessorComponents/ProfessorDashboard"
import StudentDashBoard from "./StudentComponents/StudentDashBoard"

export function UserLogin() {
    // Logic - useState - ApiCall
    const [btnStatus, setBtnStatus] = useState(false)
    const [loginForm, setLoginForm] = useState<LoginInterface>({
        UserId: "",
        UserPassword: ""
    })
    const navigate = useNavigate()
    function togglePassword() {
        if ($("#userPass").attr("type") == "text") {
            $("#userPass").attr("type", "password")
        }
        else {
            $("#userPass").attr("type", "text")
        }
    }
    // Validation
    function registerForm(e: any) {
        $("span").hide()
        $("input:text").attr("class", "form-control")
        $("input:password").attr("class", "form-control")
        const { name, value } = e.target
        setLoginForm({ ...loginForm, [name]: value })
    }

    async function registerValidation() {
        if (!$("#userId").val()) {
            $("#emailErr").show().text("Please Enter Your Name")
            $("#userId").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#userPass").val()) {
            $("#emailErr").show().text("Please Enter Your EmailId")
            $("#passErr").attr("class", "form-control border border-danger border-2")
            return
        }

        setBtnStatus(true)
        const data = await sendRequest(loginForm)
        if (data) {
            location.reload()
        }
    }
    async function sendRequest(loginForm: LoginInterface) {
        const header = new Headers()
        header.append("Content-Type", "application/x-www-form-urlencoded")

        const urlencoded = new URLSearchParams()
        urlencoded.append("UserId", loginForm.UserId)
        urlencoded.append("UserPassword", loginForm.UserPassword)

        const requestOption = {
            method: "POST",
            headers: header,
            body: urlencoded
        }
        const sendReq = await fetch("http://localhost:8080/login", requestOption)
        const { statusCode, message, data }: any = await sendReq.json();
        if (statusCode == 401) {
            alert("Invalid User Name Or Password")
            setBtnStatus(false)
        }
        else if (statusCode == 404) {
            $("#errorValue").text("Invalid Email-Id Or Password")
            $("#alertBoxError").show()
            setBtnStatus(false)
        }
        else {
            Cookies.set("data", data.cookie)
            return data.Role
        }
    }
    return (
        <>
            <div className="loginDiv_main">
                <div className="d-flex justify-content-center" >
                    <div className="alert alert-danger alert-dismissible fade show w-25" id="alertBoxError" style={{ display: "none" }}>
                        <strong className="ml-5" style={{ letterSpacing: "2px" }} id="errorValue"></strong>
                        <button type="button" className="close" data-dismiss="alert" aria-label="close">
                            <label aria-hidden="true">&times;</label>
                        </button>
                    </div>
                </div>
                <div className="container">
                    <div className="mt-4">
                        <p className="display-4 text-uppercase text-center text-white setfont">Please Login</p>
                    </div>
                    <div className="row mt-5 border border-dark p-5" style={{ borderRadius: "20px", boxShadow: "0px 0px 50px 10px" }}>
                        <div className="col-md-5">
                            <img src="src/assets/Images/login.png" alt="imagenormal" />
                        </div>
                        <div className="col-1 text-center"><div className="vr" style={{ color: "black", height: "500px", width: "2px", margin: "20px" }}></div></div>
                        <div className="col-md-6">
                            <div className="container">
                                <div>
                                    <p className="text-center text-white text-uppercase" style={{ fontSize: "35px", letterSpacing: "10px", fontWeight: "300", wordSpacing: "5px" }}>Fill All Details</p>
                                </div>
                                <div className="form-group mt-5">
                                    <label htmlFor="userId" className="form-label text-white" style={{ letterSpacing: "2px", fontSize: "20px" }}>Enter Your UserId Or EmailId</label>
                                    <input type="text" name="UserId" id="userId" className="form-control" placeholder="Enter your userid or emailid" onChange={(e) => registerForm(e)} />
                                    <span id="emailErr" style={{ color: "black", display: "none", letterSpacing: "2px" }}></span>
                                </div>
                                <div className="form-group mt-5">
                                    <label htmlFor="userPass" className="form-label text-white" style={{ letterSpacing: "2px", fontSize: "20px" }}>Enter Your Password</label>
                                    <input type="password" name="UserPassword" id="userPass" className="form-control" placeholder="Enter your password"
                                        onChange={(e) => registerForm(e)} />
                                    <span id="passErr" style={{ color: "black", display: "none", letterSpacing: "2px" }}></span>
                                </div>
                                <div className="form-group mt-2 d-flex align-self-center ml-1">
                                    <input type="checkbox" id="showPass" className="form-input-check border border-dark hoverpointer" onClick={() => togglePassword()} style={{ zoom: "2" }} />
                                    <label htmlFor="showPass" className="text-white ml-3 mt-2 hoverpointer user-select-none" >Show Password</label>
                                </div>
                                <div className="p-2">
                                    <div className="container d-flex justify-content-center mt-3">
                                        {
                                            btnStatus ?
                                                <button className="btn btn w-75 btn-dark text-white text-uppercase btnfont" style={{ letterSpacing: "2px", wordSpacing: "3px" }} disabled>
                                                    <span className="spinner-border spinner-border-sm mr-3"></span>
                                                    <span>Logging In . . . </span>
                                                </button>
                                                : <button className="btn btn w-75 btn-dark text-white text-uppercase btnfont" style={{ letterSpacing: "8px" }} onClick={() => registerValidation()}>Login</button>
                                        }
                                    </div>
                                    <div className="d-flex justify-content-center mt-2 mb-2">
                                        <hr className="text-white" style={{ width: "1000px", boxShadow: "0px 0px 10px 2px" }} />
                                    </div>
                                    <div className="container d-flex justify-content-center mt-1">
                                        <button className="btn btn w-75 btn-dark text-white text-uppercase btnfont" style={{ letterSpacing: "2px", wordSpacing: "3px" }} onClick={() => navigate("/student/studentRegister")}>Register Your Self</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}