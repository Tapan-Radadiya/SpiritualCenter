export default function Unauthorized() {
    return (
        <>
            <div>
                <div className="mt-4">
                    <p className="text-center display-6 text-uppercase">You Are Not Authorized to view this content</p>
                </div>
                <div className="container d-flex justify-content-center">
                    <img src="src/assets/Images/401 Error Unauthorized-rafiki.png" style={{ height: "700px", width: "700px" }} alt="" />
                </div>
                <div className="d-flex justify-content-center">
                    <button className="btn btn-lg btn-primary w-25" onClick={() => window.history.go(-1)}>Go Back</button>
                </div>
            </div>
        </>
    )
}