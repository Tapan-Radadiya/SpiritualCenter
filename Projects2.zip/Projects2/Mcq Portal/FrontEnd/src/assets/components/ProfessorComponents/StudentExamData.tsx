import { useEffect, useState } from "react"
import authUser from "../../utils/authUser"
import { useNavigate } from "react-router-dom"

export default function StudentExamData() {
    let [studentExamData, setStudentExamData] = useState([])
    const [subjectData, setSubjectData] = useState([])
    const [studentName, setStudentName] = useState([])
    const [filterData, setFilerData] = useState([])
    const navigate = useNavigate()

    useEffect(() => {
        userAuth()
        fetchData()
        getSubjectData()
        getStudentnames()
    }, [])

    async function userAuth() {
        if (await authUser("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }
    async function fetchData() {
        const sendReq = await fetch("http://localhost:8080/professor/studentExamData", {
            credentials: "include",
            method: "GET"
        })
        const { statusCode, data } = await sendReq.json()
        if (statusCode == 200) {
            setStudentExamData(data)
            setFilerData(data)
        }
    }

    async function getStudentnames() {
        const sendReq = await fetch("http://localhost:8080/professor/studentName", {
            credentials: "include",
            method: "GET"
        })
        const { statusCode, data } = await sendReq.json()
        if (statusCode == 200) {
            setStudentName(data)
        }
    }

    async function getSubjectData() {
        var reqOpt = {
            method: "GET",
        }
        const sendReq = await fetch("http://localhost:8080/professor/getSubject", reqOpt)
        const { statusCode, data } = await sendReq.json()
        if (statusCode == 200) {
            setSubjectData(data.subjectData)
        }
        else {
            alert("Error Try After SomeTime")
        }
    }

    function filterDataByDate() {
        const sortedData = studentExamData.sort((a: any, b: any) => {
            if (new Date(a.createdAt).toLocaleDateString() < new Date(b.createdAt).toLocaleDateString()) return -1;
            else return 1
        })
        setFilerData(sortedData)
    }
    function filterByMarks() {
        const sortedData = studentExamData.sort((a: any, b: any) => {
            if (a.AchievedScore < b.AchievedScore) return 1;
            else return -1
        })

        setFilerData([...sortedData])
    }
    async function sortBySubject(e: any) {
        const { value } = e.target
        if (value == "") {
            setFilerData(studentExamData)
        }
        else {
            const data = studentExamData.filter((ele: any) => ele.SubjectName == value)
            setFilerData(data)
        }
    }
    async function sortByStudentName() {
        let studentName: any = $("#studentname").val()
        studentName = studentName.toLowerCase()
        if (studentName) {
            const data = studentExamData.filter((ele: any) => ele.StudentUserName.toLowerCase() == studentName)
            setFilerData(data)
        }
        else {
            setFilerData(studentExamData)
        }
    }
    return (
        <>
            <div className="container mt-3">
                <div className="container">
                    <p className="text-center text-uppercase" style={{ fontSize: "30px", letterSpacing: "3px", wordSpacing: "4px" }}>Student Data</p>
                </div>
                <div className="container">
                    <div className="container">
                        <select className="form-select float-right w-25 border border-dark mt-2" onChange={(e) => sortBySubject(e)}>
                            <option value="">----</option>
                            {
                                subjectData.map((key: any, value: any) => (
                                    <option value={key}>{key}</option>
                                ))
                            }
                        </select>
                        <button className="btn float-right btn-dark m-2" onClick={() => filterDataByDate()}><i className="fas fa-car"></i>Filter By Date</button>
                        <button className="btn float-right btn-dark m-2" data-toggle="modal" data-target="#studentData"><i className="fas fa-car"></i>Filter By Student Name</button>
                        <button className="btn float-right btn-dark m-2" onClick={() => filterByMarks()}><i className="fas fa-car" ></i>Filter By Student Marks</button>
                    </div>
                    <div className="modal fade" id="studentData">
                        <div className="modal-dialog modal-dialog-centered" role="document">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h3>Select Student Name</h3>
                                </div>
                                <div className="modal-body">
                                    <div className="container">
                                        <div className="form-group">
                                            <select id="studentname" className="form-select border border-dark">
                                                <option value="">- - - - -</option>
                                                {
                                                    studentName.map((key: any, value: any) => (
                                                        <option value={key}>{key}</option>
                                                    ))
                                                }
                                            </select>
                                        </div>
                                    </div>
                                    <div className="container">
                                        <button className="btn float-right btn-success m-3 w-25" data-dismiss="modal" onClick={() => sortByStudentName()}>Filter</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <table className="table table-striped table-hover" summary="Student Marks Data">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Exam Name</th>
                                <th>Total Question</th>
                                <th>Subject Name</th>
                                <th>Total Marks</th>
                                <th>Obtained Marks</th>
                                <th>Exma Result</th>
                                <th>Exam Given Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                filterData.map((key: any, value: any) => (
                                    <tr key={key._id}>
                                        <td>{key.StudentUserName}</td>
                                        <td>{key.ExamName}</td>
                                        <td>{key.ExamQuestion}</td>
                                        <td>{key.SubjectName}</td>
                                        <td>{key.ExamTotalScore}</td>
                                        <td>{key.AchievedScore}</td>
                                        <td>{key.ExamResult}</td>
                                        <td>{new Date(key.createdAt).toLocaleDateString()} -- {new Date(key.createdAt).toLocaleTimeString("en-us")}</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}