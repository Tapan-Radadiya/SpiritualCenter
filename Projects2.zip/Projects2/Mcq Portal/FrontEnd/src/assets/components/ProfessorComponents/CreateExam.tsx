import { useEffect, useState } from "react"
import { ExamInterface } from "../../interfaces/examInterface"
import decodeJwt from "../../utils/authUser"
import { useNavigate } from "react-router-dom"
export default function CreateExam({ examForm, setExamForm }: any) {
    const [subjectData, setSubjectData] = useState([])
    const navigate = useNavigate()
    useEffect(() => {
        authUser()
        getSubjectData()
    }, [])

    async function authUser() {
        if (await decodeJwt("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }
    async function getSubjectData() {
        var reqOpt = {
            method: "GET",
        }
        const sendReq = await fetch("http://localhost:8080/professor/getSubject", reqOpt)
        const { statusCode, data } = await sendReq.json()
        if (statusCode == 200) {
            setSubjectData(data.subjectData)
        }
        else {
            alert("Error Try After SomeTime")
            history.go(-1)
        }
    }
    function createForm(e: any) {
        $("span").hide()
        $("input:text").attr("class", "form-control border border-dark")
        $("#examStartDate").attr("class", "form-control border border-dark")
        $("#examEndDate").attr("class", "form-control border border-dark")
        $("#subjectName").attr("class", "form-select border border-dark")
        const { name, value } = e.target
        setExamForm({ ...examForm, [name]: value })
    }
    async function validateExamForm() {
        if (!$("#examCode").val()) {
            $("#examCodeErr").show().text("Please Enter Exam Code")
            $("#examCode").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#examName").val()) {
            $("#examNameErr").show()
            $("#examName").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#subjectName").val()) {
            $("#subErr").show()
            $("#subjectName").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#examDuration").val()) {
            $("#examDurationErr").show().text("Please Enter Exam Duration")
            $("#examDuration").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#examTotalScore").val()) {
            $("#examScoreErr").show().text("Please Enter Exam Total Score")
            $("#examTotalScore").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#examQuestion").val()) {
            $("#examQueErr").show().text("Please Enter Total Question")
            $("#examQuestion").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#examStartDate").val()) {
            $("#examStartDateErr").show()
            $("#examStartDate").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#examEndDate").val()) {
            $("#examEndDateErr").show()
            $("#examEndDate").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#examPassingMarks").val()) {
            $("#exmaPassingMarksErr").show().text("Please Enter Exam Passing Marks")
            $("#examPassingMarks").attr("class", "form-control border border-danger border-2")
            return
        }
        else {
            let examduration: any = $("#examDuration").val()
            let examTotalScore: any = $("#examTotalScore").val()
            let examStartDate: any = $("#examStartDate").val()
            let examEndDate: any = $("#examEndDate").val()
            let passingMarks: any = $("#examPassingMarks").val()
            let totalQue: any = $("#examQuestion").val()

            if (parseInt(totalQue) < 0) {
                $("#examQueErr").show().text("Total Question Should Be Positive Integer")
                $("#examQuestion").attr("class", "form-control border border-danger border-2")
                return
            }
            else if (parseInt(examduration) < 5) {
                $("#examDurationErr").show().text("Exam Duration Should Be Atlease 5 Minutes")
                $("#examDuration").attr("class", "form-control border border-danger border-2")
                return
            }
            else if (parseInt(examTotalScore) < 5) {
                $("#examScoreErr").show().text("Please Should Have Atlease 5 Marks")
                $("#examTotalScore").attr("class", "form-control border border-danger border-2")
                return
            }
            else if (new Date(examEndDate).toLocaleDateString("en-us") <= new Date(examStartDate).toLocaleDateString("en-us")) {
                $("#examStartDateErr").show().text("Exam End Should Greter Then Exam Start Date")
                $("#examStartDate").attr("class", "form-control border border-danger border-2")
                $("#examEndDateErr").show().text("Exam End Should Greter Then Exam Start Date")
                $("#examEndDate").attr("class", "form-control border border-danger border-2")
                return
            }
            else if (parseInt(passingMarks) >= parseInt(examTotalScore)) {
                $("#exmaPassingMarksErr").show().text("Passing Marks Should Not Be Greater Then TotalScore")
                $("#examPassingMarks").attr("class", "form-control border border-danger border-2")
                return
            }
        }

        if (examForm.ExamEndDate == "") {
            setExamForm({ ...examForm, ExamEndDate: new Date().toISOString().split("T")[0] })
        }
        if (examForm.ExamStartDate == "") {
            console.log("true")
            setExamForm({ ...examForm, ExamStartDate: new Date().toISOString().split("T")[0] })
        }

        await sendReq(examForm)
    }
    async function sendReq(examForm: ExamInterface) {
        if ($("#examStatus").prop("checked") == true) {
            setExamForm({ ...examForm, ExamStatus: "SHOW" })
        }
        else {
            setExamForm({ ...examForm, ExamStatus: "HIDE" })
        }
        const myHeader = new Headers()
        myHeader.append("Content-Type", "application/json")
        const sendReq = await fetch("http://localhost:8080/professor/createExam",
            {
                credentials: "include",
                headers: myHeader,
                method: "POST",
                body: JSON.stringify(examForm)
            })
        const { statusCode, message } = await sendReq.json()
        if (statusCode == 409) {
            $("#errorValue").text(message)
            $("#alertBoxError").show()
        }
        else if (statusCode == 404) {
            $("#errorValue").text(message)
            $("#alertBoxError").show()
        }
        else if (statusCode == 500) {
            $("#errorValue").text(message)
            $("#alertBoxError").show()
        }
        else if (statusCode == 201) {
            $("#errorValue").text(message)
            $("#alertBoxError").attr("class", "alert alert-success alert-dismissible fade show w-25").show()
            $("input").val("")
            $("select").val("")
        }
    }
    return (
        <>
            <div className="d-flex justify-content-center" >
                <div className="alert alert-danger alert-dismissible fade show w-25" id="alertBoxError" style={{ display: "none" }}>
                    <strong className="ml-5" style={{ letterSpacing: "2px" }} id="errorValue"></strong>
                    <button type="button" className="close" data-dismiss="alert" aria-label="close">
                        <label aria-hidden="true">&times;</label>
                    </button>
                </div>
            </div>
            <div className="container border border-dark mt-5 p-2" style={{ borderRadius: "20px" }}>
                <p className="text-center text-uppercase" style={{ fontSize: "30px", letterSpacing: "4px", wordSpacing: "5px" }}>Create Exam</p>
                <div className="container w-75">
                    <div className="form-group mt-2">
                        <label htmlFor="examCode" className="form-label">Enter Unique Exam Code</label>
                        <input type="text" name="ExamCode" id="examCode" className="form-control border border-dark" onChange={(e) => createForm(e)} />
                        <span id="examCodeErr" style={{ color: "red", display: "none" }}></span>
                    </div>
                    <div className="form-group mt-2">
                        <label htmlFor="examName" className="form-label">Enter Your Exam Name</label>
                        <input type="text" name="ExamName" id="examName" className="form-control border border-dark" onChange={(e) => createForm(e)} />
                        <span id="examNameErr" style={{ color: "red", display: "none" }}>Please Enter Exam Name</span>
                    </div>
                    <div className="row">
                        <div className="form-group mt-2 col-md">
                            <label htmlFor="subjectName" className="form-label">Select Exam Subject</label>
                            <select name="SubjectName" id="subjectName" className="form-select border border-dark" onChange={(e) => createForm(e)}>
                                <option value="">- - - - - </option>
                                {
                                    subjectData.map((value: any, key: any) => (
                                        <option value={value} key={key}>{value}</option>
                                    ))
                                }

                            </select>
                            <span id="subErr" style={{ color: "red", display: "none" }}>Please Select Exam Subject</span>
                        </div>
                        <div className="form-group mt-2 col-md">
                            <label htmlFor="examQuestion" className="form-label">Enter Total Question</label>
                            <input type="text" name="ExamQuestion" id="examQuestion" className="form-control border border-dark" onChange={(e) => createForm(e)} />
                            <span id="examQueErr" style={{ color: "red", display: "none" }}></span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="form-group mt-2 col-md">
                            <label htmlFor="examDuration" className="form-label">Enter Exam Duration (minutes)</label>
                            <input type="text" name="ExamDuration" id="examDuration" className="form-control border border-dark" onChange={(e) => createForm(e)} />
                            <span id="examDurationErr" style={{ color: "red", display: "none" }}></span>
                        </div>
                        <div className="form-group mt-2 col-md">
                            <label htmlFor="examTotalScore" className="form-label">Enter Total Marks For Exam</label>
                            <input type="text" name="ExamTotalScore" id="examTotalScore" className="form-control border border-dark" onChange={(e) => createForm(e)} />
                            <span id="examScoreErr" style={{ color: "red", display: "none" }}></span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="form-group mt-2 col-md">
                            <label htmlFor="examStartDate" className="form-label">Select Exam Start Date</label>
                            <input type="date" name="ExamStartDate" id="examStartDate" className="form-control border border-dark" min={new Date().toISOString().split("T")[0]} onChange={(e) => createForm(e)} />
                            <span id="examStartDateErr" style={{ color: "red", display: "none" }}>Please Select Exam Start Date</span>
                        </div>
                        <div className="form-group mt-2 col-md">
                            <label htmlFor="examEndDate" className="form-label">Select Exam End Date</label>
                            <input type="date" name="ExamEndDate" id="examEndDate" className="form-control border border-dark" min={new Date().toISOString().split("T")[0]} onChange={(e) => createForm(e)} />
                            <span id="examEndDateErr" style={{ color: "red", display: "none" }}>Please Select Exam End Date</span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="form-group mt-2 col-md">
                            <label htmlFor="examPassingMarks" className="form-label">Enter Passing Marks For Exam </label>
                            <input type="text" name="ExamPassingMarks" id="examPassingMarks" className="form-control border border-dark" onChange={(e) => createForm(e)} />
                            <span id="exmaPassingMarksErr" style={{ color: "red", display: "none" }}></span>
                            <small>How Many MCQ Should Be Right</small>
                        </div>
                        <div className="form-group mt-5 col-md ml-5 d-flex">
                            <input type="checkbox" name="ExamStatus" id="examStatus" className="form-check-input border border-dark p-2" onChange={(e) => createForm(e)} defaultChecked />
                            <label htmlFor="examStatus" className="form-label ml-3">Show Exam? (checked = show)</label>
                        </div>
                    </div>
                    <div className="container mt-5 d-flex justify-content-center mb-4">
                        <button className="btn btn-lg w-50 btn-primary" onClick={() => validateExamForm()}>Create Exam</button>
                    </div>
                </div>
            </div>
        </>
    )
}