import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import authUser from "../../utils/authUser"
export default function GetQuestionbankDetails() {
    const [mcqData, setMcqData] = useState([])
    const navigate = useNavigate()
    useEffect(() => {
        userAuth()
        getQuestionData()
    }, [])

    async function userAuth() {
        if (await authUser("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }

    async function getQuestionData() {
        const sendReq = await fetch("http://localhost:8080/professor/getSubjectQuestions", {
            credentials: "include",
            method: "GET"
        })
        const { data, message, statusCode } = await sendReq.json()
        if (statusCode == 200) {
            setMcqData(data)
        }
    }
    return (
        <>
            <div className="container">
                <div className="container mt-4">
                    <p className="text-uppercase text-center" style={{ fontSize: "35px", letterSpacing: "3px" }}>Question Bank</p>
                </div>
                <hr />
                <div className="container mt-5" key={"dsa"}>
                    {
                        mcqData.map((key: any, value: any) => (
                            <div className="container d-flex row p-2" key={key.subjectName}>
                                <div className="container row border border-dark pt-3 pl-3 pr-3 col-md-10" style={{ borderRadius: "15px" }} key={key.subjectName}>
                                    <div className="col-md-6 text-center"><strong style={{ fontSize: "20px" }}>Subject Name</strong></div>
                                    <div className="col-md-6 text-center"><strong style={{ fontSize: "20px" }}>Total Questions</strong></div>
                                    <div className="col-md-6 text-center"><p style={{ fontSize: "18px" }}>{key.SubjectName}</p></div>
                                    <div className="col-md-6 text-center"><p style={{ fontSize: "18px" }}>{key.TotalQuestions}</p></div>
                                </div>
                                <div className="container col-md-2 d-flex p-3" key={key.subjectName}>
                                    <button className="btn btn-info mr-3" onClick={() => navigate(`/professor/viewQuestion/${key.SubjectName}`)}>View Question</button>
                                    <button className="btn btn-danger" disabled>Delete This Subject</button>
                                </div>
                            </div>
                        ))}
                </div>
            </div>
        </>
    )
}