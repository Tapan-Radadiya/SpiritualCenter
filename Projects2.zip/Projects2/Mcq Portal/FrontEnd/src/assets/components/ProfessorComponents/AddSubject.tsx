import { useEffect, useState } from "react"
import authUser from "../../utils/authUser"
import { useNavigate } from "react-router-dom"
export default function AddSubject() {
    const [btnStatus, setBtnStatus] = useState(false)
    const navigate = useNavigate()
    useEffect(() => {
        userAuth()
    }, [])
    async function userAuth() {
        if (await authUser("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }
    async function addSubject() {
        setBtnStatus(true)
        if (!$("#subjectName").val()) {
            $("#subjectErr").show()
            $("#subjectName").attr("class", "form-control border border-danger border-2")
            setBtnStatus(false)
            return
        }
        const SubjectName: any = $("#subjectName").val()
        const headers = new Headers()
        headers.append("Content-Type", "application/json")
        const sendReq = await fetch("http://localhost:8080/professor/createSub", {
            credentials: "include",
            headers: headers,
            method: "POST",
            body: JSON.stringify({ SubjectName: SubjectName })
        })
        const { statusCode, message } = await sendReq.json()
        console.log(statusCode)
        if (statusCode == 409) {
            console.log("helo 409")
            $("#errorValue").text(message)
            $("#alertBoxError").attr("class", "alert alert-danger alert-dismissible fade show w-25").show()
            setBtnStatus(false)
        }
        else if (statusCode == 201) {
            console.log("helo 201")
            $("#errorValue").text(message)
            $("#alertBoxError").attr("class", "alert alert-success alert-dismissible fade show w-25").show()
            $("input").val('')
            setBtnStatus(false)
        }
        else if (statusCode == 500) {
            console.log("helo 500")
            $("#errorValue").text(message)
            $("#alertBoxError").attr("class", "alert alert-danger alert-dismissible fade show w-25").show()
            setBtnStatus(false)
        }
    }
    return (
        <>
            <div className="d-flex justify-content-center" >
                <div className="alert alert-danger alert-dismissible fade show w-25" id="alertBoxError" style={{ display: "none" }}>
                    <strong className="ml-5" style={{ letterSpacing: "2px" }} id="errorValue"></strong>
                    <button type="button" className="close" data-dismiss="alert" aria-label="close">
                        <label aria-hidden="true">&times;</label>
                    </button>
                </div>
            </div>
            <div className="container">
                <div className="container mt-3">
                    <p className="text-uppercase text-center" style={{ fontSize: "35px", letterSpacing: "3px" }}>Add New Subject</p>
                </div>
                <div className="container mt-4 border border-dark w-75" style={{ borderRadius: "20px" }}>
                    <div className="form-group mt-4 pt-5 pl-5 pr-5">
                        <label htmlFor="subjectName" className="form-label">Enter Subject Name</label>
                        <input type="text" name="SubjectName" id="subjectName" className="form-control border border-dark"
                            onChange={() => { $("#subjectErr").hide(); $("#subjectName").attr("class", "form-control border border-dark") }} />
                        <span style={{ display: "none", color: "red" }} id="subjectErr">Please Enter Subject Name</span>
                    </div>
                    <div className="form-group d-flex justify-content-center pb-4">
                        {
                            btnStatus ? <button className="btn btn-dark btn-lg w-50 mt-5" disabled>
                                <span className="spinner-border spinner-border-sm mr-3"></span>
                                <span>Adding New Subject ....</span>
                            </button>
                                : <button className="btn btn-dark btn-lg w-50 mt-5" onClick={() => addSubject()}>Add Subject</button>}
                    </div>
                </div>
            </div>
        </>
    )
}