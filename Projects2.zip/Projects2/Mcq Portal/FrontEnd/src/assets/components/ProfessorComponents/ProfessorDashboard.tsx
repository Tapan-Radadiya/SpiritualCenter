import decodeJwt from "../../utils/authUser"
import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import ProfHeader from "../Header&Footer/ProfHeader"

export default function ProfessorDashboard({ setSubjectData }: any) {
    const navigate = useNavigate()
    useEffect(() => {
        // checkAuth()
      
    }, [])
    async function checkAuth() {
        if (await decodeJwt("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }
    
    return (
        <>
            <ProfHeader />
        </>
    )
}