import { useEffect, useState } from "react"
import authUser from "../../utils/authUser"
import { useNavigate, useParams } from "react-router-dom"
import Codeeditor from "../CodeEditor"
export default function QuestionBankData() {
    const { subjectName } = useParams()

    const [editData, setEditData] = useState(false)

    const [mcqData, setMcqData] = useState([])
    const navigate = useNavigate()
    useEffect(() => {
        userAuth()
        fetchQuestionData()
    }, [])

    async function userAuth() {
        if (await authUser("PROFESSOR")) {
            console.log("Helo")
            navigate("/unauthorizedUser")
        }
    }
    const myheader = new Headers()
    myheader.append("Content-Type", "application/json")

    async function fetchQuestionData() {
        const sendReq = await fetch("http://localhost:8080/professor/getQuestionData/10/0", {
            credentials: "include",
            method: "POST",
            headers: myheader,
            body: JSON.stringify({ subjectName: subjectName })
        })
        const { statusCode, data } = await sendReq.json()
        if (statusCode == 200) {
            setMcqData(data.Data)
        }
    }

    function changeEditMode(e: any) {
        setEditData(!editData)
    }
    function openFullScreen() {
        const elem = $("#codeEditor")
    }
    return (
        <>
            <div className="container-fluid">
                <div className="container">
                    <p className="text-uppercase text-center mt-2" style={{ fontSize: "30px" }}>Mcq Data Of {subjectName}</p>
                    <p className="text-center text-danger">Please Dont Make Any Changes In Schema <b>If you Have To Add New Mcq Add Same As Above Schema</b> </p>
                </div>
                {/* <div className="container mb-4 float-right row">
                    <div className="col-md-10"></div>
                    <button className={editData ? "btn btn-success col-md mr-1" : "btn btn-outline-success col-md mr-1"} id="editBtn" onClick={(e) => changeEditMode(e)}>Edit</button>
                    <button className={editData ? "btn btn-outline-danger col-md" : "btn btn-danger col-md"} id="viewBtn" onClick={(e) => changeEditMode(e)}>View</button>
                    <button className="btn btn-success" onClick={() => openFullScreen()}>Full Screen Mode</button>
                </div> */}
                <div className="container-fluid codeEditor" style={{ marginTop: "20px" }}>
                    {/* <p id="questionData" contentEditable={editData ? true : false}>{JSON.stringify(mcqData)}</p> */}
                    <Codeeditor defVal={JSON.stringify(mcqData)} mcqData={mcqData} setMcqData={setMcqData} subjectName={subjectName} />
                </div>
            </div>

        </>
    )
}