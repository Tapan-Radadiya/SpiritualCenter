import { useEffect, useState } from "react"
import ChangeExamStatus from "../UtilsComponents/ChangeExamStatus"
import decodeJwt from "../../utils/authUser"
import { useNavigate } from "react-router-dom"
export default function ViewCurrentExams() {

    const [examData, setExamData] = useState([])
    const navigate = useNavigate()
    useEffect(() => {
        authUser()
        getExamData()
    }, [])
    async function authUser() {
        if (await decodeJwt("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }
    async function getExamData() {
        const sendReq = await fetch("http://localhost:8080/professor/getExams", {
            credentials: "include",
            method: "GET",
        })
        const { statusCode, data } = await sendReq.json()
        if (statusCode == 200) {
            setExamData(data)
        }
    }
    let [examId, setExamId] = useState<any>();
    async function deleteExam(examId: string) {
        if (confirm("Are You Sure You Want To Delete This Exam ?")) {
            const sendReq = await fetch(`http://localhost:8080/professor/deleteExam/${examId}`, {
                credentials: "include",
                method: "DELETE"
            })
            const { statusCode, message } = await sendReq.json()
            if (statusCode == 200) {
                location.reload()
            }
            else if (statusCode == 401) {
                alert(message)
            }
        }
        else {
            alert("Error Deleting Try After SomeTime")
        }
    }
    async function editExam(examId: string) {
        console.log(examId)
    }
    async function changeStatus(examId: string) {
        setExamId(examId)
    }
    useEffect(() => {

    }, [examId])
    return (
        <>
            <ChangeExamStatus examId={examId} />
            <div className="container">
                <div className="container text-uppercase mt-3 d-flex justify-content-center">
                    <span className="dot mt-1" style={{ backgroundColor: "#d6f5dd" }}></span>Exam Stauts Show &nbsp;&nbsp;&nbsp;&nbsp; <br />
                    <div className="vr text-center ml-2 mr-4"></div>
                    <span className="dot mt-1" style={{ backgroundColor: "#f7d4d7" }}></span>Exam Status Hidden&nbsp;&nbsp;&nbsp;&nbsp;
                </div>

                {examData.map((ele: any, key: any) => (
                    <div className="container border border-dark p-3 mt-4" style={{ borderRadius: "20px", backgroundColor: ele.ExamStatus == "SHOW" ? "#d6f5dd" : "#f7d4d7" }} key={ele._id}>
                        <div className="row p-2">
                            <div className="col-md"> <strong>Exam Code : </strong>{ele.ExamCode}</div>
                            <div className="col-md"> <strong>Exam Duration : </strong>{ele.ExamDuration}</div>
                            <div className="col-md"><strong>Exam Passing Marks : </strong>{ele.ExamPassingMarks}</div>
                        </div>
                        <div className="row p-2">
                            <div className="col-md"><strong>Exam Name : </strong>{ele.ExamName}</div>
                            <div className="col-md"><strong>Exam Quetion : </strong>{ele.ExamQuestion}</div>
                            <div className="col-md"><strong>Exam Start Date : </strong>{new Date(ele.ExamStartDate).toLocaleDateString("en-us")}</div>
                        </div>
                        <div className="row p-2">
                            <div className="col-md"><strong>Subject Name : </strong>{ele.SubjectName.SubjectName}</div>
                            <div className="col-md"><strong>Exam Total Score : </strong>{ele.ExamTotalScore}</div>
                            <div className="col-md"><strong>Exam End Date : </strong>{new Date(ele.ExamEndDate).toLocaleDateString("en-us")}</div>
                        </div>
                        <div className="row p-2 mt-3">
                            <div className="col-md text-center"><button className="btn btn-sm btn-danger w-50 rounded p-2" onClick={() => deleteExam(ele._id)}>Delete Exam</button></div>
                            <div className="col-md text-center"><button className="btn btn-sm btn-warning w-50 rounded p-2" type="button" data-toggle="modal" data-target="#test-modal" onClick={() => changeStatus(ele._id)}>Change Exam Status</button></div>
                            {/* <div className="col-md text-center"><button className="btn btn-sm btn-success w-50 rounded p-2" onClick={() => editExam(ele._id)}>Edit Exam</button></div> */}
                        </div>
                    </div>
                ))}
            </div>
        </>
    )
}