import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import authUser from "../../utils/authUser"

export default function ViewProfessor() {
    const navigate = useNavigate()
    useEffect(() => {
        fetchData()
        userAuth()
    }, [])

    async function userAuth() {
        if (await authUser("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }
    const [professorData, setProfessorData] = useState([])
    async function fetchData() {
        const sendReq = await fetch("http://localhost:8080/admin/viewProfessor", {
            method: "GET",
            credentials: "include"
        })
        const { data, statusCode } = await sendReq.json()
        if (statusCode == 200) {
            setProfessorData(data)
        }
    }
    async function deleteProfessor(id: any) {
        if (!id) {
            alert("Unable To Find Professor EmailId")
        }
        const header = new Headers()
        header.append("Content-Type", "application/json")
        const obj = {
            ProfEmailId: id
        }
        const sendReq = await fetch("http://localhost:8080/admin/removeProfessor", {
            credentials: "include",
            headers: header,
            method: "DELETE",
            body: JSON.stringify(obj)
        })
        const { statusCode, message } = await sendReq.json()
        if (statusCode == 200) {
            alert(message)
            location.reload()
        }
    }
    return (
        <>
            <div className="container">
                <div className="container">
                    <p className="text-uppercase text-center mt-3" style={{ fontSize: "30px", letterSpacing: "3px", wordSpacing: "4px" }}>Professor Data</p>
                </div>
                <table className="table table-striped table-hover text-center">
                    <thead>
                        <tr>
                            <th>Professor Name</th>
                            <th>Professor Email-Id</th>
                            <th>Remove Professor</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            professorData.map((key: any, value: any) => (
                                <tr>
                                    <td>{key.ProfName}</td>
                                    <td>{key.ProfEmailId}</td>
                                    <td><button className="btn btn-outline-danger w-50" onClick={() => deleteProfessor(key.ProfEmailId)}>Fire</button></td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
        </>
    )
}