import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import validator from "validator"
import { ProfessorInterface } from "../../interfaces/professorInterface"
import Cookies from "js-cookie"
import authUser from "../../utils/authUser"
// import "src/assets/Css Files/professor.style.css"
export function ProfessorRegister({ professorForm, setProfessorForm }: any) {
    // Logic - useState - ApiCall

    const navigate = useNavigate()
    useEffect(() => {
        userAuth()
    }, [])
    async function userAuth() {
        if (await authUser("PROFESSOR")) {
            navigate("/unauthorizedUser")
        }
    }


    const [btnStatus, setBtnStatus] = useState(false)

    function togglePassword() {
        if ($("#profPass").attr("type") == "text") {
            $("#profPass").attr("type", "password")
        }
        else {
            $("#profPass").attr("type", "text")
        }
    }
    // Validation
    function registerForm(e: any) {
        $("span").hide()
        $("input:text").attr("class", "form-control")
        $("input:password").attr("class", "form-control")
        const { name, value } = e.target
        setProfessorForm({ ...professorForm, [name]: value })
    }
    async function registerValidation() {
        if (!$("#profName").val()) {
            $("#nameErr").show().text("Please Enter Your Name")
            $("#profName").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#profEmail").val()) {
            $("#emailErr").show().text("Please Enter Your EmailId")
            $("#profEmail").attr("class", "form-control border border-danger border-2")
            return
        }
        else if (!$("#profPass").val()) {
            $("#passErr").show().text("Please Enter Password")
            $("#profPass").attr("class", "form-control border border-danger border-2")
            return
        }
        else {
            const email: any = $("#profEmail").val()
            const pass: any = $("#profPass").val()
            if (!validator.isEmail(email)) {
                $("#emailErr").show().text("Incorrect EmailId")
                $("#profEmail").attr("class", "form-control border border-danger border-2")
                return
            }
            else if (!validator.isStrongPassword(pass)) {
                $("#passErr").show().text("Weak Password")
                $("#profPass").attr("class", "form-control border border-danger border-2")
                return
            }
        }
        setBtnStatus(true)
        const role: any = await sendRequest(professorForm)
        if (role) {
            alert("Registration Successfully")
            navigate("/")
        }
    }
    async function sendRequest(professorForm: ProfessorInterface) {
        const myheader = new Headers()
        myheader.append("Content-Type", "application/x-www-form-urlencoded")
        const urlencoded = new URLSearchParams();
        urlencoded.append("ProfName", professorForm.ProfName)
        urlencoded.append("ProfEmailId", professorForm.ProfEmailId)
        urlencoded.append("ProfPassword", professorForm.ProfPassword)

        const reqRes = await fetch("http://localhost:8080/admin/registerProf", {
            method: "POST",
            headers: myheader,
            body: urlencoded,
            credentials: "include"
        })
        const { statusCode, message, data }: any = await reqRes.json()
        console.log(message)
        if (statusCode == 409) {
            alert("Email Id Already Exist")
            setBtnStatus(false)
        }
        else if (statusCode == 500) {
            alert("Error Registering Try After SomeTime")
            setBtnStatus(false)
        }
        else if (statusCode == 422) {
            alert("All Fields Required")
            setBtnStatus(false)
        }
        else if (statusCode == 201) {
            console.log(data)
            return true
        }
    }
    return (
        <>
            <div className="profRegister">
                <div className="container">
                    <div>
                        <p className="display-5 text-center text-uppercase text-white mt-3" style={{ letterSpacing: "8px", wordSpacing: "5px" }}>Professor Register</p>
                    </div>

                    <div className="row mt-5 p-5 border border-white" style={{ borderRadius: "20px", boxShadow: "10px 10p 50px 10px" }}>

                        <div className="col-md-6">
                            <div>
                                <p className="text-white text-center text-uppercase" style={{ fontSize: "25px", letterSpacing: "9px" }}>Fill All details</p>
                            </div>
                            <div>
                                <form encType="multipart/form-data">
                                    <div className="form-group mt-5">
                                        <label htmlFor="profName" className="form-label text-white">Enter Professor Name</label>
                                        <input type="text" name="ProfName" id="profName" className="form-control" placeholder="DR. John Doe" onChange={(e) => registerForm(e)} />
                                        <span id="nameErr" style={{ color: "#dd3f4e", display: "none", letterSpacing: "2px" }}></span>
                                    </div>
                                    <div className="form-group mt-5">
                                        <label htmlFor="profEmail" className="form-label text-white">Enter Professor EmailId</label>
                                        <input type="text" name="ProfEmailId" id="profEmail" className="form-control" placeholder="johndoe@gmail.com" onChange={(e) => registerForm(e)} />
                                        <span id="emailErr" style={{ color: "#dd3f4e", display: "none", letterSpacing: "2px" }}></span>
                                    </div>
                                    <div className="form-group mt-5">
                                        <label htmlFor="profPass" className="form-label text-white">Enter Professor Password</label>
                                        <input type="password" name="ProfPassword" id="profPass" className="form-control" placeholder="*************" onChange={(e) => registerForm(e)} />
                                        <small className="text-white">Password Must contain 6 character, Symbol, Alphanumeric and uppercase letter</small><br />
                                        <span id="passErr" style={{ color: "#dd3f4e", display: "none", letterSpacing: "2px" }}></span>

                                    </div>
                                    <div className="form-group ml-5">
                                        <input type="checkbox" id="togglePassword" className="form-check-input hoverpointer" style={{ zoom: 2 }} onClick={() => togglePassword()} />

                                        <label htmlFor="togglePassword" className="text-white mt-2 hoverpointer" style={{ fontSize: "20px" }}>Show Password</label>

                                    </div>
                                </form>
                            </div>
                            <div className="container d-flex justify-content-center mt-5">
                                {
                                    btnStatus ?
                                        <button className="btn btn-primary w-75 text-uppercase p-2" style={{ letterSpacing: "8px" }} disabled>
                                            <span className="spinner-border spinner-border-sm mr-3"></span>
                                            <span>Registering... </span>
                                        </button>
                                        : <button className="btn btn-primary w-75 text-uppercase p-2" style={{ letterSpacing: "8px" }} onClick={() => registerValidation()}>Register</button>
                                }
                            </div>
                        </div>
                        <div className="col-1 text-center"><div className="vr" style={{ color: "white", boxShadow: "0px 0px 20px 1px", height: "500px", width: "2px", margin: "20px" }}></div></div>
                        <div className="col-md-5">
                            <img src="src/assets/Images/Sign up-bro.png" alt="" className="w-100 mt-4" />
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}