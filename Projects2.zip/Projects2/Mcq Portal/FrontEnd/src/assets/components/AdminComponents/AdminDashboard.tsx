import AdminHeader from "../Header&Footer/AdminHeader"

export default function AdminDashboard() {
    return (
        <>
            <AdminHeader />
            <h1>Welcome Admin</h1>
        </>
    )
}