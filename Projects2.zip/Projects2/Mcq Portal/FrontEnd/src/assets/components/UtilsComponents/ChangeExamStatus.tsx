import { useEffect, useState } from "react"

export default function ChangeExamStatus({ examId }: any) {
    const [curExamStatus, setCurExamStatus] = useState(false);

    async function getCurrentExamData() {
        const sendReq = await fetch(`http://localhost:8080/professor/getExam/${examId}`, {
            credentials: "include",
            method: "GET",
        })
        const { statusCode, message, data } = await sendReq.json()
        if (statusCode == 200) {
            console.log(data.ExamStatus)
            setCurExamStatus(data.ExamStatus === "HIDE" ? true : false);
        }
    }
    useEffect(() => {
        getCurrentExamData()
    }, [examId])

    async function changeStatus() {
        const sendReq = await fetch(`http://localhost:8080/professor/toggleExam/${examId}`, {
            credentials: "include",
            method: "PATCH"
        })
        console.log(await sendReq.json())
        location.reload()
    }

    return (
        <>
            <div className="modal fade" id="test-modal">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Change Exam Status</h5>
                        </div>
                        <div className="modal-body">
                            <div className="container">
                                <div className="form-group form-check form-switch d-flex ml-5">
                                    <label htmlFor="changeStatus" className="form-label" style={{ fontSize: "25px" }}>Hide</label>
                                    <input type="checkbox" id="changeStatus" className="form-check-input border border-dark mt-1" style={{ zoom: 1.5 }} checked={curExamStatus} onChange={() => setCurExamStatus(!curExamStatus)} />
                                </div>
                            </div>
                            <div>
                                <button className="btn btn-info btn-md float-right" onClick={() => changeStatus()} data-dismiss="modal">Change Status</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}