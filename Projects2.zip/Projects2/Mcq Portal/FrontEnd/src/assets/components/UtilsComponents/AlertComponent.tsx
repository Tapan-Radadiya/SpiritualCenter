export default function AlertComponent(data: string) {
    console.log(data)
    return (
        <>
            <div className="d-flex justify-content-center" >
                <div className="alert alert-danger alert-dismissible fade show w-25" id="alertBoxError" >
                    <strong className="ml-5" style={{ letterSpacing: "2px" }}>{data}</strong>
                    <button type="button" className="close" data-dismiss="alert" aria-label="close">
                        <label aria-hidden="true">&times;</label>
                    </button>
                </div>
            </div>
        </>
    )
}