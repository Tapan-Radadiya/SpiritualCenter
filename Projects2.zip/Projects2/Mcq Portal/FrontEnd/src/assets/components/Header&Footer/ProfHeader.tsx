import { useNavigate } from "react-router-dom"
import Cookies from "js-cookie"
export default function ProfHeader() {
    const navigate = useNavigate()
    function logoutUser() {
        Cookies.remove("data")
        navigate("/")
        location.reload()
    }
    return (
        <>
            <div className="header position">
                <div className="container-fluid bg-dark p-1" style={{ letterSpacing: "1px" }}>
                    <div className="row p-1 mt-3">
                        <div className="col-md-1 text-white"><p className="text-center" style={{ fontSize: "20px" }}>Exam Portal</p></div>
                        <div className="col-md-5 text-white"></div>
                        <div className="col-md text-white text-center">
                            <div className="dropdown">
                                <p className="text-center dropdown-toggle navbarIcons mr-2" id="dropDownData" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage Exams</p>
                                <div className="dropdown-menu mt-3 w-100 p-1 dropDownDiv" aria-labelledby="dropDownData">
                                    <a href="" className="dropdown-item dropItem" onClick={() => navigate("/professor/createExam")}>Create Exam</a>
                               
                                    <a href="" className="dropdown-item dropItem" onClick={() => navigate("/professor/viewExams")}>View Exam</a>
                                </div>
                            </div>
                        </div>
                        <div className="col-md text-white">
                            <p className="navbarIcons text-center" onClick={() => navigate("/professor/viewStudentData")}>Student Data</p>
                        </div>
                        <div className="col-md text-white">
                            <p className="navbarIcons text-center" onClick={() => navigate("/professor/addSubject")}>Add Subject</p>
                        </div>
                        <div className="col-md text-white">
                            <p className="navbarIcons text-center" onClick={() => navigate("/professor/questionData")}>Question Bank</p>
                        </div>
                        <div className="col-md text-white">
                            <p className="navbarIcons text-center" onClick={() => logoutUser()}>Logout</p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}