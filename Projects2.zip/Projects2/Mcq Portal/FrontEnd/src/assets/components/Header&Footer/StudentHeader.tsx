import { useNavigate } from "react-router-dom"
import Cookies from "js-cookie"

export default function StudentHeader() {
    const navigate = useNavigate()
    function logoutUser() {
        Cookies.remove("data")
        navigate("/")
        location.reload()
    }
    return (
        <>
            <div className="header position">
                <div className="container-fluid bg-dark p-1" style={{ letterSpacing: "1px" }}>
                    <div className="row p-1 mt-3">
                        <div className="col-md-1 text-white"><p className="text-center" style={{ fontSize: "20px" }}>Exam Nest</p></div>
                        <div className="col-md-5 text-white"></div>
                        <div className="col-md text-white">
                            <p className="navbarIcons text-center" onClick={() => navigate("/student/giveExam")}>Give Exam</p>
                        </div>
                        <div className="col-md text-white">
                            <p className="navbarIcons text-center" onClick={() => navigate("/student/viewResult")}>Previous Exam Result</p>
                        </div>
                        <div className="col-md text-white">
                            <p className="navbarIcons text-center" onClick={() => logoutUser()}>Logout</p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
