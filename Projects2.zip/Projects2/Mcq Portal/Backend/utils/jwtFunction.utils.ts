import jwt from 'jsonwebtoken'

const generateJwt = async (data: object) => {
    const jwtData = jwt.sign(data, `${process.env.JWT_PRIVATE_KEY}`)
    return jwtData
}
const checkExpiry =async (data:any) => {
    const checkTime = jwt.decode(data)
    console.log(checkTime);
    
}
const decodeJwt = async (text: any) => {
    return jwt.verify(text, `${process.env.JWT_PRIVATE_KEY}`)
}

export {
    generateJwt,
    decodeJwt,
    checkExpiry
}


// JWT data
//     Name:""
//     ROLE:""
