import bcrypt from "bcrypt"

async function encryptText(text: string) {
    const salt = await bcrypt.genSalt()
    return bcrypt.hash(text, salt)
}

async function compareText(encData: any, text: any) {
    return await bcrypt.compare(text, encData)
}

export {
    encryptText,
    compareText
}