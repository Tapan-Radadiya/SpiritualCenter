import express from 'express'
import cookieParser from 'cookie-parser'
import bodyParser from 'body-parser'
import studentRouter from "./routes/student.routes"
import profRouter from "./routes/professor.routes"
import adminRouter from "./routes/admin.routes"
import loginRouter from "./routes/login.routes"
import cors from "cors"
import "dotenv/config"

const app = express()
const corsOpt = {
    origin: process.env.CORS_ORIGIN,
    credentials: true
}
app.use(cors(corsOpt))
app.use(cookieParser())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use("/admin", adminRouter)
app.use("/student", studentRouter)
app.use("/professor", profRouter)
app.use("/login", loginRouter)
export default app