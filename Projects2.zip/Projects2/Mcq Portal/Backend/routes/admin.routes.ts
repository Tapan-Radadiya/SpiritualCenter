import express from 'express'
import {
    registerAdmin,
    registerProfessor,
    viewProfessor,
    deleteProfessor
} from "../controller/admin.controller"
import verifyUser from "../middleware/authincatication.middleware"
import authorizeUser from "../middleware/authorization.middleware"


const router = express.Router()
router.route("/registerAdmin").post(registerAdmin)
router.route("/registerProf").post(verifyUser, authorizeUser, registerProfessor)
router.route("/viewProfessor").get(verifyUser, authorizeUser, viewProfessor)
router.route("/removeProfessor").delete(verifyUser, authorizeUser, deleteProfessor)
export default router