import express from 'express'
import { loginUser } from "../controller/login.controller"
const router = express.Router()

router.route("").post(loginUser)
export default router