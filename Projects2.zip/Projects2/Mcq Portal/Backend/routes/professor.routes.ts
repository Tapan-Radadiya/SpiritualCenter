import express from 'express'
import {

    createExam,
    editExam,
    toggleExam,
    getExamStatus,
    displayExam,
    deleteExam,
    previousExamData,
    getQuestionBankData,
    updateQuestion,
    getStudentName
} from "../controller/professor.controller"
import {
    addSubject,
    addMcq,
    getSubject,
    getSubjectQuestion
} from "../controller/subject.controller"
import verifyUser from "../middleware/authincatication.middleware"
import authorizeUser from "../middleware/authorization.middleware"
const router = express.Router()


router.route("/createExam").post(verifyUser, authorizeUser, createExam)
router.route("/editExam/:examCode").put(verifyUser, authorizeUser, editExam)
router.route("/deleteExam/:examId").delete(verifyUser, authorizeUser, deleteExam)
router.route("/getExams").get(verifyUser, authorizeUser, displayExam)
router.route("/toggleExam/:examId").patch(verifyUser, authorizeUser, toggleExam)
router.route("/getExam/:examId").get(verifyUser, authorizeUser, getExamStatus)
router.route("/studentExamData").get(verifyUser, authorizeUser, previousExamData)
router.route("/getQuestionData/:limit/:pageNumber").post(verifyUser, authorizeUser, getQuestionBankData)
router.route("/updateQuesion/:SubjectName").post(verifyUser, authorizeUser, updateQuestion)
router.route("/studentName").get(verifyUser, authorizeUser, getStudentName)
// MCQ Routes
router.route("/createSub").post(verifyUser, authorizeUser, addSubject)
router.route("/addMcq/:subName").post(verifyUser, authorizeUser, addMcq)
router.route("/getSubject").get(getSubject)
router.route("/getSubjectQuestions").get(verifyUser, authorizeUser, getSubjectQuestion)
// router.route("/getSubject").get(verifyUser,authorizeUser,getSubject)
export default router