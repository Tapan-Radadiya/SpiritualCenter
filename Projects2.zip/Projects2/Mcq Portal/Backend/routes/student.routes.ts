import express from 'express'
import {
    registerStudent,
    giveExam,
    submitExam,
    getYourExamDetails
} from "../controller/student.controller"
import verifyUser from "../middleware/authincatication.middleware"
import authorizeUser from "../middleware/authorization.middleware"
const router = express.Router()


router.route("/registerStudent").post(registerStudent)
router.route("/giveExam/:examCode").get(verifyUser, authorizeUser, giveExam)
router.route("/submitExam").post(verifyUser, authorizeUser, submitExam)
router.route("/getExamDetails").get(verifyUser,authorizeUser,getYourExamDetails)
export default router