import { ObjectId } from "mongoose";

export interface ScoreInterface{
    ExamCode:ObjectId
    StudentUserName:String
    StudentScore:String,
    Result:String
}