import { ObjectId } from "mongoose";

export interface ResultInterface {
    ExamId: ObjectId
    ScoringId: ObjectId
    Result: String
}