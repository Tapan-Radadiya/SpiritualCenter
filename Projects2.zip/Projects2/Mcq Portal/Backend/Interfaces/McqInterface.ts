export interface MCQInterface {
    Question: String
    OptionA: String
    OptionB: String
    OptionC: String
    OptionD: String,
    Answers: String[]
}