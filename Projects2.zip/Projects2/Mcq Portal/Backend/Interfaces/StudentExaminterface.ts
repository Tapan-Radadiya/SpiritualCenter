import { ObjectId } from "mongoose"

export interface StudentExamInterface {
    StudentUserName: String
    ExamName: String,
    SubjectName: String,
    ExamQuestion: Number,
    ExamTotalScore: Number,
    AchievedScore: Number,
    ExamResult: String
}