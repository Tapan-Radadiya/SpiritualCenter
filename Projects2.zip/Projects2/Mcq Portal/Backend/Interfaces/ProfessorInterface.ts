export interface AdminInterface {
    ProfName: String
    ProfEmailId: String
    ProfPassword: String
}