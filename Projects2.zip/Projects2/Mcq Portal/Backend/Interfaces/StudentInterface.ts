export interface StudentInterface {
    StudentName: String
    StudentEmailId: String
    StudentUserName: String
    StudentPassword: String
    AppearedForExam:String
}
