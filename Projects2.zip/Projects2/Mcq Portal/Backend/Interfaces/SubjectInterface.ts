export interface SubjectInterface {
    SubjectName: String,
    SubjectMcqFile:String
}