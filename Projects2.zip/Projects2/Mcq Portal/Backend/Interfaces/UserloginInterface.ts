import { ObjectId } from "mongoose";

export interface userLogin {
    UserId: String,
    UserPassword: String,
    UserRole: String,
    UserData: ObjectId
}