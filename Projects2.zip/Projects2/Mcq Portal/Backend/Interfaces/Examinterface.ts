import { ObjectId } from "mongoose"

export interface ExamInterface {
    ExamCode: String
    ExamName: String
    SubjectName: ObjectId
    ExamDuration: Number
    ExamQuestion: Number
    ExamTotalScore: Number
    ExamPassingMarks: Number
    ExamStartDate: Date
    ExamEndDate: Date
    ExamStatus: String
    ModifiedBy: String
    CreatedBy: String
}