import mongoose from "mongoose";
import { AdminInterface } from "../Interfaces/ProfessorInterface"
import validator from "validator";

const ProfessorSchema = new mongoose.Schema<AdminInterface>({
    ProfName: {
        type: String,
        required: true,
        minlength: [3, "Name Should Contain Atlease 3 Character"]
    },
    ProfEmailId: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        lowercase: true,
        validate: [validator.isEmail, "Incorrect Email Id"]
    },
    ProfPassword: {
        type: String,
        required: true,
        trim: true,
        validate: [validator.isStrongPassword, "Password Is Very Week"]
    }
}, { timestamps: true })

export const Professor = mongoose.model("Professor", ProfessorSchema)