import mongoose from "mongoose";
import validator from "validator";

const AdminSchema = new mongoose.Schema({
    AdminName: {
        type: String,
        required: true
    },
    AdminEmailId: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowerCase: true,
        validate: [validator.isEmail, "Incorrect EmailId"]
    },
    AdminPassword: {
        type: String,
        trim: true,
        minLength: [6, "Password Must Contain Atleast 6 Character"],
        validate: [validator.isStrongPassword, "Password Is Weak"]
    }
}, { timestamps: true })

export const Admin = mongoose.model("Admin", AdminSchema)