import mongoose from "mongoose";
import { ResultInterface } from "../Interfaces/ResultInterface"

const ResultSchema = new mongoose.Schema<ResultInterface>({
    ExamId: {
        type: mongoose.Types.ObjectId,
        ref: "Exam"
    },
    ScoringId: {
        type: mongoose.Types.ObjectId,
        ref: "Score"
    },
  
}, { timestamps: true })

export const Result = mongoose.model("Result",ResultSchema)