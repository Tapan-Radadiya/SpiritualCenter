import mongoose from "mongoose";
import { SubjectInterface } from "../Interfaces/SubjectInterface"
import validator from "validator";

const SubjectSchema = new mongoose.Schema<SubjectInterface>({
    SubjectName: {
        type: String,
        required: true,
        unique: true
    },
    SubjectMcqFile: {
        type: String,
        required: true
    }
}, { timestamps: true })

export const Subject = mongoose.model("Subject", SubjectSchema)