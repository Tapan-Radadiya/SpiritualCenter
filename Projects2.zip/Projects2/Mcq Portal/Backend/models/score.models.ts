import mongoose from "mongoose";
import { ScoreInterface } from "../Interfaces/ScoreInterface"
import validator from "validator";

const ScoreSchema = new mongoose.Schema<ScoreInterface>({
    StudentUserName: {
        type: String,
        ref: "Student"
    },
    ExamCode: {
        type: mongoose.Types.ObjectId,
        ref: "Exam"
    },
    StudentScore: {
        type: Number,
        required: true,
        validate: [validator.isNumeric, "Student Score Should Be In Number"]
    },
    Result: {
        type: String,
        enum: {
            values: ["PASS", "FAIL"],
            message: "Invalid Value"
        }
    }
}, { timestamps: true })

export const Score = mongoose.model("Score",ScoreSchema)