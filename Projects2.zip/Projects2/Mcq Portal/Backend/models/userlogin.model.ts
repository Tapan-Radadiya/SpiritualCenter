import mongoose from "mongoose";
import { userLogin } from "../Interfaces/UserloginInterface";
import validator from "validator";

const UserSchema = new mongoose.Schema<userLogin>({
    UserId: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    UserPassword: {
        type: String,
        required: true,
        validate: [validator.isStrongPassword, "Please Provide String Password"]
    },
    UserRole: {
        type: String,
        enum: {
            values: ["ADMIN", "STUDENT", "PROFESSOR"],
            message: "Invalid Value For Enum"
        }
    },
    UserData: {
        type: mongoose.Types.ObjectId,
        required: true
    }
})

export const UserLogin = mongoose.model("UserLogin", UserSchema)