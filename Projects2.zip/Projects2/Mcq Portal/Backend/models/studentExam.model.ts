import mongoose from "mongoose";
import { StudentExamInterface } from "../Interfaces/StudentExaminterface"

const StudentExamSchema = new mongoose.Schema<StudentExamInterface>({
    StudentUserName: {
        type: String,
        ref: "Student"
    },
    ExamName: {
        type: String,
        required: true
    },
    ExamQuestion: {
        type: Number,
        required: true
    },
    SubjectName: {
        type: String,
        required: true
    },
    ExamTotalScore: {
        type: Number,
        required: true
    },
    AchievedScore: {
        type: Number,
        required: true
    },
    ExamResult: {
        type: String,
        enum: {
            values: ["PASS", "FAIL"],
            message: "Invalid Enum Value"
        }
    }
}, { timestamps: true })

export const StudentExam = mongoose.model("StudentExam", StudentExamSchema)