import mongoose from "mongoose";
import { StudentInterface } from "../Interfaces/StudentInterface";
import validator from "validator";
const StudentSchema = new mongoose.Schema<StudentInterface>({
    StudentName: {
        type: String,
        required: true,
        minlength: [3, "Name Should Contain Atleast 3 Character"]
    },
    StudentUserName: {
        type: String,
        required: true,
        unique: true,
        minlength: [6, "UserName Should Contain Atleast 6 Character"],
        uppercase: true
    },
    StudentEmailId: {
        type: String,
        required: true,
        unique: true,
        validate: [validator.isEmail, "Incorrect Email Id"]
    },
    StudentPassword: {
        type: String,
        required: true,
        validate: [validator.isStrongPassword, "Password Should Be Strong"],
        minlength: [6, "Password Length MustBe 6 Character Long"]
    },
    AppearedForExam: [
        {
            type: mongoose.Types.ObjectId,
            ref: "StudentExam"
        }
    ]
}, { timestamps: true })

export const Student = mongoose.model("Student", StudentSchema)