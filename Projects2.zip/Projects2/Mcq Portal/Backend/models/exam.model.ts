import mongoose from "mongoose";
import validator from "validator";
import { ExamInterface } from "../Interfaces/Examinterface";

const ExamSchema = new mongoose.Schema<ExamInterface>({
    ExamCode: {
        type: String,
        required: true,
        unique: true,
        minLength: [6, "Exam Code Should Container Atleast 6 Character"]
    },
    ExamName: {
        type: String,
        required: true,
        minLength: [3, "Exam Name Should Contain Atleast 3 Character"]
    },
    SubjectName: {
        type: mongoose.Types.ObjectId,
        required: true,
        ref:"Subject"
    },
    ExamDuration: {
        type: Number,
        required: true,
        min: [5, "Exam Duration Should Be Greter Then 5 Minutes"],
    },
    ExamQuestion: {
        type: Number,
        required: true
    },
    ExamTotalScore: {
        type: Number,
        required: true,
        min: [10, "Exam Score Should Be Greter Then 10"],
    },
    ExamPassingMarks: {
        type: Number,
        required: true
    },
    ExamStartDate: {
        type: Date,
        required: true,
        validate: {
            validator: (e: Date) => {
                return new Date(e).toLocaleDateString("en-us") >= new Date().toLocaleDateString("en-us")
            },
            message: "Exam Start Date Should Be Greater Or Equal To Today's Date"
        }
    },
    ExamEndDate: {
        type: Date,
        required: true,
        validate: {
            validator: (e: Date) => {
                return new Date(e).toLocaleDateString("en-us") >= new Date().toLocaleDateString("en-us")
            },
            message: "Exam End Date Should Be Greater Or Equal To Exam Start Date"
        }
    },
    ExamStatus: {
        type: String,
        enum: {
            values: ["SHOW", "HIDE"],
            default: "SHOW",
            message: "Invalid Option"
        }
    },
    CreatedBy: {
        type: String,
        required: true
    },
    ModifiedBy: {
        type: String,
        default: function () {
            return this.CreatedBy
        }
    },
}, { timestamps: true })

export const Exam = mongoose.model("Exam", ExamSchema)