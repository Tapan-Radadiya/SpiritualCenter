import 'dotenv/config'
import app from "./app"
import connectDb from "./config/dbConnect.config"
const PORT = process.env.PORT || 3001

connectDb()
    .then(() => {
        app.listen(PORT, () => {
            console.log(`Server Listening On Port Number : ${PORT}`);
        })
    })
    .catch((err) => {
        console.log(`Error Connecting With Db ${err}`);
    })
