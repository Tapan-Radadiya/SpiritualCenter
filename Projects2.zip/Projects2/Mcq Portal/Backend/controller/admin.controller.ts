import { Request, Response, response } from "express"
import { Professor } from "../models/professor.model"
import { ApiResult } from "../utils/ApiResult.utils"
import { compareText, encryptText } from "../utils/bcryptFunction.utils"
import { Admin } from "../models/admin.model"
import { generateJwt } from "../utils/jwtFunction.utils"
import { UserLogin } from "../models/userlogin.model"

const registerAdmin = async (req: Request, res: Response) => {
    const {
        AdminName,
        AdminEmailId,
        AdminPassword
    } = req.body

    if (!AdminName ||
        !AdminEmailId ||
        !AdminPassword) { return res.status(409).send(ApiResult(409, "All Fields Required")) }

    try {
        const findAdmin = await Admin.findOne({ AdminEmailId: AdminEmailId })
        if (findAdmin) { return res.status(409).send(ApiResult(409, "This Admin Is Already Registered")) }
        const createAdmin = await Admin.create({
            AdminName,
            AdminEmailId,
            AdminPassword: await encryptText(AdminPassword)
        })
        if (!createAdmin) { return res.status(500).send(ApiResult(500, "Error Creating Admin Try After SomeTime")) }
        else {

            const addLoginData = await UserLogin.create({
                UserId: createAdmin.AdminEmailId,
                UserPassword: createAdmin.AdminPassword,
                UserData: createAdmin._id,
                UserRole: "ADMIN"
            })
            if (addLoginData) { return res.status(201).send(ApiResult(201, "Admin Created Please Login")) }
            else {
                return res.status(500).send(ApiResult(500, "Error Creating Admin Try After SomeTime"))
            }
        }
    } catch (error) {
        res.send(`Error In RegisterAdmin ${error}`)
    }
}

const registerProfessor = async (req: Request, res: Response) => {
    const {
        ProfName,
        ProfEmailId,
        ProfPassword,
    } = req.body
    if (!ProfName ||
        !ProfEmailId ||
        !ProfPassword) {
        res.status(422).send(ApiResult(422, "All Fields Required"))
    }
    try {
        const checkProf = await Professor.findOne({ ProfEmailId: ProfEmailId })
        if (checkProf) {
            return res.status(409).send(ApiResult(409, "Professor Email Id Already Exist"))
        }

        const createProf = await Professor.create({
            ProfName,
            ProfEmailId,
            ProfPassword: await encryptText(ProfPassword)
        })
        if (!createProf) return res.status(500).send(ApiResult(500, "Error Registering Professor Try After Sometime"))
        else {
            const addLoginData = await UserLogin.create({
                UserId: createProf.ProfEmailId,
                UserPassword: createProf.ProfPassword,
                UserData: createProf._id,
                UserRole: "PROFESSOR"
            })
            if (addLoginData) {
                return res.status(201).send(ApiResult(201, "Professor Created Successfully"))
            }
            else {
                return res.status(500).send(ApiResult(500, "Error Registering Professor Try After Sometime"))
            }
        }
    } catch (error) {
        return res.send(`Error In Register Professor ${error}`)
    }
}

const viewProfessor = async (req: Request, res: Response) => {
    try {
        const getProfessor = await Professor.find().select("ProfName ProfEmailId")
        if (!getProfessor) return res.status(409).send(ApiResult(409, "Error Fetching Data"))
        return res.status(200).send(ApiResult(200, "Data Fetched", getProfessor))
    } catch (error) {
        return res.send("Error Fetching Professor Data")
    }
}

const deleteProfessor = async (req: Request, res: Response) => {
    const { ProfEmailId } = req.body
    if (!ProfEmailId) {
        return res.status(409).send(ApiResult(409, "Please Provide Professor Email Id"))
    }
    try {
        const removeProfessor = await Professor.findOneAndDelete({ ProfEmailId: ProfEmailId })
        if (!removeProfessor) return res.status(404).send(ApiResult(404, "No Professor Found With This Email Id"))
        const removeLoginDetails = await UserLogin.findOneAndDelete({ UserId: ProfEmailId })
        if (!removeLoginDetails) return res.status(404).send(ApiResult(404, "No Professor Found With This Email Id"))
        return res.status(200).send(ApiResult(200, "Professor Deleted Successfully"))
    } catch (error) {
        return res.send("Error In Delete Professor")
    }
}
export {

    registerAdmin,
    registerProfessor,
    viewProfessor,
    deleteProfessor
}