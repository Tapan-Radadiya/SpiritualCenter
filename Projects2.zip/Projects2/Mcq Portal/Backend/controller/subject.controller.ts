import { Subject } from "../models/subject.model"
import { Request, Response } from "express"
import { ApiResult } from "../utils/ApiResult.utils"
import { MCQInterface } from "../Interfaces/McqInterface"
import fs from 'fs'

type subjectDataType = {
    SubjectName: String,
    TotalQuestions: Number
}
// counts Total MCQ in each SUbject
async function countMcqWithSubject(getSubjectData: any) {
    const subjectdata: subjectDataType[] = []
    getSubjectData.forEach(async (ele: any) => {
        const data = await JSON.parse(fs.readFileSync(ele.SubjectMcqFile, 'utf-8'))
        subjectdata.push({ SubjectName: ele.SubjectName, TotalQuestions: data.length })
    })
    return subjectdata
}

const addSubject = async (req: Request, res: Response) => {
    const { SubjectName } = req.body

    if (!SubjectName) return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "All Fields Required"))
    const defaultTemplate = {
        "Question": "",
        "OptionA": "",
        "OptionB": "",
        "OptionC": "",
        "OptionD": "",
        "Answers": [
            "OptionA"
        ]
    }
    try {
        const checkSub = await Subject.findOne({ SubjectName: SubjectName })
        if (checkSub) return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "Subject Already Exist"))
        fs.writeFileSync(`ExamFiles/${SubjectName}.json`,`[${JSON.stringify(defaultTemplate)}]`)
        const createSubject = await Subject.create({
            SubjectName,
            SubjectMcqFile: `ExamFiles/${SubjectName}.json`
        })
        if (createSubject) {
            return res.header("Access-Control-Allow-Credentials", "true").status(201).send(ApiResult(201, "Subject Created"))
        }
        else {
            return res.header("Access-Control-Allow-Credentials", "true").status(500).send(ApiResult(500, "Error Creating Subject Try AFter SomeTime"))
        }
    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").send(`Error In Add Subject ${error}`)
    }
}

const getSubject = async (req: Request, res: Response) => {
    try {
        const subjectList: any = await Subject.find().select("SubjectName")
        if (!subjectList) {
            return res.header("Access-Control-Allow-Credentials", "true").status(500).send(ApiResult(500, "Error Fetching Data TryAfter SomeTime"))
        }
        const subjectData: any = []
        subjectList.forEach((element: any) => {
            subjectData.push(element.SubjectName)
        })
        return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "-", { subjectData }))
    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").send(`Error In get Subject ${error}`)
    }
}
const addMcq = async (req: Request, res: Response) => {
    const { subName } = req.params
    const { Question,
        OptionA,
        OptionB,
        OptionC,
        OptionD,
        Answers } = req.body
    if (!Question ||
        !OptionA ||
        !OptionB ||
        !OptionC ||
        !OptionD ||
        !Answers) {
        return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "All Fields Required"))
    }
    const checkSubject = await Subject.findOne({ SubjectName: subName })
    if (!checkSubject) { return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, "No Subject Found With This Name")) }

    try {
        const mcqData = await JSON.parse(fs.readFileSync(`${checkSubject.SubjectMcqFile}`, "utf-8"))
        const newMcq: MCQInterface = {
            Question,
            OptionA,
            OptionB,
            OptionC,
            OptionD,
            Answers,
        }
        mcqData.push(newMcq)
        fs.writeFileSync(`${checkSubject.SubjectMcqFile}`, JSON.stringify(mcqData))
        return res.header("Access-Control-Allow-Credentials", "true").status(201).send(ApiResult(201, "Mcq Added Successfully"))
    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "Error Adding Data Please Delete And Recreate Exam"))
    }
}

const getSubjectQuestion = async (req: Request, res: Response) => {

    try {

        const getSubjectData = await Subject.find({})
        const subjectdata = await countMcqWithSubject(getSubjectData)
        return res.status(200).send(ApiResult(200, "Data Fetched", subjectdata))
    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").status(500).send(error)
    }
}
export { addSubject, addMcq, getSubject, getSubjectQuestion }