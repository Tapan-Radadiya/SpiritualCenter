import { Request, Response } from "express"
import { ApiResult } from "../utils/ApiResult.utils"
import { Student } from "../models/student.model"
import { StudentExam } from "../models/studentExam.model"
import { compareText, encryptText } from "../utils/bcryptFunction.utils"
import { generateJwt } from "../utils/jwtFunction.utils"
import { UserLogin } from "../models/userlogin.model"
import { Exam } from "../models/exam.model"
import { StudentExamInterface } from "../Interfaces/StudentExaminterface"
import fs from 'fs'
const registerStudent = async (req: Request, res: Response) => {
    const {
        StudentName,
        StudentUserName,
        StudentEmailId,
        StudentPassword,
    } = req.body
    if (!StudentName ||
        !StudentUserName ||
        !StudentEmailId ||
        !StudentPassword) {
        return res.status(422).send(ApiResult(409, "All Fields Required"))
    }

    try {
        const checkUserExist = await Student.findOne({
            $or: [{ StudentUserName: StudentUserName }, { StudentEmailId: StudentEmailId }]
        })
        if (checkUserExist) {
            return res.status(409).send(ApiResult(409, "UserName Or Email Already Exist"))
        }
        const createStudent = await Student.create({
            StudentName,
            StudentUserName,
            StudentEmailId,
            StudentPassword: await encryptText(StudentPassword)
        })

        if (createStudent) {
            const addLoginData = await UserLogin.create({
                UserId: createStudent.StudentUserName,
                UserPassword: createStudent.StudentPassword,
                UserRole: "STUDENT",
                UserData: createStudent._id
            })
            if (addLoginData) {
                return res.status(201).send(ApiResult(201, "Student Register Successfully Please Login"))
            }
            else { return res.status(500).send(ApiResult(500, "Error While Registering Try After SomeTime")) }
        }
        else {
            return res.status(500).send(ApiResult(500, "Error While Registering Try After SomeTime"))
        }
    } catch (error) {
        res.send(`Error In RegisterStudent ${error}`)
    }
}

const giveExam = async (req: Request, res: Response) => {
    const { examCode } = req.params
    if (!examCode) return res.status(409).send(ApiResult(409, "Please Provide ExamCode"))

    try {
        const findExam: any = await Exam.findOne({ ExamCode: examCode }).populate("SubjectName")

        if (!findExam) return res.status(404).send(ApiResult(404, "Invalid Exam Code"))

        // ExamStatus 
        if (findExam.ExamStatus == "HIDE") {
            return res.status(409).send(ApiResult(409, "Exam Is Not Started Yet - Exam Status Is Hide"))
        }

        // Exam Start Date
        if (new Date().toLocaleDateString("en-us") < new Date(findExam.ExamStartDate).toLocaleDateString("en-us")) {
            return res.status(409).send(ApiResult(409, `Exam Is Scheduled For Date  : ${new Date(findExam.ExamStartDate).toLocaleDateString("en-us")} (MM/DD/YYYY) `))
        }

        // Exam End Date 
        if (new Date().toLocaleDateString("en-us") > new Date(findExam.ExamEndDate).toLocaleDateString("en-us")) {
            return res.status(409).send(ApiResult(409, `You Can't Give Exam Now Exam Is Over On ${new Date(findExam.ExamEndDate).toLocaleDateString("en-us")}(MM/DD/YYYY)`))
        }
        const file = findExam.SubjectName.SubjectMcqFile
        const mcqdata = await JSON.parse(fs.readFileSync(file, 'utf-8'))
        const totalExamQ = findExam.ExamQuestion

        let randomMcqIndex: any = []
        let randomMcq: any = []
        for (let i = 0; i < totalExamQ; i++) {
            const randNmr = Math.floor(Math.random() * ((mcqdata.length - 0) + 1))
            if (randomMcqIndex.includes(randNmr) || randNmr == mcqdata.length) {
                i--
                continue
            }
            randomMcqIndex.push(randNmr)
            randomMcq.push(mcqdata[randNmr])
        }
        return res.status(200).send(ApiResult(200, "Start Your Exam", { ExamData: findExam, McqData: randomMcq }))
    } catch (error) {
        res.send(`Error IN Give Exam ${error}`)
    }
}

const getYourExamDetails = async (req: Request, res: Response) => {
    const { Name }: any = req.headers
    try {
        const getData = await StudentExam.find({ StudentUserName: Name }).sort({ createdAt: -1 })
        if (getData) {
            return res.status(200).send(ApiResult(200, "Data Fetched", getData))
        }
        else {
            return res.status(500).send(ApiResult(500, "Error Fetching Exam Data Try After SomeTime"))
        }
    } catch (error) {
        res.send(`Error In Get ExamDetails ${error}`)
    }
}

const submitExam = async (req: Request, res: Response) => {
    const { ExamCode, AchievedScore } = req.body
    const { Name }: any = req.headers
    let examresult = "PASS"
    if (!ExamCode || !(AchievedScore >= 0)) {
        return res.status(409).send(ApiResult(409, "Please Provide AchievedScore"))
    }
    try {
        const examData: any = await Exam.findOne({ ExamCode }).populate("SubjectName")
        if (AchievedScore < examData.ExamPassingMarks) { examresult = "FAIL" }
        // Count Marks From 100%
        const queWeight = examData.ExamTotalScore / examData.ExamQuestion
        const totalScore = ((queWeight * AchievedScore) / examData.ExamTotalScore * 100)
        const data: StudentExamInterface = {
            StudentUserName: Name,
            ExamName: examData.ExamName,
            SubjectName: examData.SubjectName.SubjectName,
            ExamQuestion: examData.ExamQuestion,
            ExamTotalScore: examData.ExamTotalScore,
            AchievedScore: totalScore,
            ExamResult: examresult
        }
        const storeData = await StudentExam.create(data)
        if (!storeData) { return res.status(409).send(ApiResult(409, "Error Submitting Data")) }
        else {
            return res.status(200).send(ApiResult(200, "Exam Submited Thank You For Appering In Exam"))
        }
    } catch (error) {
        res.send(`Error In Submit Exam ${error}`)
    }
}
export {
    registerStudent,
    giveExam,
    submitExam,
    getYourExamDetails
}

// Server Side Pagination