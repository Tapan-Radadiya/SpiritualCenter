import { Request, Response } from "express"
import { Professor } from "../models/professor.model"
import { ApiResult } from "../utils/ApiResult.utils"
import { compareText } from "../utils/bcryptFunction.utils"
import { Exam } from "../models/exam.model"
import fs from 'fs'
import { Subject } from "../models/subject.model"
import { StudentExam } from "../models/studentExam.model"
import mongoose from "mongoose"
import { Student } from "../models/student.model"

const createExam = async (req: Request, res: Response) => {
    const {
        ExamCode,
        ExamName,
        SubjectName,
        ExamDuration,
        ExamTotalScore,
        ExamQuestion,
        ExamPassingMarks,
        ExamStartDate,
        ExamEndDate,
        ExamStatus
    } = req.body

    if (!ExamCode ||
        !ExamName ||
        !SubjectName ||
        !ExamDuration ||
        !ExamQuestion ||
        !ExamTotalScore ||
        !ExamPassingMarks ||
        !ExamStartDate ||
        !ExamEndDate ||
        !ExamStatus) {
        return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "All Fields Required"))
    }
    try {
        const checkExamCode = await Exam.findOne({ ExamCode: ExamCode })
        if (checkExamCode) {
            return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "ExamCode ALready In Use"))
        }
        const findSubject: any = await Subject.findOne({ SubjectName: SubjectName })
        if (!findSubject) {
            return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, "No Subject Found"))
        }
        const mcqData = await JSON.parse(fs.readFileSync(findSubject.SubjectMcqFile, 'utf-8'))
        if (mcqData.length < ExamQuestion) {
            return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "You Don't Have Enough MCQ In Your Question Bank For This Subject"))
        }
        if (new Date(ExamEndDate).toLocaleDateString("en-us") <= new Date(ExamStartDate).toLocaleDateString("en-us")) {
            return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "Exam Start Date Should Be Lesser Then Exam End Date"))
        }
        const createExam = await Exam.create({
            ExamCode,
            ExamName,
            SubjectName: findSubject._id,
            ExamDuration,
            ExamQuestion,
            ExamTotalScore,
            ExamPassingMarks,
            ExamStartDate,
            ExamEndDate,
            ExamStatus,
            CreatedBy: req.headers.Name,
        })

        if (!createExam) { return res.header("Access-Control-Allow-Credentials", "true").status(500).send(ApiResult(500, "Error Creating Exam Try After SomeTime")) }
        else {
            return res.header("Access-Control-Allow-Credentials", "true").status(201).send(ApiResult(201, "Exam Created", createExam))
        }
    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").send(`Error IN Create Exam ${error}`)
    }
}

const deleteExam = async (req: Request, res: Response) => {
    const { examId } = req.params
    const { Name } = req.headers

    const findExam = await Exam.findOne({ _id: new mongoose.Types.ObjectId(examId) })

    if (!findExam) return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, "No Exam Found With This Email Id"))

    if (findExam.CreatedBy != Name) {
        return res.header("Access-Control-Allow-Credentials", "true").status(401).send(ApiResult(401, "Only Author Of Exam Can Delete Exam"))
    }

    try {
        const removeExam = await Exam.findByIdAndDelete(findExam._id)
        if (!removeExam) return res.header("Access-Control-Allow-Credentials", "true").status(500).send(ApiResult(500, "Error Deleting Exam Try After SomeTime"))
        return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Exam Deleted Successfully"))
    } catch (error) {
        return res.header("Access-Control-Allow-Credentials", "true").send(`Error in delete exam - ${error}`)
    }
}

const editExam = async (req: Request, res: Response) => {
    const { examCode } = req.params
    const { Name } = req.headers
    const {
        ExamName,
        ExamSubject,
        ExamDuration,
        ExamTotalScore,
        ExamPassingMarks,
        ExamStartDate,
        ExamEndDate,
    } = req.body

    if (!ExamName ||
        !ExamSubject ||
        !ExamDuration ||
        !ExamTotalScore ||
        !ExamPassingMarks ||
        !ExamStartDate ||
        !ExamEndDate) {
        return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "All Fields Required"))
    }
    if (new Date(ExamEndDate).toLocaleDateString("en-us") <= new Date(ExamStartDate).toLocaleDateString("en-us")) {
        return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "Exam Start Date Should Be Lesser Then Exam End Date"))
    }
    try {
        const updateExam = await Exam.findOneAndUpdate({ ExamCode: examCode }, {
            ExamName,
            ExamSubject,
            ExamDuration,
            ExamTotalScore,
            ExamPassingMarks,
            ExamStartDate,
            ExamEndDate,
            ModifiedBy: Name
        })
        if (updateExam) return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Exam Update", updateExam))
        else {
            return res.header("Access-Control-Allow-Credentials", "true").status(500).send(ApiResult(500, "Error Updating Exam Try After SomeTime"))
        }
    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").send(`Error In Edit Exam ${error}`)
    }
}

const toggleExam = async (req: Request, res: Response) => {
    const { examId } = req.params
    const { Name } = req.headers
    try {
        const changeStatus: any = await Exam.findOne({ _id: new mongoose.Types.ObjectId(examId) })
        if (changeStatus.ExamStatus == "SHOW") {
            const updateExam = await Exam.findByIdAndUpdate(changeStatus._id, { ExamStatus: "HIDE", ModifiedBy: Name })
            if (updateExam) return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Exam Status Changed To Hide"))
        }
        else if (changeStatus.ExamStatus == "HIDE") {
            const updateExam = await Exam.findByIdAndUpdate(changeStatus._id, { ExamStatus: "SHOW", ModifiedBy: Name })
            if (updateExam) return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Exam Status Changed To SHOW"))
        }
    } catch (error) {
        return res.header("Access-Control-Allow-Credentials", "true").send(ApiResult(500, `Error In Toggle exam ${error} `))
    }
}

const getExamStatus = async (req: Request, res: Response) => {
    const { examId } = req.params
    if (!examId) {
        return res.header("Access-Control-Allow-Credentials", "true").status(422).send(ApiResult(422, "ExamCode Required"))
    }
    try {
        const getExam = await Exam.findById({ _id: new mongoose.Types.ObjectId(examId) })
        if (!getExam) {
            return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, "No Exam Found"))
        }
        else {
            return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Data Fetched", getExam))
        }
    } catch (error) {
        return res.header("Access-Control-Allow-Credentials", "true").send(ApiResult(500, `Error In Get ExamStatus ${error}`))
    }
}

const displayExam = async (req: Request, res: Response) => {
    const getExams = await Exam.find().populate("SubjectName").select("ExamCode ExamName SubjectName ExamDuration ExamQuestion ExamTotalScore ExamPassingMarks ExamStartDate ExamEndDate ExamStatus CreatedBy MidifiedBy")
    if (getExams) {
        return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Data Fetched", getExams))
    }
}

const getQuestionBankData = async (req: Request, res: Response) => {
    const { limit, pageNumber }: any = req.params
    const { subjectName } = req.body
    if (!subjectName) {
        return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "Please Provide Subject Name"))
    }

    try {
        const findSubject: any = await Subject.findOne({ SubjectName: subjectName })
        if (!findSubject) return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, "No Subject Found"))
        const questions = await JSON.parse(fs.readFileSync(findSubject.SubjectMcqFile, 'utf-8'))

        const paginatedData = questions.splice((limit * pageNumber), limit)
        if (limit == 0) {
            return res.header("Access-Control-Allow-Credentials", "true").status(409).send(ApiResult(409, "Please Provide Limit Greater Then 0"))
        }
        let totalpages = Math.ceil(questions.length / limit) - 1
        totalpages = totalpages < 0 ? 0 : totalpages

        if (paginatedData.length <= 0) {
            return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, `Invalid PageNumber Page Limit is 0-${totalpages}`))
        }
        if (questions) {
            return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Data Fetched", { Data: paginatedData, pageNumbers: totalpages + 1 }))
        }
    } catch (error) {
        return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, "No Subject Found Or File Has Not Been Created Please Create Subject Again"))
    }
}

const previousExamData = async (req: Request, res: Response) => {
    try {
        const previoudData = await StudentExam.find()
        return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Data Fetched", previoudData))
    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").send(`Error In Previoud Exam Data ${error}`)
    }
}

const updateQuestion = async (req: Request, res: Response) => {
    const { SubjectName } = req.params
    const data: any = req.body
    if (!SubjectName) {
        return res.header("Access-Control-Allow-Credentials", "true").status(422).send("Please Provide SubjectName")
    }
    try {
        const findExam: any = await Subject.findOne({ SubjectName: SubjectName })
        if (!findExam) return res.header("Access-Control-Allow-Credentials", "true").status(404).send(ApiResult(404, "Not Able To Find Subject Name"))
        fs.writeFile(findExam.SubjectMcqFile, JSON.stringify(data), function (err: any) {
            if (err) { return res.header("Access-Control-Allow-Credentials", "true").status(500).send(ApiResult(500, "Error Updating MCQ Try After SomeTime")) }
            else { return res.header("Access-Control-Allow-Credentials", "true").status(200).send(ApiResult(200, "Mcq Updated")) }
        })

    } catch (error) {
        res.header("Access-Control-Allow-Credentials", "true").send(`Error In Update Question ${error}`)
    }
}

const getStudentName = async (req: Request, res: Response) => {
    try {
        const getStudents = await Student.find().select("StudentUserName")
        if (!getStudents) {
            return res.status(409).send(ApiResult(209, "Error Fetching Data"))
        }
        const studentNames:any = []
        getStudents.forEach((ele) => {
            studentNames.push(ele.StudentUserName.toLowerCase())
        })
        return res.status(200).send(ApiResult(200, "Data Fetched", studentNames))
    } catch (error) {
        res.send("Error Fetching Student Data Try After Some Time")
    }
}
export {
    createExam,
    editExam,
    toggleExam,
    getExamStatus,
    displayExam,
    deleteExam,
    previousExamData,
    getQuestionBankData,
    updateQuestion,
    getStudentName
}