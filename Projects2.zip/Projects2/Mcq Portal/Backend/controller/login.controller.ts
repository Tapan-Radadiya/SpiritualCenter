import { Request, Response } from "express"
import { UserLogin } from "../models/userlogin.model"
import { compareText } from "../utils/bcryptFunction.utils"
import { ApiResult } from "../utils/ApiResult.utils"
import { generateJwt } from "../utils/jwtFunction.utils"
const loginUser = async (req: Request, res: Response) => {
    const { UserId,
        UserPassword } = req.body
    if (!UserId || !UserPassword) {
        return res.status(409).send("All Fields Required")
    }
    try {
        const findUser = await UserLogin.findOne({ UserId: UserId })
        if (!findUser) {
            return res.status(404).send(ApiResult(404, "No User Found With This UserId or EmailId"))
        }
        if (!await compareText(findUser.UserPassword, UserPassword)) {
            return res.status(401).send(ApiResult(401, "Invalid Username Or Password"))
        }
        const data = {
            Name: UserId,
            ROLE: findUser.UserRole
        }

        const jwtData = await generateJwt(data)

        res.cookie("data", jwtData).status(201).send(ApiResult(201, "User logged Successfully", { cookie: jwtData, Role: findUser.UserRole }))
    } catch (error) {
        res.send(`Error in LoginUser ${error}`)
    }
}
export {
    loginUser
}