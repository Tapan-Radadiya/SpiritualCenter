import { NextFunction, Request, Response } from "express";
import { ApiResult } from "../utils/ApiResult.utils";

const authorizeUser = async (req: Request, res: Response, next: NextFunction) => {
    const reqUrl = req.baseUrl.slice(1)
    const { Name, Role } = req.headers

    if (reqUrl == "student" && Role == "STUDENT") {
        next()
    }
    else if (reqUrl == "professor" && Role == "PROFESSOR" || Role == "ADMIN") {
        next()
    }
    else if (reqUrl == "admin" && Role == "ADMIN") {
        next()
    }
    else {
        return res.header("Access-Control-Allow-Credentials", "true").status(401).send(ApiResult(401, "You Are Not Authorized To View This Content"))
    }
}

export default authorizeUser