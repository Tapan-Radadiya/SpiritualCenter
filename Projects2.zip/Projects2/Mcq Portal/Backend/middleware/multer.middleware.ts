import multer from "multer";
import path from "path";
import { Exam } from "../models/exam.model"
import fs from 'fs'
const storageOpt = multer.diskStorage({
    destination(req, file, callback) {
        const examFilePath = path.join(__dirname, "/ExamFiles")
        callback(null, examFilePath)
    },
    filename(req, file, callback) {
        callback(null, `${req.body.ExamCode}.json`)
    },
})

export const upload = multer({
    storage: storageOpt,
    async fileFilter(req, file, callback) {
        const examCode = req.body.ExamCode
        const findExam = await Exam.findOne({ ExamCode: examCode })
        
    },
})