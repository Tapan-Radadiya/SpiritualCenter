import { NextFunction, Request, Response } from "express";
import { ApiResult } from "../utils/ApiResult.utils"
import { checkExpiry, decodeJwt } from "../utils/jwtFunction.utils"
import { UserLogin } from "../models/userlogin.model"

const verifyUser = async (req: Request, res: Response, next: NextFunction) => {
    const data = req.cookies.data
    if (!data) {
        return res.header("Access-Control-Allow-Credentials","true").status(401).send(ApiResult(401, "Please Login"))
    }
    try {
        const decodData: any = await decodeJwt(data)
        const checkUser: any = await UserLogin.findOne({ UserId: decodData.Name })

        if (checkUser) {
            req.headers = { ...req.headers, Name: decodData.Name, Role: checkUser.UserRole }
            return next()
        }
        else {
            return res.header("Access-Control-Allow-Credentials", "true").status(401).send(ApiResult(401, "Invalid User"))
        }
    } catch (error) {
        return res.header("Access-Control-Allow-Credentials", "true").status(401).send(ApiResult(401, "Your Session Is Expired Please Login Again"))
    }
}
export default verifyUser