import { User_Interface } from "@/app/interfaces/userData.interface"
import { connectDb } from "@/config/connectDb"
import { AppSettings } from "@/models/appsettings.model"
import { DonationData } from "@/models/donationdata.model"
import { User } from "@/models/userdata.model"
import { UserLogin } from "@/models/userlogin.model"
import ApiResponse from "@/utils/ApiResponse"
import { uploadImageToS3 } from "@/utils/imageUpload"

async function createUserServiceApi(userdata: User_Interface, uniqueName: string, ImageData: any) {

    const createUser = await User.create({
        First_Name: userdata.First_Name,
        Middle_Name: userdata.Middle_Name,
        Last_Name: userdata.Last_Name,
        Email_Id: userdata.Email_Id,
        UserName: userdata.UserName,
        Password: "password" || userdata.Password,
        Initiation_Date: userdata.Initiation_Date,
        Flat_Number: userdata.Flat_Number,
        Area: userdata.Area,
        City: userdata.City,
        State: userdata.State,
        PinCode: userdata.PinCode,
        ImageUrl: ImageData != null ? await uploadImageToS3(ImageData, userdata.UserName.toString()) : "",
        Status: "ACTIVE",
    })
    const createLoginCredentials = await UserLogin.create({
        UserName: createUser.UserName,
        Password: createUser.Password,
        Role: "DEVOTEE"
    })

    return ApiResponse(201, "User Registered Successfully 👍", createUser)
}

async function deleteUserServiceApi(usernameToUpdate: string) {

    const removeUser = await User.findOneAndUpdate({ UserName: usernameToUpdate }, { Status: "INACTIVE" })
    const removeCredentials = await UserLogin.findOneAndDelete({ UserName: usernameToUpdate })
    if (!removeUser || !removeCredentials) {
        return ApiResponse(404, "User Not Found")
    }
    return ApiResponse(200, "User Deleted 👍")
}

async function editUserServiceApi(userData: User_Interface, usernameToUpdate: string, ImageData: any, prevImage: string) {

    const editUser = await User.findOneAndUpdate({ UserName: usernameToUpdate }, {
        First_Name: userData.First_Name,
        Middle_Name: userData.Middle_Name,
        Last_Name: userData.Last_Name,
        Email_Id: userData.Email_Id,
        Initiation_Date: userData.Initiation_Date,
        Flat_Number: userData.Flat_Number,
        Area: userData.Area,
        City: userData.City,
        State: userData.State,
        PinCode: userData.PinCode,
        ImageUrl: ImageData != null ? await uploadImageToS3(ImageData, usernameToUpdate) : prevImage,
        Status: "ACTIVE",
    }, { new: true })

    if (!editUser) {
        return ApiResponse(500, "Error Updating User Try After SomeTime")
    }
    return ApiResponse(200, "User Updated 👍")

}

async function getDonationDataServiceApi() {
    const donationData: any = await DonationData.aggregate(
        [
            {
                $group: {
                    _id: { UserName: "$UserName", Month: "$Month", Year: "$Year" },
                    totalDonation: {
                        $sum: "$Donation_Amount"
                    }
                }
            },
            {
                $sort: {
                    totalDonation: 1
                }
            }
        ]
    )
    if (donationData.length == 0) {
        return ApiResponse(200, "No Donation Data Found 👍", donationData)
    }
    return ApiResponse(200, "Data Fetched 👍", donationData)
}

async function getRecordsPerPageServiceApi() {
    const getPages = await AppSettings.findOne({})
    if (!getPages) {
        return ApiResponse(500, "Error Try After SomeTime")
    }
    const curRecordsPerPage = getPages.RecordsPerPage
    return ApiResponse(200, "Current Records Are 👍", { curRecordsPerPage })
}

async function getTotalPageServiceApi() {
    const pageLimit = await AppSettings.findOne({})
    const limit = pageLimit.RecordsPerPage
    const pageArray: number[] = []
    const totalDocuments = await User.find({ Status: "ACTIVE" })
    const totalPages = Math.ceil(totalDocuments.length / Number(limit))

    for (let i = 1; i <= totalPages; i++) {
        pageArray.push(i)
    }

    if (pageArray.length > 1) {
        return ApiResponse(200, "PageNumber Fetched", pageArray)
    }
    else {
        return ApiResponse(200, "PageNumber Fetched", [])
    }
}

async function getUnpaidDonationDataServiceApi() {
    const unpaidDonationData = await User.aggregate(
        [
            {
                $lookup: {
                    from: "donationdatas",
                    localField: "UserName",
                    foreignField: "UserName",
                    as: "result"
                }
            },
            {
                $match: {
                    $nor: [
                        { "result.Month": { $eq: new Date().getMonth() + 1 } },
                    ]
                }
            },
            {
                $project: {
                    UserName: 1,
                    First_Name: 1,
                    Middle_Name: 1,
                    Last_Name: 1,
                    Email_Id: 1,
                    Flat_Number: 1,
                    Area: 1,
                    City: 1,
                    State: 1,
                    PinCode: 1,
                    Initiation_Date: 1,
                }
            }
        ]
    )
    return ApiResponse(200, "Data Fetched", unpaidDonationData)
}

async function rollbackUserServiceApi(usernameToRollBack: string) {
    const updateUser = await User.findOneAndUpdate({ UserName: usernameToRollBack }, { Status: "ACTIVE" }, { new: true })
    const addCredentials = await UserLogin.create({
        UserName: updateUser.UserName,
        Password: updateUser.Password,
        Role: "DEVOTEE"
    })
    if (!updateUser || !addCredentials) {
        return ApiResponse(500, "Error Revoking User")
    }
    else {
        return ApiResponse(200, "User Revoked 👍")
    }
}

async function updateRecordsPerPageServiceApi(RecordsValue: number) {
    const getId = await AppSettings.findOne({})
    if (!getId) {
        return ApiResponse(500, "Server Error Try After SomeTime")
    }
    const updateValue = await AppSettings.findByIdAndUpdate(getId._id,
        { RecordsPerPage: RecordsValue }, { new: true })

    if (!updateValue) {
        return ApiResponse(500, "Error Updating App Setting Try After SomeTime")
    }
    return ApiResponse(200, "Records Per Page Value Updated 👍")
}

async function getUserListServiceApi(pagenumber: number) {
    const pageLimit = await AppSettings.findOne({})
    const limit = pageLimit.RecordsPerPage
    const skip = (pagenumber - 1) * limit

    const userData: any = await User.find({ Status: "ACTIVE" }).limit(limit).skip(skip)
    if (userData.length == 0) {
        return ApiResponse(200, "Empty User Data 👍", userData)
    }
    return ApiResponse(200, "Data Fetched 👍", userData)
}

export {
    createUserServiceApi,
    deleteUserServiceApi,
    editUserServiceApi,
    getDonationDataServiceApi,
    getRecordsPerPageServiceApi,
    getTotalPageServiceApi,
    getUnpaidDonationDataServiceApi,
    rollbackUserServiceApi,
    updateRecordsPerPageServiceApi,
    getUserListServiceApi
}