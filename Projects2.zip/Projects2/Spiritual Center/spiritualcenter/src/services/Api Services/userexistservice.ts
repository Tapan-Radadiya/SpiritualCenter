export default async function checkUserExistService(username: string) {
    const data = await fetch(`http://localhost:3000/api/checkUserExit/${username}`, { method: "GET" })
    return await data.json()
}