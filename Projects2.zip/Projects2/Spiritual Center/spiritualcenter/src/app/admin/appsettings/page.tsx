'use client'
import { App_Settings } from "@/app/interfaces/appsettings.interface"
import { setDeletedUserData, setTotalRecordsValue } from "@/lib/features/userdataslice"
import { changeRecordsPerPageService, getCurrectRecordsPerPageService, getDeletedUserDataService, revokeUserDataService } from "@/services/adminservices"
import { useEffect } from "react"
import { useForm } from "react-hook-form"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"

export default function AppSettings() {
    const { register, setValue, formState: { errors }, handleSubmit } = useForm<App_Settings>()
    useEffect(() => {
        fetchData()
        fetchCurrectRecordsValue()
    }, [])


    const deletedUserData = useSelector((state: any) => state.userdataslice.deletedUserData)
    const currentRecords = useSelector((state: any) => state.userdataslice.currentRecordsPerPage)
    setValue("RecordsPerPage", currentRecords)
    const dispatch = useDispatch()

    async function fetchData() {
        const { statusCode, message, data } = await getDeletedUserDataService()
        if (statusCode == 200) {
            dispatch(setDeletedUserData(data))
        }
    }
    async function fetchCurrectRecordsValue() {
        const { statusCode, message, data } = await getCurrectRecordsPerPageService()
        if (statusCode == 200) {
            dispatch(setTotalRecordsValue(data.curRecordsPerPage))
        }
    }

    async function revokeUser(userName: string) {
        const { statusCode, message } = await revokeUserDataService(userName)
        if (statusCode == 200) {
            await fetchData()
            toast.success(message)
        }
        else if (statusCode == 422) {
            toast.warning(message)
        }
        else {
            toast.error(message)
        }
    }

    async function changePageValue(form_data: any) {
        const { statusCode, message } = await changeRecordsPerPageService(form_data.RecordsPerPage)
        if (statusCode == 200) {
            dispatch(setTotalRecordsValue(form_data.RecordsPerPage))
            toast.success(message)
        }
    }
    return (
        <>

            <div className="container d-flex justify-content-center p-3" style={{ marginTop: "100px" }}>
                <p className="mr-5" style={{ fontSize: "20px", letterSpacing: "2px" }}>Change Records Per Page Value</p>
                <form onSubmit={handleSubmit((data) => changePageValue(data))}>
                    <div className="form-group d-flex">
                        <input type="text" {...register("RecordsPerPage", {
                            required: { value: true, message: "Records Value Required" },
                            min: { value: 1, message: "Records Value Can't Be Less Then 1" }
                        })} className="form-control border border-dark w-75" />
                        <button className="btn w-50 btn-primary ml-3">Submit</button>
                    </div>
                    {errors.RecordsPerPage && <span className="text-danger">{errors.RecordsPerPage.message}</span>}
                </form>
            </div>
            <div className="container mt-5 p-2">
                <div className="container">
                    <p className="text-center" style={{ fontSize: "25px", letterSpacing: "2px" }}>Deleted User Data</p>
                </div>
                <div className="container">
                    <table className="table text-center">
                        <thead className="thead-dark">
                            <tr>
                                <th>FirstName</th>
                                <th>MiddleName</th>
                                <th>LastName</th>
                                <th>EmailId</th>
                                <th>UserName</th>
                                <th>PinCode</th>
                                <th>Revoke User</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                deletedUserData.map((key: any, value: any) => (
                                    <tr key={value}>
                                        <td>{key.First_Name}</td>
                                        <td>{key.Middle_Name}</td>
                                        <td>{key.Last_Name}</td>
                                        <td>{key.Email_Id}</td>
                                        <td>{key.UserName}</td>
                                        <td>{key.PinCode}</td>
                                        <td><button className="btn btn-success" onClick={() => revokeUser(key.UserName)}>Revoke User</button></td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}