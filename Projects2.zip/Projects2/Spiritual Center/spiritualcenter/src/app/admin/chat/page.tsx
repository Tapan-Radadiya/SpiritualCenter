"use client"
import ChatComponent from "@/app/components/chatComponent";

export default function Chat(){
    return(
        <>
            <ChatComponent/>
        </>
    )
}