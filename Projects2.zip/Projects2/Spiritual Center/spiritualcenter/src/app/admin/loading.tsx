export default function LoadingPage() {
    return (
        <>
           <div className="text-center display-1" style={{ marginTop: "15%" }}>
                <div className="spinner-border" role="status">
                    <span className="sr-only">Loading...</span>
                </div>
            </div>
        </>
    )
}