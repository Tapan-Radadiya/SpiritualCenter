'use client'
import { addData } from "@/lib/features/donationdataslice"
import { getDonationDataService } from "@/services/devoteeservices"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"

export default function DevoteePayment() {
    useEffect(() => {
        fetchData()
    }, [])
    const dispatch = useDispatch()
    const donationData = useSelector((state: any) => state.donationdataslice.donationData)
    async function fetchData() {
        const { statusCode, message, data }: any = await getDonationDataService()
        if (statusCode == 200) {
            dispatch(addData(data))
        }
        else if (statusCode == 409) {
            toast.warning(message)
        }
        else if (statusCode == 500) {
            toast.error(message)
        }
    }

    return (
        <>

            <div className="container">
                <div className="container mt-5 text-center">
                    <h1 className="mb-5" style={{ letterSpacing: "2px" }}>Payment Data</h1>
                    <table id="allMyPaymentList" className="table">
                        <thead className="thead-dark">
                            <tr>
                                <th>Devotee Id</th>
                                <th>Year</th>
                                <th>Month</th>
                                <th>Donation Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                donationData.map((key: any, value: any) => (
                                    <tr key={value} className={key.totalDonation >= 10000 ? "bg-success" : ""}>
                                        <td>{key._id.UserName}</td>
                                        <td>{key._id.Month}</td>
                                        <td>{key._id.Year}</td>
                                        <td>{key.totalDonation}</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}