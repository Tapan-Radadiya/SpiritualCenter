'use client'
import { useEffect } from "react"
import DevoteeHeader from "../components/Devoteeheader"
import { socket } from "../../socket"
export default function Header({ children }: { children: React.ReactNode }) {
    useEffect(() => {
        socket.emit("NEW_USER_CONNECTED")
    }, [])
    return (
        <>
            <DevoteeHeader />
            <section>
                {children}
            </section>
        </>
    )
}