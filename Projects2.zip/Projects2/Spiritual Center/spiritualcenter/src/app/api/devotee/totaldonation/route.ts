import { DonationData } from "@/models/donationdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies, headers } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { getTotalDonationServiceApi } from "@/services/Api Services/devoteeservices";

export async function GET(req: NextRequest) {

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Host"))
    }
    const username = headers().get("username")

    if (!username) {
        return NextResponse.json(ApiResponse(409, "UserName Required"))
    }
    try {
        const { statusCode, message, data } = await getTotalDonationServiceApi(username)
        return NextResponse.json(ApiResponse(statusCode, message, data))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}