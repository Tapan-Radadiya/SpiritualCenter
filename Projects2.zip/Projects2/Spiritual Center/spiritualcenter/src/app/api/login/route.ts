import { User } from "@/models/userdata.model";
import { UserLogin } from "@/models/userlogin.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { createToken } from "@/utils/jwtToken";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
    if (!await connectDb()) {
        return ApiResponse(500, "Error Connecting With DB")
    }
    const {
        UserName,
        Password,
        Role
    } = await req.json()

    if (!UserName) {
        return NextResponse.json(ApiResponse(422, "UserName Is Required"))
    }
    if (!Password) {
        return NextResponse.json(ApiResponse(422, "Password Is Required"))
    }
    if (!Role) {
        return NextResponse.json(ApiResponse(422, "Role Is Required"))
    }

    try {
        const checkUser = await UserLogin.findOne({ UserName: UserName })
        if (!checkUser) {
            return NextResponse.json(ApiResponse(404, "No User Found With This UserName"))
        }
        if (checkUser.Password != Password || checkUser.Role != Role) {
            return NextResponse.json(ApiResponse(401, "Invalid Credentials"))
        }
        const jwtData = createToken(checkUser.UserName, checkUser.Role)

        cookies().set("userdata", jwtData)
        const setUserStatus = await User.findOneAndUpdate({ UserName: UserName }, { isOnline: true })
        return NextResponse.json(ApiResponse(200, "User Logged In", { Role: checkUser.Role, Username: checkUser.UserName }))

    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}