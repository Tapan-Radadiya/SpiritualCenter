import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextResponse } from "next/server";
export async function GET() {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    try {
        const getDeletedData = await User.find({ Status: "INACTIVE" }).select("First_Name Middle_Name Last_Name Email_Id UserName PinCode")
        if (getDeletedData.length == 0) {
            return NextResponse.json(ApiResponse(200, "No Data Found 👍", getDeletedData))
        }
        else {
            return NextResponse.json(ApiResponse(200, "Data Fetched 👍", getDeletedData))
        }
    } catch (error) {
        console.log(error);
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }

}