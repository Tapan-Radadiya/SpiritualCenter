import { User } from "@/models/userdata.model";
import { UserLogin } from "@/models/userlogin.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { deleteUserServiceApi } from "@/services/Api Services/adminservices";

export async function DELETE(req: NextRequest, { params }: any) {
  
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Host"))
    }
    const { usernameToUpdate } = params
    if (!usernameToUpdate) {
        return NextResponse.json(ApiResponse(422, "Username Is Required"))
    }

    try {
      
        const { statusCode, message } = await deleteUserServiceApi(usernameToUpdate)
        return NextResponse.json(ApiResponse(statusCode, message))
    } catch (error) {
        console.log(error);

        return NextResponse.json(ApiResponse(500, "Server Error"))
    }
}