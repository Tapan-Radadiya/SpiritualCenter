import ApiResponse from "@/utils/ApiResponse";
import { NextRequest, NextResponse } from "next/server";
import { connectDb } from "@/config/connectDb";
import { DonationData } from "@/models/donationdata.model";
import authUser from "@/utils/authUser";
import { cookies } from "next/headers";
import { getDonationDataServiceApi } from "@/services/Api Services/adminservices";

export async function GET(req: NextRequest) {

    // const cookieData = cookies().get("userdata")
    // const username = await authUser(cookieData?.value, ["ADMIN"])
    // if (!username) {
    //     return NextResponse.json(ApiResponse(401, "You Are Not Authorized For This"))
    // }
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }

    try {

        const { statusCode, message, data } = await getDonationDataServiceApi()
        return NextResponse.json(ApiResponse(statusCode, message, data))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}