import { AppSettings } from "@/models/appsettings.model";
import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextRequest, NextResponse } from "next/server";
import { getTotalPageServiceApi } from "@/services/Api Services/adminservices";

export async function GET(req: NextRequest) {

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    
    try {
        const { statusCode, message, data } = await getTotalPageServiceApi()
        return NextResponse.json(ApiResponse(statusCode, message, data))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}