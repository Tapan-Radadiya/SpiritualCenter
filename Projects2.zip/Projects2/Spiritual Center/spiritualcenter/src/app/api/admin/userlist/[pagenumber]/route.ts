import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { headers } from "next/headers";
import { AppSettings } from "@/models/appsettings.model";
import { getUserListServiceApi } from "@/services/Api Services/adminservices";

export async function GET(req: NextRequest, { params }: any) {
    const userName = headers().get("username")
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With Server"))
    }
    const { pagenumber } = params

    try {

             const { statusCode, message, data } = await getUserListServiceApi(pagenumber)
        return NextResponse.json(ApiResponse(statusCode, message, data))
        
    } catch (error) {
        console.log(error)
        return NextResponse.json(ApiResponse(500, "Error Connecting With Server", error))
    }
}