import { AppSettings } from "@/models/appsettings.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextResponse } from "next/server";
import { getRecordsPerPageServiceApi } from "@/services/Api Services/adminservices";
export async function GET() {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    try {
       
        
        const { statusCode, message, data } = await getRecordsPerPageServiceApi()
        return NextResponse.json(ApiResponse(statusCode, message, data))
    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error Try After Some Time"))
    }
}