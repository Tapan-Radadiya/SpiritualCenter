import { User } from "@/models/userdata.model";
import ApiResponse from "@/utils/ApiResponse";
import authUser from "@/utils/authUser";
import { connectDb } from "@/config/connectDb";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { getUnpaidDonationDataServiceApi } from "@/services/Api Services/adminservices";

export async function GET(req: NextRequest) {

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    try {
        const { statusCode, message, data } = await getUnpaidDonationDataServiceApi()
        return NextResponse.json(ApiResponse(statusCode, message, data))

    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}