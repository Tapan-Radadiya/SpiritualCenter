import { UserLogin } from "@/models/userlogin.model";
import { NextApiRequest } from "next";
import { NextResponse } from "next/server";

export async function GET(req: NextApiRequest, { params }: any) {

    const exist = await UserLogin.findOne(
        { UserName: params.username },
    )
    if (exist)
        return NextResponse.json(true)
    else
        return NextResponse.json(false)
}