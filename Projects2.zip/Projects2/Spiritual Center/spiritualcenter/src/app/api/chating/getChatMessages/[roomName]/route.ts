import { ChatingData } from "@/models/chating.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { NextRequest, NextResponse } from "next/server";
import { getChatMessagesServiceApi } from "@/services/Api Services/chatingservice";

export async function GET(req: NextRequest, { params }: any) {

    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(502, "Error Connecting With Server"))
    }

    try {
        const { roomName } = params

        const { statusCode, message, data } = await getChatMessagesServiceApi(roomName)
        return NextResponse.json(ApiResponse(statusCode, message, data))
    } catch (error) {
        console.log(error);
        return NextResponse.json(ApiResponse(500, "Internal Server Error"))
    }
}