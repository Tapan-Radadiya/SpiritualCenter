import { User } from "@/models/userdata.model";
import { UserLogin } from "@/models/userlogin.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import { headers } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { getAllUsersDataServiceApi } from "@/services/Api Services/chatingservice";

export async function GET(req: NextRequest) {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting With DB"))
    }
    try {
        const username = headers().get("username")
        const { statusCode, message, data } = await getAllUsersDataServiceApi(username)
        return NextResponse.json(ApiResponse(statusCode, message, data))

    } catch (error) {
        return NextResponse.json(ApiResponse(500, "Server Error Try After SomeTime"))
    }
}