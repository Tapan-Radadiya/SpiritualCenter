import { ChatingData } from "@/models/chating.model";
import ApiResponse from "@/utils/ApiResponse";
import { connectDb } from "@/config/connectDb";
import getTime from "@/utils/getCurrentTime";
import { headers } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { sendMessageServiceApi } from "@/services/Api Services/chatingservice";

export async function POST(req: NextRequest) {
    if (!await connectDb()) {
        return NextResponse.json(ApiResponse(500, "Error Connecting DB"))
    }
    try {
        const { userMessage, roomName, time } = await req.json()
        const username = headers().get("username")
        if (!username) {
            return NextResponse.json(ApiResponse(401, "Invalid Session Please Login Again"))
        }
        if (!userMessage) {
            return NextResponse.json(ApiResponse(422, "Message Should Not Be Empty"))
        }
        if (!roomName) {
            return NextResponse.json(ApiResponse(422, "Room Name Required"))
        }
        if (!time) {
            return NextResponse.json(ApiResponse(422, "Time Required"))
        }
       

        const { statusCode, message } = await sendMessageServiceApi({ username, userMessage, roomName, time })
        return NextResponse.json(ApiResponse(statusCode, message))
    } catch (error) {
        console.log(error);

        return NextResponse.json(ApiResponse(500, "Error Sending Message"))
    }
}
