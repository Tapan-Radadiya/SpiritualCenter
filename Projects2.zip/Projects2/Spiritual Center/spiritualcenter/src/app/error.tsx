'use client'
import userlogoutaction from "@/actions/userlogoutaction"
import errorImage from "../images/issue.png"
import Image from "next/image"
import { useRouter } from "next/navigation"
export default function Error({ error, reset }: { error: Error, reset: () => void }) {
    const router = useRouter()
    function navigateToLogin() {
        userlogoutaction()
        router.push("/login")
    }
    return (
        <>
            <div className="container d-flex justify-content-center">
                <Image
                    src={errorImage}
                    alt="Error Image"
                    width={500}
                    height={500}
                />
            </div>
            <div className="container mt-5 text-center">
                <h1>There Is Some Issue Please Login Again</h1>
                <button className="btn btn-success mt-4" type="button" style={{ fontSize: "20px" }} onClick={() => navigateToLogin()}>Please Login</button>
            </div>
        </>
    )
}