"use client"

import ChangeUserStatus from "@/actions/changeUserStatusAction"
import { socket } from "@/socket"
import { useEffect } from "react"

export default function Home() {
  //   useEffect(() => {
  //     function unloadEventHandler(event: BeforeUnloadEvent) {
  //         event.preventDefault()
  //         socket.emit("DISCONNECT_USER")
  //         ChangeUserStatus()
  //         event.returnValue = true
  //     }
  //     window.addEventListener("beforeunload", unloadEventHandler)
  //     return () => {
  //         window.removeEventListener("beforeunload", unloadEventHandler)
  //     }
  // }, [])
  return (
    <>

    </>
  );
}
