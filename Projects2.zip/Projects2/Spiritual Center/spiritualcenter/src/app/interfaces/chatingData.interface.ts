export interface ChatingData_Interface {
    RoomName: string,
    MessageData: [
        {
            userName: string,
            message: string,
            time: Date
        }
    ]
}