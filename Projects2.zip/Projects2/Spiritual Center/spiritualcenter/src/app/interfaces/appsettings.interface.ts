export interface App_Settings {
    RecordsPerPage: number
}