'use server'
import { User } from "@/models/userdata.model";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import jwt from "jsonwebtoken"

export default async function userlogoutaction() {
    try {
        const cookie: any = cookies().get("userdata")
        const { Username }: any = jwt.decode(cookie.value)
        cookies().delete("userdata")
        await User.findOneAndUpdate({ UserName: Username }, { isOnline: false }) // Seting User Active Status to False
        return redirect("/login")
    } catch (error) {
        console.log(error);
        cookies().delete("userdata")
        return redirect("/login")
    }
}