"use server"
import { decodeJwt } from "@/utils/jwtToken";
import { cookies } from "next/headers";

export default async function ChangeUserStatus() {
    console.log("Heyy Change User Status");

    const cookie: any = cookies().get("userdata")
    const { Username }: any = decodeJwt(cookie.value)
    console.log("-=-=-=-=", Username);
}