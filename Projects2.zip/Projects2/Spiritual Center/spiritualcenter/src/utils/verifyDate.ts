export function verifyInitiaionDate(initiationDate: Date) {
    const initDate = initiationDate
    let months = Number((new Date().getFullYear() - new Date(initDate).getFullYear()) * 12)
    months -= new Date(initDate).getMonth()
    months += new Date().getMonth()
    if (months > 2) {
        return "Initiation Date should be not be less than of last 2 month"
    }
}