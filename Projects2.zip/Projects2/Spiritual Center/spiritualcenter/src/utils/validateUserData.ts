import { User_Interface } from "@/app/interfaces/userData.interface";
import ApiResponse from "./ApiResponse";
import validator from "validator";
import { verifyInitiaionDate } from "./verifyDate";

export function validateUser(user_data: User_Interface, ImageData?: File) {
    const {
        First_Name,
        Middle_Name,
        Last_Name,
        Email_Id,
        Initiation_Date,
        Flat_Number,
        Area,
        City,
        State,
        PinCode,
        Status
    } = user_data


    if (!First_Name) {
        return ApiResponse(422, "FirstName Is Required")
    }
    else if (First_Name.length <= 3) {
        return ApiResponse(409, "For First Name minimum 3 char required")
    }
    else if (First_Name.length >= 15) {
        return ApiResponse(409, "For First Name maximum 15 char allowed")
    }
    if (!Middle_Name) {
        return ApiResponse(422, "MiddleName Is Required")
    }
    else if (Middle_Name.length <= 3) {
        return ApiResponse(409, "For Middle Name minimum 3 char required")
    }
    else if (Middle_Name.length >= 15) {
        return ApiResponse(409, "For Middle Name maximum 15 char allowed")
    }
    if (!Last_Name) {
        return ApiResponse(422, "LastName Is Required")
    }
    else if (Last_Name.length <= 3) {
        return ApiResponse(409, "For Last Name minimum 3 char required")
    }
    else if (Last_Name.length >= 15) {
        return ApiResponse(409, "For Last Name maximum 15 char allowed")
    }
    if (!Email_Id) {
        return ApiResponse(422, "Email Id Is Required")
    }

    // String -> string
    else if (!validator.isEmail(Email_Id.toString())) {
        return ApiResponse(409, "Invalid Email Id")
    }
    if (!Initiation_Date) {
        return ApiResponse(422, "Initiation Date Is Required")
    }
    else if (new Date(Initiation_Date) > new Date()) {
        return ApiResponse(409, "Initiation Date Should Not Be Of Future")
    }
    else {
        let months = Number((new Date().getFullYear() - new Date(Initiation_Date).getFullYear()) * 12)
        months -= new Date(Initiation_Date).getMonth()
        months += new Date().getMonth()
        if (months > 2) {
            return ApiResponse(409, "Initiation Date should be not be less than of last 2 month")
        }
    }
    if (!Flat_Number) {
        return ApiResponse(422, "Flat Number Is Required")
    }
    else if (!Number(Flat_Number)) {
        return ApiResponse(422, "Flat Number Should Be Number")
    }
    if (!Area) {
        return ApiResponse(422, "Area Is Required")
    }
    if (!City) {
        return ApiResponse(422, "City Is Required")
    }
    if (!State) {
        return ApiResponse(422, "State Is Required")
    }
    if (!PinCode) {
        return ApiResponse(422, "Pincode Is Required")
    }
    else if (!validator.isPostalCode(PinCode.toString(), "IN")) {
        return ApiResponse(409, "Invalid Pincode")
    }
    if (!Status) {
        return ApiResponse(422, "Status Is Required")
    }
    else if (Status != "ACTIVE" && Status != "INACTIVE") {
        return ApiResponse(409, "Invalid Value For Status")
    }
    if (ImageData) {
        if (ImageData?.size > 10000000) {
            return ApiResponse(409, "File Should Not Be More Then 10 MB")
        }
        else {
            const ImageType = ImageData?.type.split("/")[1]
            if (ImageType != "png" && ImageType != "jpg" && ImageType != "jpeg") {
                return ApiResponse(409, "Invalid File Type (Allowed png, jpg, jpeg)")
            }
        }
    }
    return ApiResponse(200, "All Fields Are Valid")
}