import jwt from 'jsonwebtoken'

export function createToken(username: string, role: string) {
    return jwt.sign({ Username: username, Role: role }, `${process.env.JWT_SECRET_KEY}`)
}

export function decodeJwt(token: string) {
    return jwt.verify(token, `${process.env.JWT_SECRET_KEY}`)
}