import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import fs from 'fs'

export async function uploadImageToS3(file: File, userName: string) {
    const s3client = new S3Client(
        {
            region: "ap-south-1",
            credentials: {
                accessKeyId: `${process.env.ACCESS_KEY}`,
                secretAccessKey: `${process.env.SECRET_ACCESS_KEY}`
            }
        }
    )
    const imageBuffer: any = await file.arrayBuffer()

    const uploadStatus = await s3client.send(
        new PutObjectCommand({
            Bucket: `${process.env.BUCKET_NAME}`,
            Key: `${userName}_Profile_Image`,
            Body: imageBuffer,
            ContentType: "image/png"
        })
    )
    if (uploadStatus.$metadata.httpStatusCode == 200) {
        return `${userName}_Profile_Image`
    }
    else {
        throw new Error("Error Uploading Image")
    }
}