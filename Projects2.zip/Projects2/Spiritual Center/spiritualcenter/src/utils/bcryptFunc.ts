'use client'
import bcrypt from "bcrypt"

function encryptData(data: string) {
    const saltRounds = process.env.SALT_ROUND
    const saltValue = bcrypt.genSaltSync(Number(saltRounds))
    return bcrypt.hashSync(data, saltValue)
}

function compareData(data: string, encryptData: string) {
    return bcrypt.compareSync(data, encryptData)
}

export {
    encryptData, compareData
}